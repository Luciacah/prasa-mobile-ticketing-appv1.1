import 'package:flutter/material.dart';
import '../presentation/ai_chat_support/ai_chat_support.dart';
import '../presentation/home_dashboard/home_dashboard.dart';
import '../presentation/ticket_purchase/ticket_purchase.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/onboarding_flow/onboarding_flow.dart';
import '../presentation/train_status_alerts/train_status_alerts.dart';
import '../presentation/user_profile_screen/user_profile_screen.dart';
import '../presentation/settings_screen/settings_screen.dart';
import '../presentation/registration_screen/registration_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String aiChatSupport = '/ai-chat-support';
  static const String homeDashboard = '/home-dashboard';
  static const String ticketPurchase = '/ticket-purchase';
  static const String login = '/login-screen';
  static const String onboardingFlow = '/onboarding-flow';
  static const String trainStatusAlerts = '/train-status-alerts';
  static const String userProfileScreen = '/user-profile-screen';
  static const String settingsScreen = '/settings-screen';
  static const String registrationScreen = '/registration-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const OnboardingFlow(),
    aiChatSupport: (context) => const AiChatSupport(),
    homeDashboard: (context) => const HomeDashboard(),
    ticketPurchase: (context) => const TicketPurchase(),
    login: (context) => const LoginScreen(),
    onboardingFlow: (context) => const OnboardingFlow(),
    trainStatusAlerts: (context) => const TrainStatusAlerts(),
    userProfileScreen: (context) => const UserProfileScreen(),
    settingsScreen: (context) => const SettingsScreen(),
    registrationScreen: (context) => const RegistrationScreen(),
    // TODO: Add your other routes here
  };
}
