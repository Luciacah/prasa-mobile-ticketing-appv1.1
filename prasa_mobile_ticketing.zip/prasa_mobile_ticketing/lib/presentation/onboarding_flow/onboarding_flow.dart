import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/onboarding_page_widget.dart';
import './widgets/page_indicator_widget.dart';

class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({super.key});

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow>
    with TickerProviderStateMixin {
  late PageController _pageController;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  int _currentPage = 0;

  final List<Map<String, dynamic>> _onboardingData = [
    {
      "title": "Digital QR Tickets",
      "description":
          "Skip the queues and get instant digital tickets with secure QR codes. Travel smarter with PRASA's modern ticketing system.",
      "imageUrl":
          "https://images.unsplash.com/photo-1725451397002-bdee8fd20683",
      "semanticLabel":
          "Modern train station platform with diverse passengers using mobile phones to scan QR codes at digital turnstiles, showing the convenience of contactless ticketing",
    },
    {
      "title": "AI-Powered Support",
      "description":
          "Get instant help 24/7 with our intelligent chatbot. Ask questions, get travel updates, and resolve issues anytime, anywhere.",
      "imageUrl":
          "https://images.unsplash.com/photo-1682994283524-f0c74eee90c8",
      "semanticLabel":
          "Friendly customer service representative with headset helping passengers at a modern train station information desk, with digital screens showing AI chat interface",
    },
    {
      "title": "Smart Fare Recommendations",
      "description":
          "Save money with personalized fare suggestions based on your travel patterns. Discover the best routes and deals for your journey.",
      "imageUrl":
          "https://images.unsplash.com/photo-1508512630842-7f13136fa18b",
      "semanticLabel":
          "South African commuters of diverse backgrounds looking at mobile phone screens showing route maps and fare comparisons while standing on a busy train platform",
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));
    _fadeController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });

    // Haptic feedback for page transitions
    HapticFeedback.lightImpact();
  }

  void _nextPage() {
    if (_currentPage < _onboardingData.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _skipOnboarding() {
    _navigateToLogin();
  }

  void _navigateToLogin() {
    Navigator.pushReplacementNamed(context, '/login-screen');
  }

  void _navigateToHome() {
    Navigator.pushReplacementNamed(context, '/home-dashboard');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Stack(
          children: [
            // Main content
            Column(
              children: [
                // Skip button
                _buildSkipButton(),

                // Page view
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: _onPageChanged,
                    itemCount: _onboardingData.length,
                    itemBuilder: (context, index) {
                      final data = _onboardingData[index];
                      return OnboardingPageWidget(
                        title: data["title"] as String,
                        description: data["description"] as String,
                        imageUrl: data["imageUrl"] as String,
                        semanticLabel: data["semanticLabel"] as String,
                        isLastPage: index == _onboardingData.length - 1,
                        onGetStarted: _navigateToHome,
                        onSignIn: _navigateToLogin,
                      );
                    },
                  ),
                ),

                // Page indicator and navigation
                _buildBottomNavigation(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkipButton() {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          top: 2.h,
          right: 4.w,
        ),
        child: Align(
          alignment: Alignment.topRight,
          child: TextButton(
            onPressed: _skipOnboarding,
            style: TextButton.styleFrom(
              padding: EdgeInsets.symmetric(
                horizontal: 4.w,
                vertical: 1.h,
              ),
            ),
            child: Text(
              'Skip',
              style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.primary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNavigation() {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 6.w,
          vertical: 3.h,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Page indicator
            PageIndicatorWidget(
              currentPage: _currentPage,
              totalPages: _onboardingData.length,
            ),

            // Navigation button (only show if not last page)
            if (_currentPage < _onboardingData.length - 1) ...[
              SizedBox(height: 3.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Previous button (invisible for spacing)
                  SizedBox(width: 20.w),

                  // Next button
                  Container(
                    width: 15.w,
                    height: 6.h,
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      borderRadius: BorderRadius.circular(3.h),
                    ),
                    child: IconButton(
                      onPressed: _nextPage,
                      icon: CustomIconWidget(
                        iconName: 'arrow_forward',
                        color: AppTheme.lightTheme.colorScheme.onPrimary,
                        size: 6.w,
                      ),
                    ),
                  ),

                  // Skip button (invisible for spacing)
                  SizedBox(width: 20.w),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
