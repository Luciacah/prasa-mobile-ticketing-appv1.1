import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TravelPreferencesSetupWidget extends StatefulWidget {
  final String homeStation;
  final String workStation;
  final String preferredLanguage;
  final Function(Map<String, dynamic>) onPreferencesChanged;

  const TravelPreferencesSetupWidget({
    Key? key,
    required this.homeStation,
    required this.workStation,
    required this.preferredLanguage,
    required this.onPreferencesChanged,
  }) : super(key: key);

  @override
  State<TravelPreferencesSetupWidget> createState() =>
      _TravelPreferencesSetupWidgetState();
}

class _TravelPreferencesSetupWidgetState
    extends State<TravelPreferencesSetupWidget> {
  // Mock South African railway stations
  final List<String> _stations = [
    'Cape Town',
    'Johannesburg Park',
    'Pretoria',
    'Durban',
    'Port Elizabeth',
    'Bloemfontein',
    'East London',
    'Pietermaritzburg',
    'Kimberley',
    'Polokwane',
    'Nelspruit',
    'Rustenburg',
    'Klerksdorp',
    'Welkom',
    'Vereeniging',
    'Soweto',
    'Sandton',
    'Rosebank',
    'Observatory',
    'Wynberg',
    'Bellville',
    'Parow',
    'Goodwood',
    'Salt River',
    'Woodstock',
    'Mowbray',
    'Rondebosch',
    'Newlands',
    'Claremont',
    'Kenilworth',
    'Diep River',
    'Retreat',
    'Steenberg',
    'Muizenberg',
    'St James',
    'Kalk Bay',
    'Fish Hoek',
    'Glencairn',
    'Simon\'s Town',
  ];

  final List<String> _languages = [
    'English',
    'Afrikaans',
    'Zulu',
    'Xhosa',
    'Sotho',
    'Tswana',
    'Pedi',
    'Venda',
    'Tsonga',
    'Ndebele',
    'Swati',
  ];

  String? _selectedHomeStation;
  String? _selectedWorkStation;
  String? _selectedLanguage;

  @override
  void initState() {
    super.initState();
    _selectedHomeStation =
        widget.homeStation.isNotEmpty ? widget.homeStation : null;
    _selectedWorkStation =
        widget.workStation.isNotEmpty ? widget.workStation : null;
    _selectedLanguage = widget.preferredLanguage;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 4.h),

        Text(
          'Travel Preferences',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),

        Text(
          'Set your travel preferences to get personalized recommendations and faster booking.',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: Colors.grey.shade600,
          ),
        ),
        SizedBox(height: 4.h),

        // Home Station
        _buildStationSelector(
          title: 'Home Station',
          subtitle: 'Your most frequent starting point',
          icon: Icons.home_outlined,
          selectedStation: _selectedHomeStation,
          onStationChanged: (station) {
            setState(() => _selectedHomeStation = station);
            _updatePreferences();
          },
        ),

        SizedBox(height: 3.h),

        // Work Station
        _buildStationSelector(
          title: 'Work Station',
          subtitle: 'Your usual destination for work',
          icon: Icons.business_outlined,
          selectedStation: _selectedWorkStation,
          onStationChanged: (station) {
            setState(() => _selectedWorkStation = station);
            _updatePreferences();
          },
        ),

        SizedBox(height: 3.h),

        // Language Preference
        _buildLanguageSelector(),

        SizedBox(height: 4.h),

        // Information card
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color:
                AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.3),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.info_outline,
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 20,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Helpful Tips',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      '• These preferences help us suggest the fastest routes\n• You can change these settings anytime in your profile\n• We\'ll show nearby stations for easier selection',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        SizedBox(height: 4.h),

        // Skip option
        Center(
          child: TextButton(
            onPressed: () {
              // Skip this step
            },
            child: Text(
              'Skip for now',
              style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                color: Colors.grey.shade600,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),

        SizedBox(height: 4.h),
      ],
    );
  }

  Widget _buildStationSelector({
    required String title,
    required String subtitle,
    required IconData icon,
    required String? selectedStation,
    required Function(String?) onStationChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon,
                color: AppTheme.lightTheme.colorScheme.primary, size: 20),
            SizedBox(width: 2.w),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        Text(
          subtitle,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: Colors.grey.shade600,
          ),
        ),
        SizedBox(height: 2.h),
        InkWell(
          onTap: () =>
              _showStationPicker(title, selectedStation, onStationChanged),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selectedStation != null
                    ? AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.3)
                    : Colors.grey.shade300,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.train_outlined,
                  color: selectedStation != null
                      ? AppTheme.lightTheme.colorScheme.primary
                      : Colors.grey.shade600,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    selectedStation ?? 'Select a station',
                    style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      color: selectedStation != null
                          ? Colors.black87
                          : Colors.grey.shade600,
                    ),
                  ),
                ),
                Icon(
                  Icons.keyboard_arrow_down,
                  color: Colors.grey.shade600,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLanguageSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.language_outlined,
                color: AppTheme.lightTheme.colorScheme.primary, size: 20),
            SizedBox(width: 2.w),
            Text(
              'Preferred Language',
              style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        Text(
          'Choose your preferred language for notifications and app content',
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: Colors.grey.shade600,
          ),
        ),
        SizedBox(height: 2.h),
        InkWell(
          onTap: () => _showLanguagePicker(),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.3),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.translate,
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    _selectedLanguage ?? 'English',
                    style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      color: Colors.black87,
                    ),
                  ),
                ),
                Icon(
                  Icons.keyboard_arrow_down,
                  color: Colors.grey.shade600,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _showStationPicker(
      String title, String? currentSelection, Function(String?) onChanged) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Container(
              padding: EdgeInsets.all(4.w),
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  SizedBox(height: 3.h),
                  Text(
                    'Select $title',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 2.h),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                itemCount: _stations.length + 1,
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return ListTile(
                      leading: const Icon(Icons.clear),
                      title: const Text('Clear Selection'),
                      onTap: () {
                        onChanged(null);
                        Navigator.pop(context);
                      },
                    );
                  }

                  final station = _stations[index - 1];
                  final isSelected = station == currentSelection;

                  return ListTile(
                    leading: Icon(
                      Icons.train_outlined,
                      color: isSelected
                          ? AppTheme.lightTheme.colorScheme.primary
                          : Colors.grey.shade600,
                    ),
                    title: Text(
                      station,
                      style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                        color: isSelected
                            ? AppTheme.lightTheme.colorScheme.primary
                            : null,
                        fontWeight: isSelected ? FontWeight.w600 : null,
                      ),
                    ),
                    trailing: isSelected
                        ? Icon(
                            Icons.check_circle,
                            color: AppTheme.lightTheme.colorScheme.primary,
                          )
                        : null,
                    onTap: () {
                      onChanged(station);
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLanguagePicker() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        height: 50.h,
        child: Column(
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Select Language',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 2.h),
            Expanded(
              child: ListView.builder(
                itemCount: _languages.length,
                itemBuilder: (context, index) {
                  final language = _languages[index];
                  final isSelected = language == _selectedLanguage;

                  return ListTile(
                    leading: Icon(
                      Icons.translate,
                      color: isSelected
                          ? AppTheme.lightTheme.colorScheme.primary
                          : Colors.grey.shade600,
                    ),
                    title: Text(
                      language,
                      style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                        color: isSelected
                            ? AppTheme.lightTheme.colorScheme.primary
                            : null,
                        fontWeight: isSelected ? FontWeight.w600 : null,
                      ),
                    ),
                    trailing: isSelected
                        ? Icon(
                            Icons.check_circle,
                            color: AppTheme.lightTheme.colorScheme.primary,
                          )
                        : null,
                    onTap: () {
                      setState(() => _selectedLanguage = language);
                      _updatePreferences();
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _updatePreferences() {
    widget.onPreferencesChanged({
      'homeStation': _selectedHomeStation ?? '',
      'workStation': _selectedWorkStation ?? '',
      'preferredLanguage': _selectedLanguage ?? 'English',
    });
  }
}
