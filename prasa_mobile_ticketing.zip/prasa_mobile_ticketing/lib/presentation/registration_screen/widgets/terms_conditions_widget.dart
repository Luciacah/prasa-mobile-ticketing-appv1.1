import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TermsConditionsWidget extends StatelessWidget {
  final bool acceptedTerms;
  final Function(bool) onTermsChanged;

  const TermsConditionsWidget({
    Key? key,
    required this.acceptedTerms,
    required this.onTermsChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 4.h),

        Text(
          'Terms & Privacy Policy',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),

        Text(
          'Please review and accept our terms and privacy policy to continue with your PRASA account registration.',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: Colors.grey.shade600,
          ),
        ),
        SizedBox(height: 4.h),

        // Terms of Service Summary
        _buildTermsSummaryCard(
          icon: Icons.article_outlined,
          title: 'Terms of Service',
          description:
              'Guidelines for using PRASA mobile services, ticket purchasing, and account responsibilities.',
          onTap: () => _showTermsDialog(
              context, 'Terms of Service', _getTermsOfService()),
        ),

        SizedBox(height: 3.h),

        // Privacy Policy Summary
        _buildTermsSummaryCard(
          icon: Icons.privacy_tip_outlined,
          title: 'Privacy Policy',
          description:
              'How we collect, use, and protect your personal information and travel data.',
          onTap: () =>
              _showTermsDialog(context, 'Privacy Policy', _getPrivacyPolicy()),
        ),

        SizedBox(height: 4.h),

        // Acceptance checkbox
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: acceptedTerms
                  ? AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.3)
                  : Colors.grey.shade300,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: acceptedTerms,
                onChanged: (value) => onTermsChanged(value ?? false),
                activeColor: AppTheme.lightTheme.colorScheme.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: RichText(
                  text: TextSpan(
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                    children: [
                      TextSpan(text: 'I agree to the '),
                      TextSpan(
                        text: 'Terms of Service',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.primary,
                          decoration: TextDecoration.underline,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => _showTermsDialog(context,
                              'Terms of Service', _getTermsOfService()),
                      ),
                      TextSpan(text: ' and '),
                      TextSpan(
                        text: 'Privacy Policy',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.primary,
                          decoration: TextDecoration.underline,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => _showTermsDialog(
                              context, 'Privacy Policy', _getPrivacyPolicy()),
                      ),
                      TextSpan(
                          text:
                              '. I understand that my personal information will be processed according to these policies.'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

        SizedBox(height: 6.h),
      ],
    );
  }

  Widget _buildTermsSummaryCard({
    required IconData icon,
    required String title,
    required String description,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade100,
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    description,
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: Colors.grey.shade400,
            ),
          ],
        ),
      ),
    );
  }

  void _showTermsDialog(BuildContext context, String title, String content) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          title,
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: 60.h,
          child: SingleChildScrollView(
            child: Text(
              content,
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Close',
              style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getTermsOfService() {
    return '''
PRASA MOBILE TICKETING TERMS OF SERVICE

1. ACCEPTANCE OF TERMS
By using the PRASA Mobile Ticketing application, you agree to be bound by these Terms of Service and all applicable laws and regulations.

2. ACCOUNT REGISTRATION
- You must provide accurate and complete information during registration
- You are responsible for maintaining the confidentiality of your account credentials
- You must be at least 18 years old to create an account
- One account per person is permitted

3. TICKET PURCHASING AND USAGE
- All ticket purchases are subject to PRASA's current fare structure
- Digital tickets are valid for the specified journey and time period
- Tickets are non-transferable and non-refundable except as specified
- You must present valid identification along with your digital ticket

4. PAYMENT TERMS
- All payments must be made through approved payment methods
- Payment processing fees may apply
- Refunds will be processed according to PRASA's refund policy
- Disputed charges must be reported within 30 days

5. USER CONDUCT
- You agree not to use the service for any unlawful or prohibited purpose
- Fraudulent activity will result in account termination and legal action
- You must not attempt to circumvent fare payment systems
- Sharing account credentials is strictly prohibited

6. SERVICE AVAILABILITY
- PRASA strives to maintain service availability but does not guarantee uninterrupted service
- Scheduled maintenance may temporarily affect service availability
- Real-time information is provided as available and may be subject to delays

7. INTELLECTUAL PROPERTY
- All content and materials in the app are owned by PRASA or licensed to PRASA
- You may not reproduce, distribute, or create derivative works without permission
- PRASA trademarks and logos may not be used without authorization

8. LIMITATION OF LIABILITY
- PRASA's liability is limited to the amount paid for services
- We are not liable for indirect, consequential, or punitive damages
- Force majeure events may affect service without compensation

9. PRIVACY AND DATA PROTECTION
- Your personal information is protected according to our Privacy Policy
- We collect and use data to provide and improve our services
- Location data may be collected to enhance service delivery

10. MODIFICATIONS TO TERMS
- These terms may be updated periodically
- Continued use of the service constitutes acceptance of updated terms
- Material changes will be communicated through the app

11. TERMINATION
- Either party may terminate the account at any time
- PRASA may suspend accounts for violation of these terms
- Upon termination, access to digital tickets and services will be revoked

12. GOVERNING LAW
- These terms are governed by South African law
- Disputes will be resolved in South African courts
- Arbitration may be required for certain disputes

Contact Information:
PRASA Customer Service
Email: support@prasa.com
Phone: +27 11 773 9000

Last Updated: November 2025
''';
  }

  String _getPrivacyPolicy() {
    return '''
PRASA MOBILE TICKETING PRIVACY POLICY

1. INFORMATION WE COLLECT
We collect information that you provide directly to us, including:
- Personal identification information (name, email, phone number, date of birth)
- Payment information (credit card details, billing address)
- Travel preferences and history
- Location data (with your permission)
- Device information and usage data

2. HOW WE USE YOUR INFORMATION
Your information is used to:
- Process ticket purchases and payments
- Provide personalized travel recommendations
- Send service notifications and updates
- Improve our services and user experience
- Comply with legal and regulatory requirements
- Prevent fraud and enhance security

3. INFORMATION SHARING
We may share your information with:
- Payment processors for transaction handling
- Third-party service providers who assist in operations
- Law enforcement when required by law
- PRASA affiliates and partners for service delivery
We never sell your personal information to third parties.

4. DATA SECURITY
We implement industry-standard security measures including:
- Encryption of sensitive data in transit and at rest
- Regular security audits and assessments
- Access controls and employee training
- Secure payment processing systems
- Multi-factor authentication options

5. YOUR RIGHTS
You have the right to:
- Access your personal information
- Correct inaccurate information
- Request deletion of your data
- Withdraw consent for data processing
- Receive a copy of your data
- File complaints with data protection authorities

6. LOCATION SERVICES
Location data is collected to:
- Provide nearby station information
- Offer location-based services and notifications
- Improve route planning and recommendations
You can disable location services in your device settings.

7. COOKIES AND TRACKING
We use cookies and similar technologies to:
- Remember your preferences and settings
- Analyze app usage and performance
- Provide personalized content
- Ensure security and prevent fraud

8. DATA RETENTION
We retain your information for:
- Active accounts: Duration of account plus 7 years
- Transaction records: 7 years for tax and audit purposes
- Marketing preferences: Until you opt out
- Technical logs: 2 years for security and troubleshooting

9. INTERNATIONAL TRANSFERS
Your data may be transferred to and processed in countries other than South Africa. We ensure adequate protection through:
- Standard contractual clauses
- Adequacy decisions by regulators
- Your explicit consent when required

10. CHILDREN'S PRIVACY
Our service is not intended for children under 18. We do not knowingly collect personal information from children without parental consent.

11. CHANGES TO THIS POLICY
We may update this privacy policy to reflect changes in:
- Our information practices
- Legal requirements
- Service offerings
We will notify you of material changes through the app or email.

12. CONTACT US
For privacy-related questions or concerns:
Privacy Officer
PRASA
Email: privacy@prasa.com
Phone: +27 11 773 9000
Address: PRASA House, 1321 Paul Kruger St, Hatfield, Pretoria

Your privacy is important to us, and we are committed to protecting your personal information while providing excellent transportation services.

Last Updated: November 2025
''';
  }
}
