import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/app_export.dart';
import '../../services/supabase_auth_service.dart';
import '../login_screen/widgets/prasa_logo_widget.dart';
import '../login_screen/widgets/social_login_widget.dart';
import './widgets/profile_photo_widget.dart';
import './widgets/registration_form_widget.dart';
import './widgets/terms_conditions_widget.dart';
import './widgets/travel_preferences_setup_widget.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({Key? key}) : super(key: key);

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  int _currentStep = 0;
  bool _isLoading = false;
  String? _errorMessage;

  // Form data
  final Map<String, dynamic> _registrationData = {
    'fullName': '',
    'email': '',
    'phone': '',
    'dateOfBirth': '',
    'password': '',
    'confirmPassword': '',
    'acceptedTerms': false,
    'profilePhotoPath': null,
    'homeStation': '',
    'workStation': '',
    'preferredLanguage': 'English',
  };

  final List<String> _stepTitles = [
    'Personal Information',
    'Security Setup',
    'Terms & Privacy',
    'Profile Photo',
    'Travel Preferences',
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _handleRegistration() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Validate current step
      if (!_validateCurrentStep()) {
        setState(() => _isLoading = false);
        return;
      }

      // Create account with Supabase
      final AuthResponse? response =
          await SupabaseAuthService.instance.signUpWithEmailAndPassword(
        email: _registrationData['email'],
        password: _registrationData['password'],
        userData: {
          'full_name': _registrationData['fullName'],
          'phone': _registrationData['phone'],
          'date_of_birth': _registrationData['dateOfBirth'],
          'home_station': _registrationData['homeStation'],
          'work_station': _registrationData['workStation'],
          'preferred_language':
              _registrationData['preferredLanguage'].toLowerCase(),
          'avatar_url': _registrationData['profilePhotoPath'] ?? '',
        },
      );

      if (response != null && response.user != null) {
        // Success - show welcome animation
        if (mounted) {
          HapticFeedback.lightImpact();
          _showSuccessDialog();
        }
      } else {
        throw Exception('Registration failed');
      }
    } catch (e) {
      if (mounted) {
        HapticFeedback.heavyImpact();
        setState(() {
          _errorMessage = e.toString();
        });

        Fluttertoast.showToast(
          msg: "Registration failed. Please try again.",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
          textColor: AppTheme.lightTheme.colorScheme.onError,
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  bool _validateCurrentStep() {
    switch (_currentStep) {
      case 0: // Personal Information
        return _registrationData['fullName'].isNotEmpty &&
            _registrationData['email'].isNotEmpty &&
            _registrationData['phone'].isNotEmpty &&
            _registrationData['dateOfBirth'].isNotEmpty;
      case 1: // Security Setup
        return _registrationData['password'].isNotEmpty &&
            _registrationData['confirmPassword'].isNotEmpty &&
            _registrationData['password'] ==
                _registrationData['confirmPassword'];
      case 2: // Terms & Privacy
        return _registrationData['acceptedTerms'] == true;
      case 3: // Profile Photo (optional)
        return true;
      case 4: // Travel Preferences (optional)
        return true;
      default:
        return false;
    }
  }

  void _nextStep() {
    if (_validateCurrentStep() && _currentStep < _stepTitles.length - 1) {
      setState(() => _currentStep++);
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      HapticFeedback.lightImpact();
    } else if (_currentStep == _stepTitles.length - 1) {
      _handleRegistration();
    } else {
      _showValidationError();
    }
  }

  void _previousStep() {
    if (_currentStep > 0) {
      setState(() => _currentStep--);
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      HapticFeedback.lightImpact();
    }
  }

  void _showValidationError() {
    HapticFeedback.heavyImpact();
    Fluttertoast.showToast(
      msg: "Please fill in all required fields",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.lightTheme.colorScheme.error,
      textColor: AppTheme.lightTheme.colorScheme.onError,
    );
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.tertiary,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.check,
                color: AppTheme.lightTheme.colorScheme.onTertiary,
                size: 32,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Welcome to PRASA!',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        content: Text(
          'Your account has been created successfully. Please check your email to verify your account.',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
          textAlign: TextAlign.center,
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushReplacementNamed(context, AppRoutes.login);
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 3.h),
                backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              ),
              child: Text(
                'Continue to Login',
                style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onPrimary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleSocialRegistration(String provider) async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      AuthResponse? result;

      switch (provider.toLowerCase()) {
        case 'google':
          result = await SupabaseAuthService.instance.signInWithGoogle();
          break;
        case 'apple':
          result = await SupabaseAuthService.instance.signInWithApple();
          break;
        default:
          throw Exception(
              'Unsupported social registration provider: $provider');
      }

      if (result != null && result.user != null) {
        if (mounted) {
          HapticFeedback.lightImpact();

          Fluttertoast.showToast(
            msg: "$provider registration successful!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
            textColor: AppTheme.lightTheme.colorScheme.onTertiary,
          );

          _showSuccessDialog();
        }
      }
    } catch (e) {
      if (mounted) {
        HapticFeedback.heavyImpact();
        setState(() {
          _errorMessage = e.toString();
        });

        Fluttertoast.showToast(
          msg: "$provider registration failed. Please try again.",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
          textColor: AppTheme.lightTheme.colorScheme.onError,
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            children: [
              // Header with progress
              _buildHeader(),

              // Error message display
              if (_errorMessage != null) _buildErrorMessage(),

              // Page content
              Expanded(
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    _buildPersonalInfoStep(),
                    _buildSecurityStep(),
                    _buildTermsStep(),
                    _buildProfilePhotoStep(),
                    _buildTravelPreferencesStep(),
                  ],
                ),
              ),

              // Social registration (show only on first step)
              if (_currentStep == 0) _buildSocialRegistration(),

              // Navigation buttons
              _buildNavigationButtons(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: _currentStep > 0
                    ? _previousStep
                    : () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back),
              ),
              const Spacer(),
              const PrasaLogoWidget(),
              const Spacer(),
              SizedBox(width: 48), // Balance the back button
            ],
          ),
          SizedBox(height: 3.h),

          // Progress indicator
          Container(
            height: 4,
            child: LinearProgressIndicator(
              value: (_currentStep + 1) / _stepTitles.length,
              backgroundColor: Colors.grey.shade300,
              valueColor: AlwaysStoppedAnimation<Color>(
                AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
          ),
          SizedBox(height: 2.h),

          Text(
            _stepTitles[_currentStep],
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),

          Text(
            'Step ${_currentStep + 1} of ${_stepTitles.length}',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorMessage() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.error_outline,
            color: AppTheme.lightTheme.colorScheme.error,
            size: 20,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Text(
              _errorMessage!,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.error,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalInfoStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: RegistrationFormWidget(
        registrationData: _registrationData,
        onDataChanged: (data) => setState(() => _registrationData.addAll(data)),
      ),
    );
  }

  Widget _buildSecurityStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 4.h),
          Text(
            'Create a secure password',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),

          // Password field with strength indicator
          _buildPasswordField(),
          SizedBox(height: 3.h),

          // Confirm password field
          _buildConfirmPasswordField(),
        ],
      ),
    );
  }

  Widget _buildTermsStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: TermsConditionsWidget(
        acceptedTerms: _registrationData['acceptedTerms'],
        onTermsChanged: (accepted) =>
            setState(() => _registrationData['acceptedTerms'] = accepted),
      ),
    );
  }

  Widget _buildProfilePhotoStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: ProfilePhotoWidget(
        profilePhotoPath: _registrationData['profilePhotoPath'],
        onPhotoChanged: (path) =>
            setState(() => _registrationData['profilePhotoPath'] = path),
      ),
    );
  }

  Widget _buildTravelPreferencesStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: TravelPreferencesSetupWidget(
        homeStation: _registrationData['homeStation'],
        workStation: _registrationData['workStation'],
        preferredLanguage: _registrationData['preferredLanguage'],
        onPreferencesChanged: (preferences) =>
            setState(() => _registrationData.addAll(preferences)),
      ),
    );
  }

  Widget _buildPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          obscureText: true,
          onChanged: (value) =>
              setState(() => _registrationData['password'] = value),
          decoration: InputDecoration(
            labelText: 'Password',
            prefixIcon: Icon(Icons.lock_outline),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            filled: true,
            fillColor: Colors.grey.shade50,
          ),
        ),
        SizedBox(height: 1.h),

        // Password strength indicator
        _buildPasswordStrengthIndicator(),
      ],
    );
  }

  Widget _buildConfirmPasswordField() {
    return TextFormField(
      obscureText: true,
      onChanged: (value) =>
          setState(() => _registrationData['confirmPassword'] = value),
      decoration: InputDecoration(
        labelText: 'Confirm Password',
        prefixIcon: Icon(Icons.lock_outline),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
        errorText: _registrationData['confirmPassword'].isNotEmpty &&
                _registrationData['password'] !=
                    _registrationData['confirmPassword']
            ? 'Passwords do not match'
            : null,
      ),
    );
  }

  Widget _buildPasswordStrengthIndicator() {
    String password = _registrationData['password'];
    int strength = _calculatePasswordStrength(password);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Container(
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: strength / 4,
                  child: Container(
                    decoration: BoxDecoration(
                      color: _getStrengthColor(strength),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(width: 2.w),
            Text(
              _getStrengthText(strength),
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: _getStrengthColor(strength),
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        Text(
          'Password must contain: uppercase, lowercase, number, and special character',
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  int _calculatePasswordStrength(String password) {
    int strength = 0;
    if (password.length >= 8) strength++;
    if (password.contains(RegExp(r'[A-Z]'))) strength++;
    if (password.contains(RegExp(r'[a-z]'))) strength++;
    if (password.contains(RegExp(r'[0-9]'))) strength++;
    if (password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) strength++;
    return strength > 4 ? 4 : strength;
  }

  Color _getStrengthColor(int strength) {
    switch (strength) {
      case 0:
      case 1:
        return Colors.red;
      case 2:
        return Colors.orange;
      case 3:
        return Colors.yellow.shade700;
      case 4:
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getStrengthText(int strength) {
    switch (strength) {
      case 0:
      case 1:
        return 'Weak';
      case 2:
        return 'Fair';
      case 3:
        return 'Good';
      case 4:
        return 'Strong';
      default:
        return 'Very Weak';
    }
  }

  Widget _buildSocialRegistration() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: Divider()),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                child: Text(
                  'Or register with',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                  ),
                ),
              ),
              Expanded(child: Divider()),
            ],
          ),
          SizedBox(height: 3.h),
          SocialLoginWidget(
            onSocialLogin: _handleSocialRegistration,
            isLoading: _isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Container(
      padding: EdgeInsets.all(6.w),
      child: Row(
        children: [
          if (_currentStep > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: _isLoading ? null : _previousStep,
                style: OutlinedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  side: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.primary),
                ),
                child: Text(
                  'Previous',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.primary,
                  ),
                ),
              ),
            ),
          if (_currentStep > 0) SizedBox(width: 4.w),
          Expanded(
            flex: _currentStep > 0 ? 1 : 2,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _nextStep,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 3.h),
                backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              ),
              child: _isLoading
                  ? SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.lightTheme.colorScheme.onPrimary,
                        ),
                      ),
                    )
                  : Text(
                      _currentStep == _stepTitles.length - 1
                          ? 'Create Account'
                          : 'Next',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onPrimary,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
