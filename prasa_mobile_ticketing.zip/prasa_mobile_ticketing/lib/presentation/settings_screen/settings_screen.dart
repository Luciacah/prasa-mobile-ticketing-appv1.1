import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/app_export.dart';
import './widgets/account_settings_widget.dart';
import './widgets/advanced_settings_widget.dart';
import './widgets/app_preferences_widget.dart';
import './widgets/data_storage_widget.dart';
import './widgets/notification_settings_widget.dart';
import './widgets/privacy_security_widget.dart';
import './widgets/support_section_widget.dart';
import './widgets/travel_settings_widget.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final User? _currentUser = Supabase.instance.client.auth.currentUser;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  bool _isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    // Load user settings from Supabase or SharedPreferences
    try {
      // Example: Load theme preference
      // final isDark = await SharedPreferences.getInstance().then((prefs) => prefs.getBool('isDarkMode') ?? false);
      // setState(() => _isDarkMode = isDark);
    } catch (e) {
      debugPrint('Error loading settings: $e');
    }
  }

  List<Widget> _getFilteredSettings() {
    final allSettings = [
      const AccountSettingsWidget(),
      const NotificationSettingsWidget(),
      const PrivacySecurityWidget(),
      const AppPreferencesWidget(),
      const TravelSettingsWidget(),
      const DataStorageWidget(),
      const SupportSectionWidget(),
      const AdvancedSettingsWidget(),
    ];

    if (_searchQuery.isEmpty) {
      return allSettings;
    }

    // In a real implementation, you would filter based on setting titles and content
    return allSettings;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Settings',
          style: GoogleFonts.inter(
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      body: Column(
        children: [
          // Search functionality
          Container(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() => _searchQuery = value.toLowerCase());
              },
              decoration: InputDecoration(
                hintText: 'Search settings...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
              ),
            ),
          ),

          // Settings list
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: _getFilteredSettings()
                  .map((widget) => Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: widget,
                      ))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}
