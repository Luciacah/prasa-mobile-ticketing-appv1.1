import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class AppPreferencesWidget extends StatefulWidget {
  const AppPreferencesWidget({super.key});

  @override
  State<AppPreferencesWidget> createState() => _AppPreferencesWidgetState();
}

class _AppPreferencesWidgetState extends State<AppPreferencesWidget> {
  String _selectedTheme = 'System';
  String _selectedLanguage = 'English';
  double _textSize = 1.0;
  bool _highContrast = false;
  bool _hapticFeedback = true;
  bool _soundEffects = true;

  final List<String> _themes = ['Light', 'Dark', 'System'];
  final List<String> _languages = [
    'English',
    'Afrikaans',
    'Zulu',
    'Xhosa',
    'Sotho',
    'Tswana',
    'Venda',
    'Tsonga',
    'Ndebele',
    'Swati',
    'Pedi',
  ];

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'App Preferences',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 16),

            // Theme Selection
            _buildSectionTitle('Appearance'),
            const SizedBox(height: 12),

            _buildDropdownOption(
              icon: Icons.palette,
              title: 'Theme',
              subtitle: 'Choose your preferred theme',
              value: _selectedTheme,
              items: _themes,
              onChanged: (value) => setState(() => _selectedTheme = value!),
            ),

            const SizedBox(height: 16),

            // Language Selection
            _buildDropdownOption(
              icon: Icons.language,
              title: 'Language',
              subtitle: 'Select your preferred language',
              value: _selectedLanguage,
              items: _languages,
              onChanged: (value) => setState(() => _selectedLanguage = value!),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Accessibility Options
            _buildSectionTitle('Accessibility'),
            const SizedBox(height: 12),

            // Text Size
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor.withAlpha(26),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.format_size,
                        color: Theme.of(context).primaryColor,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Text Size',
                            style: GoogleFonts.inter(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Adjust text size for better readability',
                            style: GoogleFonts.inter(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text(
                      'A',
                      style: GoogleFonts.inter(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Expanded(
                      child: Slider(
                        value: _textSize,
                        min: 0.8,
                        max: 1.4,
                        divisions: 6,
                        onChanged: (value) => setState(() => _textSize = value),
                      ),
                    ),
                    Text(
                      'A',
                      style: GoogleFonts.inter(
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Center(
                  child: Text(
                    'Sample text at ${(_textSize * 100).toInt()}% size',
                    style: GoogleFonts.inter(
                      fontSize: 16 * _textSize,
                      color: Colors.grey[600],
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // High Contrast
            _buildToggleOption(
              icon: Icons.contrast,
              title: 'High Contrast',
              subtitle: 'Increase contrast for better visibility',
              value: _highContrast,
              onChanged: (value) => setState(() => _highContrast = value),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Interaction Options
            _buildSectionTitle('Interaction'),
            const SizedBox(height: 12),

            _buildToggleOption(
              icon: Icons.vibration,
              title: 'Haptic Feedback',
              subtitle: 'Feel vibrations for app interactions',
              value: _hapticFeedback,
              onChanged: (value) => setState(() => _hapticFeedback = value),
            ),

            const SizedBox(height: 16),

            _buildToggleOption(
              icon: Icons.volume_up,
              title: 'Sound Effects',
              subtitle: 'Play sounds for app actions',
              value: _soundEffects,
              onChanged: (value) => setState(() => _soundEffects = value),
            ),

            const SizedBox(height: 20),

            // Reset to Defaults
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _resetToDefaults,
                icon: const Icon(Icons.refresh),
                label: const Text('Reset to Defaults'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.inter(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: Colors.grey[700],
      ),
    );
  }

  Widget _buildDropdownOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButton<String>(
                  value: value,
                  isExpanded: true,
                  underline: const SizedBox(),
                  onChanged: onChanged,
                  items: items.map<DropdownMenuItem<String>>((String item) {
                    return DropdownMenuItem<String>(
                      value: item,
                      child: Text(item),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildToggleOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
        ),
      ],
    );
  }

  void _resetToDefaults() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Reset to Defaults',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: Text(
          'This will reset all app preferences to their default values. Are you sure you want to continue?',
          style: GoogleFonts.inter(fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _selectedTheme = 'System';
                _selectedLanguage = 'English';
                _textSize = 1.0;
                _highContrast = false;
                _hapticFeedback = true;
                _soundEffects = true;
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Preferences reset to defaults')),
              );
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }
}
