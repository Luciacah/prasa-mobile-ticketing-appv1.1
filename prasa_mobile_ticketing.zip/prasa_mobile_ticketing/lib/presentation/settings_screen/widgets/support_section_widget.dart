import 'package:flutter/material.dart';

import '../../../core/app_export.dart';

class SupportSectionWidget extends StatelessWidget {
  const SupportSectionWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Support',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 16),

            // FAQ
            _buildSupportItem(
              context,
              icon: Icons.help_outline,
              title: 'Frequently Asked Questions',
              subtitle: 'Find answers to common questions',
              onTap: () => _showFAQ(context),
            ),

            const Divider(height: 24),

            // Contact Support
            _buildSupportItem(
              context,
              icon: Icons.support_agent,
              title: 'Contact Support',
              subtitle: 'Get help from our support team',
              onTap: () => _contactSupport(context),
            ),

            const Divider(height: 24),

            // Live Chat
            _buildSupportItem(
              context,
              icon: Icons.chat,
              title: 'Live Chat',
              subtitle: 'Chat with our support agents',
              onTap: () => _openLiveChat(context),
            ),

            const Divider(height: 24),

            // Report Issue
            _buildSupportItem(
              context,
              icon: Icons.bug_report,
              title: 'Report an Issue',
              subtitle: 'Report bugs or technical problems',
              onTap: () => _reportIssue(context),
            ),

            const Divider(height: 24),

            // Send Feedback
            _buildSupportItem(
              context,
              icon: Icons.feedback,
              title: 'Send Feedback',
              subtitle: 'Share your thoughts and suggestions',
              onTap: () => _sendFeedback(context),
            ),

            const SizedBox(height: 20),

            // App Information
            _buildAppInfo(context),
          ],
        ),
      ),
    );
  }

  Widget _buildSupportItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withAlpha(26),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: Theme.of(context).primaryColor,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Icon(
            Icons.arrow_forward_ios,
            size: 16,
            color: Colors.grey[400],
          ),
        ],
      ),
    );
  }

  Widget _buildAppInfo(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.withAlpha(13),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey.withAlpha(51),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'App Information',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          _buildInfoRow('Version', '1.0.0+1'),
          const SizedBox(height: 8),
          _buildInfoRow('Build Number', '100'),
          const SizedBox(height: 8),
          _buildInfoRow('Last Updated', 'November 16, 2025'),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _checkForUpdates(context),
                  icon: const Icon(Icons.system_update),
                  label: const Text('Check Updates'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _viewChangelog(context),
                  icon: const Icon(Icons.history),
                  label: const Text('Changelog'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  void _showFAQ(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.95,
        minChildSize: 0.5,
        builder: (context, scrollController) => Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Text(
                'Frequently Asked Questions',
                style: GoogleFonts.inter(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: ListView(
                  controller: scrollController,
                  children: [
                    _buildFAQItem(
                      'How do I purchase a ticket?',
                      'You can purchase tickets through the app by selecting your departure and arrival stations, choosing your preferred time, and completing the payment process.',
                    ),
                    _buildFAQItem(
                      'Can I cancel or refund my ticket?',
                      'Tickets can be cancelled up to 2 hours before departure for a full refund. After that, cancellation fees may apply.',
                    ),
                    _buildFAQItem(
                      'What payment methods are accepted?',
                      'We accept credit cards, debit cards, mobile money, and PRASA Wallet payments.',
                    ),
                    _buildFAQItem(
                      'How do I use my mobile ticket?',
                      'Show your mobile ticket or QR code to the conductor when boarding the train.',
                    ),
                    _buildFAQItem(
                      'What if my train is delayed?',
                      'You\'ll receive real-time notifications about delays. If the delay is more than 30 minutes, you\'re eligible for a partial refund.',
                    ),
                    _buildFAQItem(
                      'How do I contact customer support?',
                      'You can reach us through live chat, email (support@prasa.com), or phone (+27 11 773 9000).',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFAQItem(String question, String answer) {
    return ExpansionTile(
      title: Text(
        question,
        style: GoogleFonts.inter(
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            answer,
            style: GoogleFonts.inter(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
        ),
      ],
    );
  }

  void _contactSupport(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Contact Support',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 20),
            _buildContactOption(
              icon: Icons.phone,
              title: 'Phone Support',
              subtitle: '+27 11 773 9000',
              description: 'Available 24/7',
              onTap: () {
                Navigator.pop(context);
                // Launch phone dialer
              },
            ),
            const SizedBox(height: 16),
            _buildContactOption(
              icon: Icons.email,
              title: 'Email Support',
              subtitle: 'support@prasa.com',
              description: 'Response within 24 hours',
              onTap: () {
                Navigator.pop(context);
                // Launch email client
              },
            ),
            const SizedBox(height: 16),
            _buildContactOption(
              icon: Icons.location_on,
              title: 'Visit Office',
              subtitle: 'PRASA House, Johannesburg',
              description: 'Mon-Fri 8AM-5PM',
              onTap: () {
                Navigator.pop(context);
                // Open maps
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required String description,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey[300]!),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, size: 24, color: Colors.blue),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.inter(fontSize: 14),
                  ),
                  Text(
                    description,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 16),
          ],
        ),
      ),
    );
  }

  void _openLiveChat(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.aiChatSupport);
  }

  void _reportIssue(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Issue reporting form - Coming soon')),
    );
  }

  void _sendFeedback(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Feedback form - Coming soon')),
    );
  }

  void _checkForUpdates(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('You\'re using the latest version')),
    );
  }

  void _viewChangelog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'What\'s New',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Version 1.0.0',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '• Initial release of PRASA Mobile Ticketing\n• Purchase and manage train tickets\n• Real-time journey tracking\n• AI-powered customer support\n• Biometric authentication\n• Offline map support',
                style: GoogleFonts.inter(fontSize: 14),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
