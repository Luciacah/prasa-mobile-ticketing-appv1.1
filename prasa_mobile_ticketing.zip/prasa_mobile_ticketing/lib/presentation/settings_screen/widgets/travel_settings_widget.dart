import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class TravelSettingsWidget extends StatefulWidget {
  const TravelSettingsWidget({super.key});

  @override
  State<TravelSettingsWidget> createState() => _TravelSettingsWidgetState();
}

class _TravelSettingsWidgetState extends State<TravelSettingsWidget> {
  String _defaultPaymentMethod = 'Credit Card (**** 1234)';
  bool _autoBooking = false;
  String _preferredClass = 'Economy';
  String _preferredSeating = 'Window';
  bool _quickBooking = true;
  int _bookingReminder = 15; // minutes before departure

  final List<String> _paymentMethods = [
    'Credit Card (**** 1234)',
    'Debit Card (**** 5678)',
    'PRASA Wallet',
    'Mobile Money',
  ];

  final List<String> _travelClasses = [
    'Economy',
    'Business',
    'First Class',
  ];

  final List<String> _seatingPreferences = [
    'No preference',
    'Window',
    'Aisle',
    'Table seat',
  ];

  final List<int> _reminderOptions = [5, 10, 15, 30, 60]; // minutes

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Travel Settings',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 16),

            // Default Payment Method
            _buildSectionTitle('Payment & Booking'),
            const SizedBox(height: 12),

            _buildDropdownSetting(
              icon: Icons.payment,
              title: 'Default Payment Method',
              subtitle: 'Choose your preferred payment option',
              value: _defaultPaymentMethod,
              items: _paymentMethods,
              onChanged: (value) =>
                  setState(() => _defaultPaymentMethod = value!),
            ),

            const SizedBox(height: 16),

            // Auto-booking
            _buildToggleSetting(
              icon: Icons.auto_awesome,
              title: 'Auto-booking',
              subtitle: 'Automatically book recurring journeys',
              value: _autoBooking,
              onChanged: (value) => setState(() => _autoBooking = value),
            ),

            const SizedBox(height: 16),

            // Quick Booking
            _buildToggleSetting(
              icon: Icons.flash_on,
              title: 'Quick Booking',
              subtitle: 'Skip confirmation for familiar routes',
              value: _quickBooking,
              onChanged: (value) => setState(() => _quickBooking = value),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Journey Preferences
            _buildSectionTitle('Journey Preferences'),
            const SizedBox(height: 12),

            _buildDropdownSetting(
              icon: Icons.airline_seat_recline_normal,
              title: 'Preferred Class',
              subtitle: 'Default travel class selection',
              value: _preferredClass,
              items: _travelClasses,
              onChanged: (value) => setState(() => _preferredClass = value!),
            ),

            const SizedBox(height: 16),

            _buildDropdownSetting(
              icon: Icons.event_seat,
              title: 'Seating Preference',
              subtitle: 'Your preferred seat type',
              value: _preferredSeating,
              items: _seatingPreferences,
              onChanged: (value) => setState(() => _preferredSeating = value!),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Reminders
            _buildSectionTitle('Reminders'),
            const SizedBox(height: 12),

            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withAlpha(26),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.schedule,
                    color: Theme.of(context).primaryColor,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Booking Reminder',
                        style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Remind me $_bookingReminder minutes before departure',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: _reminderOptions.map((minutes) {
                          return ChoiceChip(
                            label: Text('${minutes}m'),
                            selected: _bookingReminder == minutes,
                            onSelected: (selected) {
                              if (selected) {
                                setState(() => _bookingReminder = minutes);
                              }
                            },
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Route Planning
            _buildSectionTitle('Route Planning'),
            const SizedBox(height: 12),

            _buildActionItem(
              icon: Icons.route,
              title: 'Manage Favorite Routes',
              subtitle: 'Add, edit, or remove saved routes',
              onTap: () => _manageFavoriteRoutes(context),
            ),

            const SizedBox(height: 12),

            _buildActionItem(
              icon: Icons.history,
              title: 'Clear Journey History',
              subtitle: 'Remove all previous journey records',
              onTap: () => _clearJourneyHistory(context),
              isDangerous: true,
            ),

            const SizedBox(height: 20),

            // Export Settings
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _exportTravelSettings,
                icon: const Icon(Icons.download),
                label: const Text('Export Travel Settings'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.inter(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: Colors.grey[700],
      ),
    );
  }

  Widget _buildDropdownSetting({
    required IconData icon,
    required String title,
    required String subtitle,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButton<String>(
                  value: value,
                  isExpanded: true,
                  underline: const SizedBox(),
                  onChanged: onChanged,
                  items: items.map<DropdownMenuItem<String>>((String item) {
                    return DropdownMenuItem<String>(
                      value: item,
                      child: Text(item),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildToggleSetting({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildActionItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isDangerous = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isDangerous
                  ? Colors.red.withAlpha(26)
                  : Colors.grey.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: isDangerous ? Colors.red : Colors.grey[700],
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: isDangerous ? Colors.red : null,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios,
            color: Colors.grey[400],
            size: 16,
          ),
        ],
      ),
    );
  }

  void _manageFavoriteRoutes(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Favorite routes management - Coming soon')),
    );
  }

  void _clearJourneyHistory(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Clear Journey History',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            color: Colors.red,
          ),
        ),
        content: Text(
          'This will permanently delete all your journey history. This action cannot be undone.',
          style: GoogleFonts.inter(fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Journey history cleared')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Clear History'),
          ),
        ],
      ),
    );
  }

  void _exportTravelSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Travel settings exported to downloads')),
    );
  }
}
