import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class DataStorageWidget extends StatefulWidget {
  const DataStorageWidget({super.key});

  @override
  State<DataStorageWidget> createState() => _DataStorageWidgetState();
}

class _DataStorageWidgetState extends State<DataStorageWidget> {
  bool _offlineMaps = true;
  bool _cacheImages = true;
  bool _autoCleanup = false;
  double _totalStorageUsed = 245.8; // MB
  double _appDataSize = 89.2;
  double _cacheSize = 156.6;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Data & Storage',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 16),

            // Storage Usage Overview
            _buildStorageOverview(),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Storage Options
            Text(
              'Storage Options',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildStorageOption(
              icon: Icons.map,
              title: 'Download Offline Maps',
              subtitle: 'Save maps for offline use (${_calculateMapSize()})',
              value: _offlineMaps,
              onChanged: (value) => setState(() => _offlineMaps = value),
            ),

            const SizedBox(height: 16),

            _buildStorageOption(
              icon: Icons.image,
              title: 'Cache Images',
              subtitle: 'Store images locally for faster loading',
              value: _cacheImages,
              onChanged: (value) => setState(() => _cacheImages = value),
            ),

            const SizedBox(height: 16),

            _buildStorageOption(
              icon: Icons.auto_delete,
              title: 'Auto Cleanup',
              subtitle: 'Automatically clean old cache files',
              value: _autoCleanup,
              onChanged: (value) => setState(() => _autoCleanup = value),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Cache Management
            Text(
              'Cache Management',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildCacheItem(
              icon: Icons.cached,
              title: 'App Cache',
              size: '${_cacheSize.toStringAsFixed(1)} MB',
              description: 'Temporary files and cached data',
              onClear: () => _clearCache('app'),
            ),

            const SizedBox(height: 12),

            _buildCacheItem(
              icon: Icons.image_outlined,
              title: 'Image Cache',
              size: '${(_cacheSize * 0.6).toStringAsFixed(1)} MB',
              description: 'Cached route and station images',
              onClear: () => _clearCache('images'),
            ),

            const SizedBox(height: 12),

            _buildCacheItem(
              icon: Icons.map_outlined,
              title: 'Map Cache',
              size: '${(_cacheSize * 0.4).toStringAsFixed(1)} MB',
              description: 'Offline map tiles and data',
              onClear: () => _clearCache('maps'),
            ),

            const SizedBox(height: 20),

            // Storage Actions
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _clearAllCache,
                    icon: const Icon(Icons.delete_sweep),
                    label: const Text('Clear All Cache'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.orange,
                      side: const BorderSide(color: Colors.orange),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _manageDownloads,
                    icon: const Icon(Icons.download),
                    label: const Text('Manage Downloads'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStorageOverview() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor.withAlpha(13),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).primaryColor.withAlpha(26),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Storage Used',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${_totalStorageUsed.toStringAsFixed(1)} MB',
                style: GoogleFonts.inter(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).primaryColor,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Storage breakdown
          Column(
            children: [
              _buildStorageBar('App Data', _appDataSize, Colors.blue),
              const SizedBox(height: 8),
              _buildStorageBar('Cache', _cacheSize, Colors.orange),
            ],
          ),

          const SizedBox(height: 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStorageLegend('App Data', Colors.blue, _appDataSize),
              _buildStorageLegend('Cache', Colors.orange, _cacheSize),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStorageBar(String label, double size, Color color) {
    final percentage = size / _totalStorageUsed;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: GoogleFonts.inter(fontSize: 14),
            ),
            Text(
              '${size.toStringAsFixed(1)} MB',
              style:
                  GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500),
            ),
          ],
        ),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: percentage,
          backgroundColor: Colors.grey[200],
          valueColor: AlwaysStoppedAnimation<Color>(color),
        ),
      ],
    );
  }

  Widget _buildStorageLegend(String label, Color color, double size) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          '$label (${size.toStringAsFixed(1)} MB)',
          style: GoogleFonts.inter(fontSize: 12, color: Colors.grey[600]),
        ),
      ],
    );
  }

  Widget _buildStorageOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildCacheItem({
    required IconData icon,
    required String title,
    required String size,
    required String description,
    required VoidCallback onClear,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.grey[600],
            size: 24,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      size,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          TextButton(
            onPressed: onClear,
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  String _calculateMapSize() {
    return _offlineMaps ? '45.2 MB' : '0 MB';
  }

  void _clearCache(String type) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Clear ${type.substring(0, 1).toUpperCase()}${type.substring(1)} Cache',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: Text(
          'This will clear all cached ${type} data. The data will be re-downloaded when needed.',
          style: GoogleFonts.inter(fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                switch (type) {
                  case 'app':
                    _cacheSize *= 0.4; // Reduce cache size
                    break;
                  case 'images':
                    _cacheSize *= 0.7;
                    break;
                  case 'maps':
                    _cacheSize *= 0.8;
                    break;
                }
                _totalStorageUsed = _appDataSize + _cacheSize;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                    content: Text(
                        '${type.substring(0, 1).toUpperCase()}${type.substring(1)} cache cleared')),
              );
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _clearAllCache() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Clear All Cache',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            color: Colors.orange,
          ),
        ),
        content: Text(
          'This will clear all cached data including images, maps, and temporary files. Are you sure?',
          style: GoogleFonts.inter(fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _cacheSize = 0;
                _totalStorageUsed = _appDataSize;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('All cache cleared successfully')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }

  void _manageDownloads() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Download management - Coming soon')),
    );
  }
}
