import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class NotificationSettingsWidget extends StatefulWidget {
  const NotificationSettingsWidget({super.key});

  @override
  State<NotificationSettingsWidget> createState() =>
      _NotificationSettingsWidgetState();
}

class _NotificationSettingsWidgetState
    extends State<NotificationSettingsWidget> {
  bool _pushNotifications = true;
  bool _emailNotifications = true;
  bool _smsNotifications = false;

  // Notification types
  bool _journeyReminders = true;
  bool _delayAlerts = true;
  bool _promotionalOffers = false;
  bool _securityAlerts = true;
  bool _paymentNotifications = true;

  // Timing preferences
  TimeOfDay _quietHoursStart = const TimeOfDay(hour: 22, minute: 0);
  TimeOfDay _quietHoursEnd = const TimeOfDay(hour: 7, minute: 0);
  bool _enableQuietHours = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Notification Settings',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 16),

            // Notification Methods
            Text(
              'Delivery Methods',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildNotificationMethod(
              icon: Icons.notifications,
              title: 'Push Notifications',
              subtitle: 'Instant alerts on your device',
              value: _pushNotifications,
              onChanged: (value) => setState(() => _pushNotifications = value),
            ),

            _buildNotificationMethod(
              icon: Icons.email,
              title: 'Email Notifications',
              subtitle: 'Updates sent to your inbox',
              value: _emailNotifications,
              onChanged: (value) => setState(() => _emailNotifications = value),
            ),

            _buildNotificationMethod(
              icon: Icons.sms,
              title: 'SMS Notifications',
              subtitle: 'Text messages to your phone',
              value: _smsNotifications,
              onChanged: (value) => setState(() => _smsNotifications = value),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Notification Types
            Text(
              'Notification Types',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildNotificationToggle(
              'Journey Reminders',
              'Upcoming departure alerts',
              _journeyReminders,
              (value) => setState(() => _journeyReminders = value),
            ),

            _buildNotificationToggle(
              'Delay Alerts',
              'Real-time service updates',
              _delayAlerts,
              (value) => setState(() => _delayAlerts = value),
            ),

            _buildNotificationToggle(
              'Promotional Offers',
              'Special deals and discounts',
              _promotionalOffers,
              (value) => setState(() => _promotionalOffers = value),
            ),

            _buildNotificationToggle(
              'Security Alerts',
              'Account login and security updates',
              _securityAlerts,
              (value) => setState(() => _securityAlerts = value),
            ),

            _buildNotificationToggle(
              'Payment Notifications',
              'Transaction confirmations',
              _paymentNotifications,
              (value) => setState(() => _paymentNotifications = value),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // Quiet Hours
            Text(
              'Quiet Hours',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildNotificationToggle(
              'Enable Quiet Hours',
              'Limit notifications during specified times',
              _enableQuietHours,
              (value) => setState(() => _enableQuietHours = value),
            ),

            if (_enableQuietHours) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _buildTimeSelector(
                      label: 'Start Time',
                      time: _quietHoursStart,
                      onTap: () => _selectTime(context, true),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _buildTimeSelector(
                      label: 'End Time',
                      time: _quietHoursEnd,
                      onTap: () => _selectTime(context, false),
                    ),
                  ),
                ],
              ),
            ],

            const SizedBox(height: 20),

            // Test Notification Button
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _sendTestNotification,
                icon: const Icon(Icons.send),
                label: const Text('Send Test Notification'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationMethod({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: Theme.of(context).primaryColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationToggle(
    String title,
    String subtitle,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildTimeSelector({
    required String label,
    required TimeOfDay time,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: const Icon(Icons.access_time),
          suffixIcon: const Icon(Icons.arrow_drop_down),
        ),
        child: Text(
          time.format(context),
          style: GoogleFonts.inter(fontSize: 16),
        ),
      ),
    );
  }

  Future<void> _selectTime(BuildContext context, bool isStart) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: isStart ? _quietHoursStart : _quietHoursEnd,
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _quietHoursStart = picked;
        } else {
          _quietHoursEnd = picked;
        }
      });
    }
  }

  void _sendTestNotification() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.notifications, color: Colors.white),
            const SizedBox(width: 12),
            Text(
              'Test notification sent!',
              style: GoogleFonts.inter(fontSize: 16),
            ),
          ],
        ),
        backgroundColor: Theme.of(context).primaryColor,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ),
    );
  }
}
