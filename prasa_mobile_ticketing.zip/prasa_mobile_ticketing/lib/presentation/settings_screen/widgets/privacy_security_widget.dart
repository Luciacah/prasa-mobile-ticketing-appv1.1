import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class PrivacySecurityWidget extends StatefulWidget {
  const PrivacySecurityWidget({super.key});

  @override
  State<PrivacySecurityWidget> createState() => _PrivacySecurityWidgetState();
}

class _PrivacySecurityWidgetState extends State<PrivacySecurityWidget> {
  bool _biometricAuth = false;
  bool _locationServices = true;
  bool _dataSharing = false;
  bool _analyticsSharing = true;
  bool _profileVisibility = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Privacy & Security',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 16),

            // Biometric Authentication
            _buildPrivacyOption(
              icon: Icons.fingerprint,
              title: 'Biometric Authentication',
              subtitle: 'Use fingerprint or face ID to unlock app',
              value: _biometricAuth,
              onChanged: (value) => setState(() => _biometricAuth = value),
            ),

            const Divider(height: 24),

            // Location Services
            _buildPrivacyOption(
              icon: Icons.location_on,
              title: 'Location Services',
              subtitle: 'Allow app to access your location',
              value: _locationServices,
              onChanged: (value) => setState(() => _locationServices = value),
            ),

            const Divider(height: 24),

            // Data Sharing
            _buildPrivacyOption(
              icon: Icons.share,
              title: 'Data Sharing with Partners',
              subtitle: 'Share data with trusted transport partners',
              value: _dataSharing,
              onChanged: (value) => setState(() => _dataSharing = value),
            ),

            const Divider(height: 24),

            // Analytics
            _buildPrivacyOption(
              icon: Icons.analytics,
              title: 'Analytics & Diagnostics',
              subtitle: 'Help improve app performance',
              value: _analyticsSharing,
              onChanged: (value) => setState(() => _analyticsSharing = value),
            ),

            const Divider(height: 24),

            // Profile Visibility
            _buildPrivacyOption(
              icon: Icons.visibility,
              title: 'Profile Visibility',
              subtitle: 'Make profile visible to other users',
              value: _profileVisibility,
              onChanged: (value) => setState(() => _profileVisibility = value),
            ),

            const SizedBox(height: 20),

            // Privacy Policy and Terms
            _buildActionItem(
              icon: Icons.policy,
              title: 'Privacy Policy',
              subtitle: 'Read our privacy policy',
              onTap: () => _showPrivacyPolicy(context),
            ),

            const SizedBox(height: 12),

            _buildActionItem(
              icon: Icons.description,
              title: 'Terms of Service',
              subtitle: 'View terms and conditions',
              onTap: () => _showTermsOfService(context),
            ),

            const SizedBox(height: 12),

            _buildActionItem(
              icon: Icons.download,
              title: 'Download My Data',
              subtitle: 'Export your personal data',
              onTap: () => _downloadData(context),
            ),

            const SizedBox(height: 20),

            // Security Status
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.withAlpha(26),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.green.withAlpha(77),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.security,
                    color: Colors.green,
                    size: 24,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Security Status: Good',
                          style: GoogleFonts.inter(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.green,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Your account is secure with strong settings',
                          style: GoogleFonts.inter(
                            fontSize: 14,
                            color: Colors.green.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrivacyOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildActionItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.grey.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: Colors.grey[700],
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios,
            color: Colors.grey[400],
            size: 16,
          ),
        ],
      ),
    );
  }

  void _showPrivacyPolicy(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Privacy Policy',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'PRASA Privacy Policy',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'We collect and use your personal information to provide and improve our rail transport services. Your data is protected and used in accordance with South African privacy laws.',
                style: GoogleFonts.inter(fontSize: 14),
              ),
              const SizedBox(height: 12),
              Text(
                'Data We Collect:',
                style: GoogleFonts.inter(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '• Contact information (name, email, phone)\n• Journey preferences and history\n• Payment information (encrypted)\n• App usage analytics\n• Location data (when permitted)',
                style: GoogleFonts.inter(fontSize: 14),
              ),
              const SizedBox(height: 12),
              Text(
                'Your Rights:',
                style: GoogleFonts.inter(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '• Access your personal data\n• Correct inaccurate information\n• Delete your account and data\n• Opt-out of marketing communications',
                style: GoogleFonts.inter(fontSize: 14),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Open full privacy policy in browser
            },
            child: const Text('Read Full Policy'),
          ),
        ],
      ),
    );
  }

  void _showTermsOfService(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Terms of Service',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: SingleChildScrollView(
          child: Text(
            'By using the PRASA Mobile Ticketing app, you agree to our terms and conditions. These terms govern your use of our services and outline your rights and responsibilities as a user.',
            style: GoogleFonts.inter(fontSize: 14),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Open full terms in browser
            },
            child: const Text('Read Full Terms'),
          ),
        ],
      ),
    );
  }

  void _downloadData(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Download My Data',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: Text(
          'We\'ll prepare a complete export of your personal data including journey history, preferences, and account information. This may take up to 48 hours.',
          style: GoogleFonts.inter(fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                      'Data export request submitted. You\'ll receive an email when ready.'),
                  duration: Duration(seconds: 4),
                ),
              );
            },
            child: const Text('Request Export'),
          ),
        ],
      ),
    );
  }
}
