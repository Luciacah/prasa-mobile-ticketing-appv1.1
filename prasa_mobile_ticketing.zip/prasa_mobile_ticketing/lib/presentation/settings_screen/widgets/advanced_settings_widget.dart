import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class AdvancedSettingsWidget extends StatefulWidget {
  const AdvancedSettingsWidget({super.key});

  @override
  State<AdvancedSettingsWidget> createState() => _AdvancedSettingsWidgetState();
}

class _AdvancedSettingsWidgetState extends State<AdvancedSettingsWidget> {
  bool _developerMode = false;
  bool _betaFeatures = false;
  bool _diagnosticData = true;
  bool _crashReporting = true;
  bool _performanceMonitoring = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Advanced Settings',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              'These settings are for advanced users and developers',
              style: GoogleFonts.inter(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),

            const SizedBox(height: 16),

            // Developer Options
            _buildAdvancedOption(
              icon: Icons.developer_mode,
              title: 'Developer Mode',
              subtitle: 'Enable advanced debugging features',
              value: _developerMode,
              onChanged: (value) => setState(() => _developerMode = value),
              isWarning: true,
            ),

            if (_developerMode) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.withAlpha(26),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Colors.orange.withAlpha(77),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.warning,
                            color: Colors.orange, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'Developer Options Enabled',
                          style: GoogleFonts.inter(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.orange,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    _buildDeveloperOption('Show Debug Info', false),
                    _buildDeveloperOption('Network Logging', false),
                    _buildDeveloperOption('Performance Overlay', false),
                    _buildDeveloperOption('Widget Inspector', false),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 16),

            // Beta Features
            _buildAdvancedOption(
              icon: Icons.science,
              title: 'Beta Features',
              subtitle: 'Try experimental features before release',
              value: _betaFeatures,
              onChanged: (value) => setState(() => _betaFeatures = value),
            ),

            const SizedBox(height: 16),

            // Data Collection
            Text(
              'Data Collection',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildAdvancedOption(
              icon: Icons.analytics,
              title: 'Diagnostic Data',
              subtitle: 'Help improve app stability and performance',
              value: _diagnosticData,
              onChanged: (value) => setState(() => _diagnosticData = value),
            ),

            const SizedBox(height: 16),

            _buildAdvancedOption(
              icon: Icons.bug_report,
              title: 'Crash Reporting',
              subtitle: 'Automatically send crash reports',
              value: _crashReporting,
              onChanged: (value) => setState(() => _crashReporting = value),
            ),

            const SizedBox(height: 16),

            _buildAdvancedOption(
              icon: Icons.speed,
              title: 'Performance Monitoring',
              subtitle: 'Monitor app performance metrics',
              value: _performanceMonitoring,
              onChanged: (value) =>
                  setState(() => _performanceMonitoring = value),
            ),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // System Information
            Text(
              'System Information',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),

            const SizedBox(height: 12),

            _buildSystemInfo(),

            const SizedBox(height: 20),

            // Advanced Actions
            _buildAdvancedAction(
              icon: Icons.settings_backup_restore,
              title: 'Export Settings',
              subtitle: 'Save all settings to file',
              onTap: _exportSettings,
            ),

            const SizedBox(height: 12),

            _buildAdvancedAction(
              icon: Icons.restore,
              title: 'Import Settings',
              subtitle: 'Restore settings from file',
              onTap: _importSettings,
            ),

            const SizedBox(height: 12),

            _buildAdvancedAction(
              icon: Icons.refresh,
              title: 'Reset All Settings',
              subtitle: 'Restore factory defaults',
              onTap: _resetAllSettings,
              isDangerous: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdvancedOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    bool isWarning = false,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isWarning
                ? Colors.orange.withAlpha(26)
                : Theme.of(context).primaryColor.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: isWarning ? Colors.orange : Theme.of(context).primaryColor,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: isWarning ? Colors.orange : null,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildDeveloperOption(String title, bool value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: GoogleFonts.inter(fontSize: 14),
          ),
          Switch(
            value: value,
            onChanged: (newValue) {
              // Handle developer option changes
            },
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ],
      ),
    );
  }

  Widget _buildSystemInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.withAlpha(13),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey.withAlpha(51),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          _buildInfoRow('Platform', 'Android 14'),
          const SizedBox(height: 8),
          _buildInfoRow('Flutter Version', '3.16.0'),
          const SizedBox(height: 8),
          _buildInfoRow('Dart Version', '3.2.0'),
          const SizedBox(height: 8),
          _buildInfoRow('Device Model', 'Samsung Galaxy S24'),
          const SizedBox(height: 8),
          _buildInfoRow('Available RAM', '8.2 GB'),
          const SizedBox(height: 8),
          _buildInfoRow('Storage Free', '64.1 GB'),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildAdvancedAction({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isDangerous = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(
            color: isDangerous
                ? Colors.red.withAlpha(77)
                : Colors.grey.withAlpha(77),
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isDangerous ? Colors.red : Colors.grey[700],
              size: 24,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: isDangerous ? Colors.red : null,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.grey[400],
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  void _exportSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Settings exported to downloads folder')),
    );
  }

  void _importSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Settings import - Coming soon')),
    );
  }

  void _resetAllSettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Reset All Settings',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            color: Colors.red,
          ),
        ),
        content: Text(
          'This will reset ALL settings to their default values including preferences, notifications, and advanced options. This action cannot be undone.',
          style: GoogleFonts.inter(fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _developerMode = false;
                _betaFeatures = false;
                _diagnosticData = true;
                _crashReporting = true;
                _performanceMonitoring = false;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('All settings have been reset')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Reset All'),
          ),
        ],
      ),
    );
  }
}
