import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/empty_state_widget.dart';
import './widgets/fare_recommendation_card.dart';
import './widgets/promotional_offer_card.dart';
import './widgets/quick_journey_card.dart';
import './widgets/recent_route_card.dart';
import './widgets/service_alert_card.dart';
import './widgets/upcoming_journey_card.dart';

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard>
    with TickerProviderStateMixin {
  int _selectedIndex = 0;
  bool _isNewUser = false; // Set to true to show empty state
  bool _isRefreshing = false;

  // Mock data for recent routes
  final List<Map<String, dynamic>> _recentRoutes = [
    {
      "id": 1,
      "fromStation": "Cape Town",
      "toStation": "Stellenbosch",
      "price": "R 45.00",
      "duration": "1h 15m",
    },
    {
      "id": 2,
      "fromStation": "Johannesburg",
      "toStation": "Pretoria",
      "price": "R 32.50",
      "duration": "45m",
    },
    {
      "id": 3,
      "fromStation": "Durban",
      "toStation": "Pietermaritzburg",
      "price": "R 28.00",
      "duration": "1h 30m",
    },
  ];

  // Mock data for upcoming journeys
  final List<Map<String, dynamic>> _upcomingJourneys = [
    {
      "id": 1,
      "fromStation": "Cape Town",
      "toStation": "Stellenbosch",
      "departureTime": "08:30 AM",
      "platform": "3A",
      "ticketNumber": "TK-2024-001234",
      "countdown": "2h 15m",
    },
  ];

  // Mock data for service alerts
  final List<Map<String, dynamic>> _serviceAlerts = [
    {
      "id": 1,
      "title": "Service Delay",
      "description":
          "Cape Town to Stellenbosch service running 15 minutes late due to signal maintenance.",
      "route": "Cape Town - Stellenbosch",
      "alertType": "delay",
      "time": "10 minutes ago",
    },
    {
      "id": 2,
      "title": "Platform Change",
      "description":
          "Johannesburg to Pretoria 09:45 service moved to Platform 2B.",
      "route": "Johannesburg - Pretoria",
      "alertType": "info",
      "time": "25 minutes ago",
    },
  ];

  // Mock data for fare recommendations
  final List<Map<String, dynamic>> _fareRecommendations = [
    {
      "id": 1,
      "title": "Off-Peak Savings",
      "description":
          "Travel after 10 AM and save on your regular Cape Town to Stellenbosch route.",
      "originalPrice": "R 45.00",
      "recommendedPrice": "R 32.00",
      "savings": "R 13.00",
      "route": "Cape Town - Stellenbosch",
    },
  ];

  // Mock data for promotional offers
  final List<Map<String, dynamic>> _promotionalOffers = [
    {
      "id": 1,
      "title": "Weekend Explorer",
      "description": "Discover new destinations with 30% off weekend travel",
      "discount": "30% OFF",
      "validUntil": "30 Nov 2024",
      "promoCode": "WEEKEND30",
      "imageUrl":
          "https://images.unsplash.com/photo-1530625981245-43987dcfb80d",
      "semanticLabel":
          "Scenic railway track winding through green mountains and valleys with morning mist",
    },
  ];

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isRefreshing = false;
    });
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        // Already on Home
        break;
      case 1:
        Navigator.pushNamed(context, '/ticket-purchase');
        break;
      case 2:
        Navigator.pushNamed(context, '/train-status-alerts');
        break;
      case 3:
        Navigator.pushNamed(context, '/ai-chat-support');
        break;
      case 4:
        // Navigate to profile (not implemented)
        break;
    }
  }

  void _dismissAlert(int alertId) {
    setState(() {
      _serviceAlerts.removeWhere((alert) => (alert["id"] as int) == alertId);
    });
  }

  void _dismissRecommendation(int recommendationId) {
    setState(() {
      _fareRecommendations
          .removeWhere((rec) => (rec["id"] as int) == recommendationId);
    });
  }

  void _dismissOffer(int offerId) {
    setState(() {
      _promotionalOffers
          .removeWhere((offer) => (offer["id"] as int) == offerId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'train',
              color: Colors.white,
              size: 28,
            ),
            SizedBox(width: 2.w),
            Text(
              'PRASA Mobile',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/train-status-alerts');
            },
            icon: Stack(
              children: [
                CustomIconWidget(
                  iconName: 'notifications',
                  color: Colors.white,
                  size: 24,
                ),
                if (_serviceAlerts.isNotEmpty)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      padding: EdgeInsets.all(0.5.w),
                      decoration: const BoxDecoration(
                        color: AppTheme.secondaryLight,
                        shape: BoxShape.circle,
                      ),
                      constraints: BoxConstraints(
                        minWidth: 4.w,
                        minHeight: 4.w,
                      ),
                      child: Text(
                        '${_serviceAlerts.length}',
                        style:
                            AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                          color: Colors.white,
                          fontSize: 8.sp,
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SizedBox(width: 2.w),
        ],
      ),
      body: _isNewUser
          ? EmptyStateWidget(
              onPlanFirstJourney: () {
                Navigator.pushNamed(context, '/ticket-purchase');
              },
            )
          : RefreshIndicator(
              onRefresh: _handleRefresh,
              color: AppTheme.lightTheme.primaryColor,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Quick Journey Card
                    QuickJourneyCard(
                      fromStation: "Cape Town",
                      toStation: "Stellenbosch",
                      onPlanTrip: () {
                        Navigator.pushNamed(context, '/ticket-purchase');
                      },
                    ),

                    // Recent Routes Section
                    if (_recentRoutes.isNotEmpty) ...[
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 2.h),
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'history',
                              color: AppTheme.lightTheme.primaryColor,
                              size: 20,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Recent Routes',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 15.h,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          padding: EdgeInsets.only(left: 4.w),
                          itemCount: _recentRoutes.length,
                          itemBuilder: (context, index) {
                            final route =
                                _recentRoutes[index];
                            return RecentRouteCard(
                              fromStation: route["fromStation"] as String,
                              toStation: route["toStation"] as String,
                              price: route["price"] as String,
                              duration: route["duration"] as String,
                              onTap: () {
                                Navigator.pushNamed(
                                    context, '/ticket-purchase');
                              },
                            );
                          },
                        ),
                      ),
                    ],

                    // Upcoming Journeys
                    if (_upcomingJourneys.isNotEmpty) ...[
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 2.h),
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'schedule',
                              color: AppTheme.lightTheme.primaryColor,
                              size: 20,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Upcoming Journeys',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ..._upcomingJourneys.map((journey) {
                        final journeyData = journey;
                        return UpcomingJourneyCard(
                          fromStation: journeyData["fromStation"] as String,
                          toStation: journeyData["toStation"] as String,
                          departureTime: journeyData["departureTime"] as String,
                          platform: journeyData["platform"] as String,
                          ticketNumber: journeyData["ticketNumber"] as String,
                          countdown: journeyData["countdown"] as String,
                          onTap: () {
                            // Show ticket details
                          },
                        );
                      }).toList(),
                    ],

                    // Service Alerts
                    if (_serviceAlerts.isNotEmpty) ...[
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 2.h),
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'warning',
                              color: AppTheme.warningLight,
                              size: 20,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Service Alerts',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ..._serviceAlerts.map((alert) {
                        final alertData = alert;
                        return ServiceAlertCard(
                          title: alertData["title"] as String,
                          description: alertData["description"] as String,
                          route: alertData["route"] as String,
                          alertType: alertData["alertType"] as String,
                          time: alertData["time"] as String,
                          onDismiss: () =>
                              _dismissAlert(alertData["id"] as int),
                        );
                      }).toList(),
                    ],

                    // Fare Recommendations
                    if (_fareRecommendations.isNotEmpty) ...[
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 2.h),
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'lightbulb',
                              color: AppTheme.successLight,
                              size: 20,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Smart Savings',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ..._fareRecommendations.map((recommendation) {
                        final recData = recommendation;
                        return FareRecommendationCard(
                          title: recData["title"] as String,
                          description: recData["description"] as String,
                          originalPrice: recData["originalPrice"] as String,
                          recommendedPrice:
                              recData["recommendedPrice"] as String,
                          savings: recData["savings"] as String,
                          route: recData["route"] as String,
                          onBook: () {
                            Navigator.pushNamed(context, '/ticket-purchase');
                          },
                          onDismiss: () =>
                              _dismissRecommendation(recData["id"] as int),
                        );
                      }).toList(),
                    ],

                    // Promotional Offers
                    if (_promotionalOffers.isNotEmpty) ...[
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 2.h),
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'local_offer',
                              color: AppTheme.secondaryLight,
                              size: 20,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Special Offers',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ..._promotionalOffers.map((offer) {
                        final offerData = offer;
                        return PromotionalOfferCard(
                          title: offerData["title"] as String,
                          description: offerData["description"] as String,
                          discount: offerData["discount"] as String,
                          validUntil: offerData["validUntil"] as String,
                          promoCode: offerData["promoCode"] as String,
                          imageUrl: offerData["imageUrl"] as String,
                          semanticLabel: offerData["semanticLabel"] as String,
                          onClaim: () {
                            Navigator.pushNamed(context, '/ticket-purchase');
                          },
                          onDismiss: () =>
                              _dismissOffer(offerData["id"] as int),
                        );
                      }).toList(),
                    ],

                    SizedBox(height: 10.h), // Bottom padding for FAB
                  ],
                ),
              ),
            ),
      floatingActionButton: !_isNewUser
          ? FloatingActionButton.extended(
              onPressed: () {
                Navigator.pushNamed(context, '/ticket-purchase');
              },
              backgroundColor: AppTheme.lightTheme.primaryColor,
              foregroundColor: Colors.white,
              icon: CustomIconWidget(
                iconName: 'confirmation_number',
                color: Colors.white,
                size: 24,
              ),
              label: Text(
                'Buy Ticket',
                style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onBottomNavTap,
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppTheme.lightTheme.cardColor,
        selectedItemColor: AppTheme.lightTheme.primaryColor,
        unselectedItemColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        elevation: 8,
        items: [
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'home',
              color: _selectedIndex == 0
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'confirmation_number',
              color: _selectedIndex == 1
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Tickets',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'train',
              color: _selectedIndex == 2
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Travel',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'chat',
              color: _selectedIndex == 3
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'person',
              color: _selectedIndex == 4
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
