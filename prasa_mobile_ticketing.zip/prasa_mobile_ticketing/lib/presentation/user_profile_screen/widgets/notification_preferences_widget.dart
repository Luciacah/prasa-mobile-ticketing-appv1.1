import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class NotificationPreferencesWidget extends StatefulWidget {
  const NotificationPreferencesWidget({Key? key}) : super(key: key);

  @override
  State<NotificationPreferencesWidget> createState() =>
      _NotificationPreferencesWidgetState();
}

class _NotificationPreferencesWidgetState
    extends State<NotificationPreferencesWidget> {
  // Mock notification preferences
  Map<String, bool> _preferences = {
    'pushNotifications': true,
    'emailNotifications': false,
    'smsNotifications': true,
    'tripReminders': true,
    'delayAlerts': true,
    'promotions': false,
    'securityAlerts': true,
    'weeklyDigest': false,
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Notification Preferences',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              IconButton(
                onPressed: () => _showNotificationSettings(context),
                icon: Icon(
                  Icons.settings,
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          Text(
            'Choose how you want to receive updates and alerts.',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: Colors.grey.shade600,
            ),
          ),

          SizedBox(height: 3.h),

          // Communication channels
          _buildSectionHeader('Communication Channels'),

          _buildNotificationToggle(
            'pushNotifications',
            'Push Notifications',
            'Receive notifications on your device',
            Icons.notifications_outlined,
          ),

          _buildNotificationToggle(
            'emailNotifications',
            'Email Notifications',
            'Get updates via email',
            Icons.email_outlined,
          ),

          _buildNotificationToggle(
            'smsNotifications',
            'SMS Notifications',
            'Receive text messages for important updates',
            Icons.sms_outlined,
          ),

          SizedBox(height: 3.h),

          // Travel notifications
          _buildSectionHeader('Travel Notifications'),

          _buildNotificationToggle(
            'tripReminders',
            'Trip Reminders',
            'Get reminded about upcoming journeys',
            Icons.schedule_outlined,
          ),

          _buildNotificationToggle(
            'delayAlerts',
            'Delay & Disruption Alerts',
            'Stay informed about service changes',
            Icons.warning_amber_outlined,
          ),

          SizedBox(height: 3.h),

          // Marketing & updates
          _buildSectionHeader('Marketing & Updates'),

          _buildNotificationToggle(
            'promotions',
            'Promotions & Offers',
            'Receive special offers and discounts',
            Icons.local_offer_outlined,
          ),

          _buildNotificationToggle(
            'weeklyDigest',
            'Weekly Travel Digest',
            'Summary of your travel activity',
            Icons.analytics_outlined,
          ),

          SizedBox(height: 3.h),

          // Security notifications
          _buildSectionHeader('Security & Account'),

          _buildNotificationToggle(
            'securityAlerts',
            'Security Alerts',
            'Important security and account updates',
            Icons.security_outlined,
            isRequired: true,
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: EdgeInsets.only(bottom: 2.h),
      child: Text(
        title,
        style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppTheme.lightTheme.colorScheme.primary,
        ),
      ),
    );
  }

  Widget _buildNotificationToggle(
    String key,
    String title,
    String subtitle,
    IconData icon, {
    bool isRequired = false,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: 3.h),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 20,
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style:
                            AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    if (isRequired)
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: Colors.orange.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Required',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: Colors.orange.shade700,
                            fontWeight: FontWeight.w600,
                            fontSize: 10,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 0.5.h),
                Text(
                  subtitle,
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: _preferences[key] ?? false,
            onChanged: isRequired
                ? null
                : (value) {
                    setState(() => _preferences[key] = value);
                  },
            activeColor: AppTheme.lightTheme.colorScheme.primary,
          ),
        ],
      ),
    );
  }

  void _showNotificationSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.6,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) => Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(height: 3.h),
              Text(
                'Advanced Notification Settings',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 3.h),
              Expanded(
                child: ListView(
                  controller: scrollController,
                  children: [
                    _buildAdvancedSetting(
                      'Quiet Hours',
                      'Set times when you don\'t want to receive notifications',
                      Icons.bedtime_outlined,
                      () => _showQuietHoursDialog(context),
                    ),
                    _buildAdvancedSetting(
                      'Notification Sound',
                      'Choose custom notification sounds',
                      Icons.volume_up_outlined,
                      () => _showSoundSettings(context),
                    ),
                    _buildAdvancedSetting(
                      'Frequency Settings',
                      'Control how often you receive certain notifications',
                      Icons.repeat_outlined,
                      () => _showFrequencySettings(context),
                    ),
                    _buildAdvancedSetting(
                      'Location-Based Alerts',
                      'Get notifications based on your location',
                      Icons.location_on_outlined,
                      () => _showLocationSettings(context),
                    ),
                    _buildAdvancedSetting(
                      'Test Notifications',
                      'Send a test notification to check your settings',
                      Icons.bug_report_outlined,
                      () => _sendTestNotification(context),
                    ),
                    SizedBox(height: 4.h),
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.blue.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.info_outline,
                                color: Colors.blue.shade700,
                                size: 20,
                              ),
                              SizedBox(width: 2.w),
                              Text(
                                'Notification Tips',
                                style: AppTheme.lightTheme.textTheme.titleSmall
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.blue.shade700,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            '• Enable delay alerts to stay informed about service disruptions\n• Trip reminders help you never miss your journey\n• Security alerts are mandatory for account safety\n• You can always adjust these settings later',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: Colors.blue.shade700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdvancedSetting(
      String title, String subtitle, IconData icon, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(
          icon,
          color: AppTheme.lightTheme.colorScheme.primary,
        ),
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
          color: Colors.grey.shade600,
        ),
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }

  void _showQuietHoursDialog(BuildContext context) {
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Quiet Hours'),
        content:
            Text('Quiet hours feature will be available in the next update.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showSoundSettings(BuildContext context) {
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Notification Sound'),
        content: Text(
            'Custom notification sounds will be available in the next update.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showFrequencySettings(BuildContext context) {
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Frequency Settings'),
        content: Text(
            'Notification frequency controls will be available in the next update.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showLocationSettings(BuildContext context) {
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Location-Based Alerts'),
        content: Text(
            'Location-based notification features will be available in the next update.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _sendTestNotification(BuildContext context) {
    Navigator.pop(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Test Notification Sent'),
        content: Text(
            'A test notification has been sent. Please check your notification settings if you don\'t receive it.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
}
