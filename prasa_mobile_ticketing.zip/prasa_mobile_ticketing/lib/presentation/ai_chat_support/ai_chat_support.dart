import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/chat_input_widget.dart';
import './widgets/chat_message_widget.dart';
import './widgets/quick_reply_widget.dart';
import './widgets/rich_message_widget.dart';
import './widgets/smart_suggestions_widget.dart';
import './widgets/typing_indicator_widget.dart';

class AiChatSupport extends StatefulWidget {
  const AiChatSupport({Key? key}) : super(key: key);

  @override
  State<AiChatSupport> createState() => _AiChatSupportState();
}

class _AiChatSupportState extends State<AiChatSupport> {
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  final List<String> _quickReplies = [
    'Check Train Status',
    'Find Ticket',
    'Report Problem',
    'Speak to Human'
  ];
  final List<String> _smartSuggestions = [
    'Cape Town Central',
    'Johannesburg Park',
    'Ticket #TK123456',
    'Platform 3'
  ];

  bool _isTyping = false;
  bool _showQuickReplies = true;

  // Mock conversation data
  final List<Map<String, dynamic>> _mockMessages = [
    {
      "id": 1,
      "content":
          "Hello! I'm PRASA AI Assistant. How can I help you with your train journey today?",
      "isUser": false,
      "timestamp": DateTime.now().subtract(const Duration(minutes: 2)),
      "type": "text"
    },
    {
      "id": 2,
      "content": "Hi, I need help finding my train schedule for tomorrow",
      "isUser": true,
      "timestamp": DateTime.now().subtract(const Duration(minutes: 1)),
      "type": "text"
    },
    {
      "id": 3,
      "content":
          "I'd be happy to help you find your train schedule! Could you please tell me your departure and destination stations?",
      "isUser": false,
      "timestamp": DateTime.now().subtract(const Duration(seconds: 30)),
      "type": "text"
    }
  ];

  // Mock rich message data
  final List<Map<String, dynamic>> _mockRichMessages = [
    {
      "type": "schedule",
      "data": {
        "route": "Cape Town Central → Johannesburg Park",
        "departure": "08:30 AM",
        "arrival": "02:45 PM",
        "duration": "6h 15m"
      }
    },
    {
      "type": "ticket",
      "data": {
        "ticketNumber": "TK789012",
        "route": "Cape Town → Durban",
        "date": "16/11/2025"
      }
    },
    {
      "type": "route",
      "data": {
        "from": "Cape Town Central",
        "to": "Johannesburg Park",
        "distance": "1,462 km",
        "stops": "12 stations"
      }
    }
  ];

  @override
  void initState() {
    super.initState();
    _initializeChat();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _initializeChat() {
    setState(() {
      _messages.addAll(_mockMessages);
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage(String message) {
    setState(() {
      _messages.add({
        "id": _messages.length + 1,
        "content": message,
        "isUser": true,
        "timestamp": DateTime.now(),
        "type": "text"
      });
      _isTyping = true;
      _showQuickReplies = false;
    });

    _scrollToBottom();
    _simulateAIResponse(message);
  }

  void _simulateAIResponse(String userMessage) {
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (!mounted) return;

      setState(() {
        _isTyping = false;
      });

      String response = _generateAIResponse(userMessage);
      Map<String, dynamic>? richMessage = _generateRichMessage(userMessage);

      setState(() {
        _messages.add({
          "id": _messages.length + 1,
          "content": response,
          "isUser": false,
          "timestamp": DateTime.now(),
          "type": "text"
        });

        if (richMessage != null) {
          _messages.add({
            "id": _messages.length + 1,
            "content": "",
            "isUser": false,
            "timestamp": DateTime.now(),
            "type": "rich",
            "richData": richMessage
          });
        }

        _showQuickReplies = true;
      });

      _scrollToBottom();
    });
  }

  String _generateAIResponse(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.contains('schedule') || lowerMessage.contains('time')) {
      return "I found the train schedule for your route. Here are the available options:";
    } else if (lowerMessage.contains('ticket') ||
        lowerMessage.contains('booking')) {
      return "I can help you with your ticket. Let me show you the details:";
    } else if (lowerMessage.contains('route') || lowerMessage.contains('map')) {
      return "Here's the route information for your journey:";
    } else if (lowerMessage.contains('problem') ||
        lowerMessage.contains('issue')) {
      return "I'm sorry to hear you're experiencing an issue. Let me connect you with our support team or help resolve this directly.";
    } else if (lowerMessage.contains('human') ||
        lowerMessage.contains('agent')) {
      return "I'll connect you with a human agent right away. Please hold on while I transfer your conversation.";
    } else {
      return "I understand you need assistance. Could you please provide more details about what you're looking for? I can help with train schedules, tickets, routes, and general inquiries.";
    }
  }

  Map<String, dynamic>? _generateRichMessage(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.contains('schedule') || lowerMessage.contains('time')) {
      return _mockRichMessages[0];
    } else if (lowerMessage.contains('ticket') ||
        lowerMessage.contains('booking')) {
      return _mockRichMessages[1];
    } else if (lowerMessage.contains('route') || lowerMessage.contains('map')) {
      return _mockRichMessages[2];
    }

    return null;
  }

  void _handleQuickReply(String reply) {
    _sendMessage(reply);
  }

  void _handleVoiceMessage(String voiceText) {
    _sendMessage("🎤 $voiceText");
  }

  void _handleFileAttachment(List<int> fileBytes) {
    setState(() {
      _messages.add({
        "id": _messages.length + 1,
        "content": "📎 File attached (${fileBytes.length} bytes)",
        "isUser": true,
        "timestamp": DateTime.now(),
        "type": "text"
      });
    });

    _scrollToBottom();
    _simulateAIResponse(
        "I received your file attachment. Let me analyze it for you.");
  }

  void _handleSuggestionTap(String suggestion) {
    _sendMessage(suggestion);
  }

  void _handleRichMessageAction(String action) {
    switch (action) {
      case 'view_full_schedule':
        Navigator.pushNamed(context, '/train-status-alerts');
        break;
      case 'download_ticket':
        _sendMessage("Please download my ticket");
        break;
      case 'share_ticket':
        _sendMessage("I want to share my ticket");
        break;
      case 'view_full_route':
        _sendMessage("Show me the full route details");
        break;
    }
  }

  void _clearChat() {
    setState(() {
      _messages.clear();
      _showQuickReplies = true;
    });
    _initializeChat();
  }

  void _escalateToHuman() {
    _sendMessage("I need to speak with a human agent");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.primaryColor,
        foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
        elevation: 2,
        title: Row(
          children: [
            Container(
              width: 10.w,
              height: 10.w,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                borderRadius: BorderRadius.circular(5.w),
              ),
              child: CustomIconWidget(
                iconName: 'support_agent',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PRASA AI Assistant',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    'Online • Responds instantly',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onPrimary
                          .withValues(alpha: 0.8),
                      fontSize: 10.sp,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            icon: CustomIconWidget(
              iconName: 'more_vert',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 6.w,
            ),
            onSelected: (value) {
              switch (value) {
                case 'clear':
                  _clearChat();
                  break;
                case 'human':
                  _escalateToHuman();
                  break;
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'clear',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'clear_all',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text('Clear Chat'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'human',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'person',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text('Human Agent'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          SmartSuggestionsWidget(
            suggestions: _smartSuggestions,
            onSuggestionTap: _handleSuggestionTap,
          ),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: EdgeInsets.symmetric(vertical: 2.h),
              itemCount: _messages.length + (_isTyping ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _messages.length && _isTyping) {
                  return const TypingIndicatorWidget();
                }

                final message = _messages[index];
                final messageType = message['type'] as String? ?? 'text';

                if (messageType == 'rich') {
                  return RichMessageWidget(
                    messageData: message['richData'] as Map<String, dynamic>,
                    onActionTap: _handleRichMessageAction,
                  );
                }

                return ChatMessageWidget(
                  message: message,
                  isUser: message['isUser'] as bool,
                );
              },
            ),
          ),
          if (_showQuickReplies && !_isTyping)
            QuickReplyWidget(
              quickReplies: _quickReplies,
              onQuickReply: _handleQuickReply,
            ),
          ChatInputWidget(
            onSendMessage: _sendMessage,
            onVoiceMessage: _handleVoiceMessage,
            onFileAttachment: _handleFileAttachment,
          ),
        ],
      ),
    );
  }
}
