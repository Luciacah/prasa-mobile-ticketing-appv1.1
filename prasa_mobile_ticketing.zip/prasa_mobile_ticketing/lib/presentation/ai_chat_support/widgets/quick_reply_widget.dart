import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class QuickReplyWidget extends StatelessWidget {
  final List<String> quickReplies;
  final Function(String) onQuickReply;

  const QuickReplyWidget({
    Key? key,
    required this.quickReplies,
    required this.onQuickReply,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Wrap(
        spacing: 2.w,
        runSpacing: 1.h,
        children:
            quickReplies.map((reply) => _buildQuickReplyButton(reply)).toList(),
      ),
    );
  }

  Widget _buildQuickReplyButton(String reply) {
    return GestureDetector(
      onTap: () => onQuickReply(reply),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(6.w),
          border: Border.all(
            color: AppTheme.lightTheme.primaryColor,
            width: 1,
          ),
        ),
        child: Text(
          reply,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: AppTheme.lightTheme.primaryColor,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
