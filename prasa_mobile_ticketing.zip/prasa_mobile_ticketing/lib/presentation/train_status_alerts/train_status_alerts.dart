import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/alert_preferences_widget.dart';
import './widgets/departure_item_widget.dart';
import './widgets/favorite_route_widget.dart';
import './widgets/journey_card_widget.dart';

class TrainStatusAlerts extends StatefulWidget {
  const TrainStatusAlerts({Key? key}) : super(key: key);

  @override
  State<TrainStatusAlerts> createState() => _TrainStatusAlertsState();
}

class _TrainStatusAlertsState extends State<TrainStatusAlerts>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  // Alert preferences
  Map<String, bool> _alertPreferences = {
    'departure_reminders': true,
    'delay_alerts': true,
    'platform_changes': true,
    'service_disruptions': false,
    'location_alerts': false,
    'promotional_offers': false,
  };

  // Mock data for journeys
  final List<Map<String, dynamic>> _myJourneys = [
    {
      'id': 1,
      'from': 'Cape Town',
      'to': 'Stellenbosch',
      'trainNumber': 'CT001',
      'departureTime': '08:30',
      'arrivalTime': '09:45',
      'actualDeparture': '08:35',
      'actualArrival': '09:50',
      'platform': 3,
      'platformChanged': false,
      'status': 'delayed',
      'date': '2025-11-16',
    },
    {
      'id': 2,
      'from': 'Johannesburg',
      'to': 'Pretoria',
      'trainNumber': 'JHB205',
      'departureTime': '14:15',
      'arrivalTime': '15:30',
      'platform': 7,
      'platformChanged': true,
      'status': 'on-time',
      'date': '2025-11-16',
    },
    {
      'id': 3,
      'from': 'Durban',
      'to': 'Pietermaritzburg',
      'trainNumber': 'DBN102',
      'departureTime': '16:45',
      'arrivalTime': '18:20',
      'platform': 2,
      'platformChanged': false,
      'status': 'cancelled',
      'date': '2025-11-17',
    },
  ];

  // Mock data for live departures
  final List<Map<String, dynamic>> _liveDepartures = [
    {
      'trainNumber': 'CT001',
      'destination': 'Stellenbosch',
      'scheduledTime': '08:30',
      'actualTime': '08:35',
      'platform': 3,
      'status': 'delayed',
    },
    {
      'trainNumber': 'CT002',
      'destination': 'Paarl',
      'scheduledTime': '09:00',
      'platform': 1,
      'status': 'on-time',
    },
    {
      'trainNumber': 'CT003',
      'destination': 'Worcester',
      'scheduledTime': '09:30',
      'actualTime': '09:30',
      'platform': 4,
      'status': 'on-time',
    },
    {
      'trainNumber': 'JHB201',
      'destination': 'Pretoria',
      'scheduledTime': '10:15',
      'platform': 6,
      'status': 'on-time',
    },
    {
      'trainNumber': 'JHB202',
      'destination': 'Germiston',
      'scheduledTime': '10:45',
      'actualTime': '11:00',
      'platform': 8,
      'status': 'delayed',
    },
    {
      'trainNumber': 'DBN101',
      'destination': 'Pietermaritzburg',
      'scheduledTime': '11:30',
      'platform': null,
      'status': 'cancelled',
    },
  ];

  // Mock data for favorite routes
  final List<Map<String, dynamic>> _favoriteRoutes = [
    {
      'id': 1,
      'from': 'Cape Town',
      'to': 'Stellenbosch',
      'trainNumber': 'CT001',
      'frequency': 'Daily',
      'status': 'on-time',
      'nextDeparture': '08:30',
      'hasAlert': true,
      'lastUpdate': '2 min ago',
    },
    {
      'id': 2,
      'from': 'Johannesburg',
      'to': 'Pretoria',
      'trainNumber': 'JHB205',
      'frequency': 'Weekdays',
      'status': 'delayed',
      'nextDeparture': '14:15',
      'hasAlert': false,
      'lastUpdate': '5 min ago',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text('Train Status & Alerts'),
        actions: [
          IconButton(
            onPressed: () => _showAlertPreferences(context),
            icon: CustomIconWidget(
              iconName: 'settings',
              size: 24,
              color:
                  isDarkMode ? AppTheme.onSurfaceDark : AppTheme.onSurfaceLight,
            ),
          ),
          IconButton(
            onPressed: _refreshData,
            icon: CustomIconWidget(
              iconName: 'refresh',
              size: 24,
              color:
                  isDarkMode ? AppTheme.onSurfaceDark : AppTheme.onSurfaceLight,
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'My Journeys'),
            Tab(text: 'Live Departures'),
            Tab(text: 'Favorites'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            padding: EdgeInsets.all(4.w),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by train number, route, or station...',
                prefixIcon: Padding(
                  padding: EdgeInsets.all(3.w),
                  child: CustomIconWidget(
                    iconName: 'search',
                    size: 20,
                    color: isDarkMode
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
                ),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        onPressed: () {
                          setState(() {
                            _searchQuery = '';
                            _searchController.clear();
                          });
                        },
                        icon: CustomIconWidget(
                          iconName: 'clear',
                          size: 20,
                          color: isDarkMode
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                      )
                    : null,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),

          // Tab content
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refreshData,
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildMyJourneysTab(),
                  _buildLiveDeparturesTab(),
                  _buildFavoritesTab(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMyJourneysTab() {
    final filteredJourneys = _filterJourneys(_myJourneys);

    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(
          color: Theme.of(context).primaryColor,
        ),
      );
    }

    if (filteredJourneys.isEmpty) {
      return _buildEmptyState(
        'No Journeys Found',
        _searchQuery.isNotEmpty
            ? 'No journeys match your search criteria'
            : 'You have no upcoming journeys. Book a ticket to see your trips here.',
        'train',
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      itemCount: filteredJourneys.length,
      itemBuilder: (context, index) {
        final journey = filteredJourneys[index];
        return JourneyCardWidget(
          journey: journey,
          onTap: () => _showJourneyDetails(journey),
        );
      },
    );
  }

  Widget _buildLiveDeparturesTab() {
    final filteredDepartures = _filterDepartures(_liveDepartures);

    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(
          color: Theme.of(context).primaryColor,
        ),
      );
    }

    if (filteredDepartures.isEmpty) {
      return _buildEmptyState(
        'No Departures Found',
        _searchQuery.isNotEmpty
            ? 'No departures match your search criteria'
            : 'No live departure information available at the moment.',
        'schedule',
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      itemCount: filteredDepartures.length,
      itemBuilder: (context, index) {
        final departure = filteredDepartures[index];
        return DepartureItemWidget(
          departure: departure,
          onTap: () => _showDepartureDetails(departure),
          onSetAlert: () => _setDepartureAlert(departure),
          onViewRoute: () => _viewRoute(departure),
          onShare: () => _shareStatus(departure),
        );
      },
    );
  }

  Widget _buildFavoritesTab() {
    final filteredRoutes = _filterFavoriteRoutes(_favoriteRoutes);

    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(
          color: Theme.of(context).primaryColor,
        ),
      );
    }

    if (filteredRoutes.isEmpty) {
      return _buildEmptyState(
        'No Favorite Routes',
        _searchQuery.isNotEmpty
            ? 'No favorite routes match your search criteria'
            : 'Add your frequently traveled routes to monitor them easily.',
        'favorite',
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      itemCount: filteredRoutes.length,
      itemBuilder: (context, index) {
        final route = filteredRoutes[index];
        return FavoriteRouteWidget(
          route: route,
          onTap: () => _showRouteDetails(route),
          onSetAlert: () => _toggleRouteAlert(route),
          onRemove: () => _removeFavoriteRoute(route),
        );
      },
    );
  }

  Widget _buildEmptyState(String title, String message, String iconName) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(6.w),
              decoration: BoxDecoration(
                color:
                    (isDarkMode ? AppTheme.primaryDark : AppTheme.primaryLight)
                        .withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: iconName,
                size: 48,
                color:
                    isDarkMode ? AppTheme.primaryDark : AppTheme.primaryLight,
              ),
            ),
            SizedBox(height: 4.h),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Text(
              message,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: isDarkMode
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _filterJourneys(
      List<Map<String, dynamic>> journeys) {
    if (_searchQuery.isEmpty) return journeys;

    return journeys.where((journey) {
      final query = _searchQuery.toLowerCase();
      return (journey['from'] as String).toLowerCase().contains(query) ||
          (journey['to'] as String).toLowerCase().contains(query) ||
          (journey['trainNumber'] as String).toLowerCase().contains(query);
    }).toList();
  }

  List<Map<String, dynamic>> _filterDepartures(
      List<Map<String, dynamic>> departures) {
    if (_searchQuery.isEmpty) return departures;

    return departures.where((departure) {
      final query = _searchQuery.toLowerCase();
      return (departure['trainNumber'] as String)
              .toLowerCase()
              .contains(query) ||
          (departure['destination'] as String).toLowerCase().contains(query);
    }).toList();
  }

  List<Map<String, dynamic>> _filterFavoriteRoutes(
      List<Map<String, dynamic>> routes) {
    if (_searchQuery.isEmpty) return routes;

    return routes.where((route) {
      final query = _searchQuery.toLowerCase();
      return (route['from'] as String).toLowerCase().contains(query) ||
          (route['to'] as String).toLowerCase().contains(query) ||
          (route['trainNumber'] as String).toLowerCase().contains(query);
    }).toList();
  }

  Future<void> _refreshData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              size: 20,
              color: Colors.white,
            ),
            SizedBox(width: 3.w),
            Text('Data refreshed successfully'),
          ],
        ),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(4.w),
      ),
    );
  }

  void _showAlertPreferences(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AlertPreferencesWidget(
        preferences: _alertPreferences,
        onPreferenceChanged: (key, value) {
          setState(() {
            _alertPreferences[key] = value;
          });
        },
        onClose: () => Navigator.pop(context),
      ),
    );
  }

  void _showJourneyDetails(Map<String, dynamic> journey) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Journey Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Route: ${journey['from']} → ${journey['to']}'),
            Text('Train: ${journey['trainNumber']}'),
            Text('Date: ${journey['date']}'),
            Text('Platform: ${journey['platform']}'),
            Text('Status: ${journey['status']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showDepartureDetails(Map<String, dynamic> departure) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Departure Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Train: ${departure['trainNumber']}'),
            Text('Destination: ${departure['destination']}'),
            Text('Scheduled: ${departure['scheduledTime']}'),
            if (departure['actualTime'] != null)
              Text('Actual: ${departure['actualTime']}'),
            Text('Platform: ${departure['platform'] ?? 'TBA'}'),
            Text('Status: ${departure['status']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _setDepartureAlert(Map<String, dynamic> departure) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Alert set for Train ${departure['trainNumber']}'),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(4.w),
      ),
    );
  }

  void _viewRoute(Map<String, dynamic> departure) {
    Navigator.pushNamed(context, '/train-status-alerts');
  }

  void _shareStatus(Map<String, dynamic> departure) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Status shared for Train ${departure['trainNumber']}'),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(4.w),
      ),
    );
  }

  void _showRouteDetails(Map<String, dynamic> route) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Route Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Route: ${route['from']} → ${route['to']}'),
            Text('Train: ${route['trainNumber']}'),
            Text('Frequency: ${route['frequency']}'),
            Text('Status: ${route['status']}'),
            Text('Next Departure: ${route['nextDeparture']}'),
            Text('Alert: ${route['hasAlert'] ? 'Enabled' : 'Disabled'}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _toggleRouteAlert(Map<String, dynamic> route) {
    setState(() {
      route['hasAlert'] = !(route['hasAlert'] as bool? ?? false);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          route['hasAlert']
              ? 'Alert enabled for ${route['from']} → ${route['to']}'
              : 'Alert disabled for ${route['from']} → ${route['to']}',
        ),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(4.w),
      ),
    );
  }

  void _removeFavoriteRoute(Map<String, dynamic> route) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove Favorite Route'),
        content: Text(
            'Are you sure you want to remove this route from your favorites?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _favoriteRoutes.removeWhere((r) => r['id'] == route['id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Route removed from favorites'),
                  backgroundColor: AppTheme.successLight,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  margin: EdgeInsets.all(4.w),
                ),
              );
            },
            child: Text('Remove'),
          ),
        ],
      ),
    );
  }
}
