import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class JourneyCardWidget extends StatelessWidget {
  final Map<String, dynamic> journey;
  final VoidCallback? onTap;

  const JourneyCardWidget({
    Key? key,
    required this.journey,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final String status = journey['status'] as String? ?? 'on-time';
    final Color statusColor = _getStatusColor(status, isDarkMode);
    final String statusText = _getStatusText(status);

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: statusColor.withValues(alpha: 0.3),
          width: 1.5,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${journey['from']} → ${journey['to']}',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          'Train ${journey['trainNumber']}',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: isDarkMode
                                        ? AppTheme.textSecondaryDark
                                        : AppTheme.textSecondaryLight,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor, width: 1),
                    ),
                    child: Text(
                      statusText,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: statusColor,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Row(
                children: [
                  Expanded(
                    child: _buildTimeInfo(
                      context,
                      'Departure',
                      journey['departureTime'] as String? ?? '',
                      journey['actualDeparture'] as String?,
                      isDarkMode,
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: _buildTimeInfo(
                      context,
                      'Arrival',
                      journey['arrivalTime'] as String? ?? '',
                      journey['actualArrival'] as String?,
                      isDarkMode,
                    ),
                  ),
                ],
              ),
              if (journey['platform'] != null) ...[
                SizedBox(height: 2.h),
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'train',
                      size: 16,
                      color: isDarkMode
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Platform ${journey['platform']}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                    if (journey['platformChanged'] == true) ...[
                      SizedBox(width: 2.w),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.2.h),
                        decoration: BoxDecoration(
                          color: AppTheme.warningLight.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'CHANGED',
                          style:
                              Theme.of(context).textTheme.labelSmall?.copyWith(
                                    color: AppTheme.warningLight,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 8.sp,
                                  ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTimeInfo(
    BuildContext context,
    String label,
    String scheduledTime,
    String? actualTime,
    bool isDarkMode,
  ) {
    final bool isDelayed = actualTime != null && actualTime != scheduledTime;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: isDarkMode
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
              ),
        ),
        SizedBox(height: 0.5.h),
        if (isDelayed) ...[
          Text(
            scheduledTime,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  decoration: TextDecoration.lineThrough,
                  color: isDarkMode
                      ? AppTheme.textDisabledDark
                      : AppTheme.textDisabledLight,
                ),
          ),
          Text(
            actualTime,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.errorLight,
                ),
          ),
        ] else ...[
          Text(
            scheduledTime,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
        ],
      ],
    );
  }

  Color _getStatusColor(String status, bool isDarkMode) {
    switch (status.toLowerCase()) {
      case 'on-time':
        return isDarkMode ? AppTheme.successDark : AppTheme.successLight;
      case 'delayed':
        return isDarkMode ? AppTheme.warningDark : AppTheme.warningLight;
      case 'cancelled':
        return isDarkMode ? AppTheme.errorDark : AppTheme.errorLight;
      default:
        return isDarkMode ? AppTheme.accentDark : AppTheme.accentLight;
    }
  }

  String _getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'on-time':
        return 'ON TIME';
      case 'delayed':
        return 'DELAYED';
      case 'cancelled':
        return 'CANCELLED';
      default:
        return status.toUpperCase();
    }
  }
}
