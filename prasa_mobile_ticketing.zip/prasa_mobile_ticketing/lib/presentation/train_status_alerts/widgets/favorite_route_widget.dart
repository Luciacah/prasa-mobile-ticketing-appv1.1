import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class FavoriteRouteWidget extends StatelessWidget {
  final Map<String, dynamic> route;
  final VoidCallback? onTap;
  final VoidCallback? onRemove;
  final VoidCallback? onSetAlert;

  const FavoriteRouteWidget({
    Key? key,
    required this.route,
    this.onTap,
    this.onRemove,
    this.onSetAlert,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final String status = route['status'] as String? ?? 'on-time';
    final Color statusColor = _getStatusColor(status, isDarkMode);
    final bool hasAlert = route['hasAlert'] as bool? ?? false;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${route['from']} → ${route['to']}',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w600,
                                    ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (hasAlert)
                              Container(
                                padding: EdgeInsets.all(1.w),
                                decoration: BoxDecoration(
                                  color: (isDarkMode
                                          ? AppTheme.primaryDark
                                          : AppTheme.primaryLight)
                                      .withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: CustomIconWidget(
                                  iconName: 'notifications_active',
                                  size: 16,
                                  color: isDarkMode
                                      ? AppTheme.primaryDark
                                      : AppTheme.primaryLight,
                                ),
                              ),
                          ],
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          'Train ${route['trainNumber']} • ${route['frequency']}',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: isDarkMode
                                        ? AppTheme.textSecondaryDark
                                        : AppTheme.textSecondaryLight,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    icon: CustomIconWidget(
                      iconName: 'more_vert',
                      size: 20,
                      color: isDarkMode
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                    ),
                    onSelected: (value) {
                      switch (value) {
                        case 'alert':
                          if (onSetAlert != null) onSetAlert!();
                          break;
                        case 'remove':
                          if (onRemove != null) onRemove!();
                          break;
                      }
                    },
                    itemBuilder: (BuildContext context) => [
                      PopupMenuItem<String>(
                        value: 'alert',
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: hasAlert
                                  ? 'notifications_off'
                                  : 'notifications',
                              size: 18,
                              color: isDarkMode
                                  ? AppTheme.textPrimaryDark
                                  : AppTheme.textPrimaryLight,
                            ),
                            SizedBox(width: 3.w),
                            Text(hasAlert ? 'Remove Alert' : 'Set Alert'),
                          ],
                        ),
                      ),
                      PopupMenuItem<String>(
                        value: 'remove',
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'delete',
                              size: 18,
                              color: AppTheme.errorLight,
                            ),
                            SizedBox(width: 3.w),
                            Text(
                              'Remove Favorite',
                              style: TextStyle(color: AppTheme.errorLight),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Row(
                children: [
                  Expanded(
                    child: _buildStatusInfo(
                      context,
                      'Current Status',
                      _getStatusText(status),
                      statusColor,
                      isDarkMode,
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: _buildStatusInfo(
                      context,
                      'Next Departure',
                      route['nextDeparture'] as String? ?? 'N/A',
                      isDarkMode
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                      isDarkMode,
                    ),
                  ),
                ],
              ),
              if (route['lastUpdate'] != null) ...[
                SizedBox(height: 2.h),
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'access_time',
                      size: 14,
                      color: isDarkMode
                          ? AppTheme.textDisabledDark
                          : AppTheme.textDisabledLight,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Last updated: ${route['lastUpdate']}',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: isDarkMode
                                ? AppTheme.textDisabledDark
                                : AppTheme.textDisabledLight,
                          ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusInfo(
    BuildContext context,
    String label,
    String value,
    Color valueColor,
    bool isDarkMode,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: isDarkMode
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
              ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: valueColor,
              ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Color _getStatusColor(String status, bool isDarkMode) {
    switch (status.toLowerCase()) {
      case 'on-time':
        return isDarkMode ? AppTheme.successDark : AppTheme.successLight;
      case 'delayed':
        return isDarkMode ? AppTheme.warningDark : AppTheme.warningLight;
      case 'cancelled':
        return isDarkMode ? AppTheme.errorDark : AppTheme.errorLight;
      default:
        return isDarkMode ? AppTheme.accentDark : AppTheme.accentLight;
    }
  }

  String _getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'on-time':
        return 'On Time';
      case 'delayed':
        return 'Delayed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  }
}
