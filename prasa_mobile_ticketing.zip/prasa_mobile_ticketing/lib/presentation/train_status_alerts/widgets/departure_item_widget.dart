import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class DepartureItemWidget extends StatelessWidget {
  final Map<String, dynamic> departure;
  final VoidCallback? onTap;
  final VoidCallback? onSetAlert;
  final VoidCallback? onViewRoute;
  final VoidCallback? onShare;

  const DepartureItemWidget({
    Key? key,
    required this.departure,
    this.onTap,
    this.onSetAlert,
    this.onViewRoute,
    this.onShare,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final String status = departure['status'] as String? ?? 'on-time';
    final Color statusColor = _getStatusColor(status, isDarkMode);
    final bool isDelayed = departure['actualTime'] != null &&
        departure['actualTime'] != departure['scheduledTime'];

    return Dismissible(
      key: Key(
          'departure_${departure['trainNumber']}_${departure['scheduledTime']}'),
      direction: DismissDirection.startToEnd,
      background: Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(left: 6.w),
        decoration: BoxDecoration(
          color: isDarkMode ? AppTheme.primaryDark : AppTheme.primaryLight,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'notifications',
              size: 24,
              color:
                  isDarkMode ? AppTheme.onPrimaryDark : AppTheme.onPrimaryLight,
            ),
            SizedBox(height: 0.5.h),
            Text(
              'Set Alert',
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: isDarkMode
                        ? AppTheme.onPrimaryDark
                        : AppTheme.onPrimaryLight,
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
      ),
      onDismissed: (direction) {
        if (onSetAlert != null) onSetAlert!();
      },
      child: Card(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
        elevation: 1,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Train ${departure['trainNumber']}',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        departure['destination'] as String? ?? '',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: isDarkMode
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                            ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (isDelayed) ...[
                        Text(
                          departure['scheduledTime'] as String? ?? '',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    decoration: TextDecoration.lineThrough,
                                    color: isDarkMode
                                        ? AppTheme.textDisabledDark
                                        : AppTheme.textDisabledLight,
                                  ),
                        ),
                        Text(
                          departure['actualTime'] as String? ?? '',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.errorLight,
                                  ),
                        ),
                      ] else ...[
                        Text(
                          departure['scheduledTime'] as String? ?? '',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ],
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Platform',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: isDarkMode
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                            ),
                      ),
                      SizedBox(height: 0.5.h),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: statusColor, width: 1),
                        ),
                        child: Text(
                          departure['platform']?.toString() ?? 'TBA',
                          style:
                              Theme.of(context).textTheme.labelMedium?.copyWith(
                                    color: statusColor,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 2.w),
                PopupMenuButton<String>(
                  icon: CustomIconWidget(
                    iconName: 'more_vert',
                    size: 20,
                    color: isDarkMode
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
                  onSelected: (value) {
                    switch (value) {
                      case 'alert':
                        if (onSetAlert != null) onSetAlert!();
                        break;
                      case 'route':
                        if (onViewRoute != null) onViewRoute!();
                        break;
                      case 'share':
                        if (onShare != null) onShare!();
                        break;
                    }
                  },
                  itemBuilder: (BuildContext context) => [
                    PopupMenuItem<String>(
                      value: 'alert',
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'notifications',
                            size: 18,
                            color: isDarkMode
                                ? AppTheme.textPrimaryDark
                                : AppTheme.textPrimaryLight,
                          ),
                          SizedBox(width: 3.w),
                          Text('Set Alert'),
                        ],
                      ),
                    ),
                    PopupMenuItem<String>(
                      value: 'route',
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'route',
                            size: 18,
                            color: isDarkMode
                                ? AppTheme.textPrimaryDark
                                : AppTheme.textPrimaryLight,
                          ),
                          SizedBox(width: 3.w),
                          Text('View Route'),
                        ],
                      ),
                    ),
                    PopupMenuItem<String>(
                      value: 'share',
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'share',
                            size: 18,
                            color: isDarkMode
                                ? AppTheme.textPrimaryDark
                                : AppTheme.textPrimaryLight,
                          ),
                          SizedBox(width: 3.w),
                          Text('Share Status'),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status, bool isDarkMode) {
    switch (status.toLowerCase()) {
      case 'on-time':
        return isDarkMode ? AppTheme.successDark : AppTheme.successLight;
      case 'delayed':
        return isDarkMode ? AppTheme.warningDark : AppTheme.warningLight;
      case 'cancelled':
        return isDarkMode ? AppTheme.errorDark : AppTheme.errorLight;
      default:
        return isDarkMode ? AppTheme.accentDark : AppTheme.accentLight;
    }
  }
}
