import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AlertPreferencesWidget extends StatefulWidget {
  final Map<String, bool> preferences;
  final Function(String, bool) onPreferenceChanged;
  final VoidCallback? onClose;

  const AlertPreferencesWidget({
    Key? key,
    required this.preferences,
    required this.onPreferenceChanged,
    this.onClose,
  }) : super(key: key);

  @override
  State<AlertPreferencesWidget> createState() => _AlertPreferencesWidgetState();
}

class _AlertPreferencesWidgetState extends State<AlertPreferencesWidget> {
  late Map<String, bool> _localPreferences;

  @override
  void initState() {
    super.initState();
    _localPreferences = Map.from(widget.preferences);
  }

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDarkMode ? AppTheme.surfaceDark : AppTheme.surfaceLight,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 2.h),
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: isDarkMode ? AppTheme.dividerDark : AppTheme.dividerLight,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Alert Preferences',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
                IconButton(
                  onPressed: widget.onClose,
                  icon: CustomIconWidget(
                    iconName: 'close',
                    size: 24,
                    color: isDarkMode
                        ? AppTheme.textPrimaryDark
                        : AppTheme.textPrimaryLight,
                  ),
                ),
              ],
            ),
          ),

          // Preferences list
          Flexible(
            child: ListView(
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              children: [
                _buildPreferenceItem(
                  context,
                  'departure_reminders',
                  'Departure Reminders',
                  'Get notified 30 minutes before departure',
                  'schedule',
                  isDarkMode,
                ),
                _buildPreferenceItem(
                  context,
                  'delay_alerts',
                  'Delay Alerts',
                  'Instant notifications for train delays',
                  'warning',
                  isDarkMode,
                ),
                _buildPreferenceItem(
                  context,
                  'platform_changes',
                  'Platform Changes',
                  'Alerts when platform numbers change',
                  'swap_horiz',
                  isDarkMode,
                ),
                _buildPreferenceItem(
                  context,
                  'service_disruptions',
                  'Service Disruptions',
                  'Notifications about cancellations and service issues',
                  'error',
                  isDarkMode,
                ),
                _buildPreferenceItem(
                  context,
                  'location_alerts',
                  'Location-Based Alerts',
                  'Alerts when approaching departure station',
                  'location_on',
                  isDarkMode,
                ),
                _buildPreferenceItem(
                  context,
                  'promotional_offers',
                  'Promotional Offers',
                  'Special deals and discount notifications',
                  'local_offer',
                  isDarkMode,
                ),
              ],
            ),
          ),

          // Test notification button
          Padding(
            padding: EdgeInsets.all(4.w),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _showTestNotification(context),
                icon: CustomIconWidget(
                  iconName: 'notifications_active',
                  size: 20,
                  color: isDarkMode
                      ? AppTheme.onPrimaryDark
                      : AppTheme.onPrimaryLight,
                ),
                label: Text('Test Notification'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                ),
              ),
            ),
          ),

          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildPreferenceItem(
    BuildContext context,
    String key,
    String title,
    String description,
    String iconName,
    bool isDarkMode,
  ) {
    final bool isEnabled = _localPreferences[key] ?? false;

    return Card(
      margin: EdgeInsets.only(bottom: 2.h),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color:
                    (isDarkMode ? AppTheme.primaryDark : AppTheme.primaryLight)
                        .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: iconName,
                size: 24,
                color:
                    isDarkMode ? AppTheme.primaryDark : AppTheme.primaryLight,
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: isDarkMode
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                  ),
                ],
              ),
            ),
            Switch(
              value: isEnabled,
              onChanged: (value) {
                setState(() {
                  _localPreferences[key] = value;
                });
                widget.onPreferenceChanged(key, value);

                // Show preview notification
                if (value) {
                  _showPreviewNotification(context, title);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showTestNotification(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'notifications',
              size: 20,
              color: Colors.white,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                  'Test notification sent! Check your notification panel.'),
            ),
          ],
        ),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(4.w),
      ),
    );
  }

  void _showPreviewNotification(BuildContext context, String alertType) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              size: 20,
              color: Colors.white,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text('$alertType enabled successfully!'),
            ),
          ],
        ),
        backgroundColor: AppTheme.successLight,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(4.w),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
