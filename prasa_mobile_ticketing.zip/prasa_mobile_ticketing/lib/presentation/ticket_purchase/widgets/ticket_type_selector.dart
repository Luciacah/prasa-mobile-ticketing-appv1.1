import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TicketTypeSelector extends StatelessWidget {
  final String selectedType;
  final Function(String) onTypeSelected;
  final List<Map<String, dynamic>> ticketTypes;

  const TicketTypeSelector({
    Key? key,
    required this.selectedType,
    required this.onTypeSelected,
    required this.ticketTypes,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Ticket Type',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: ticketTypes.length,
            separatorBuilder: (context, index) => SizedBox(height: 1.h),
            itemBuilder: (context, index) {
              final ticketType = ticketTypes[index];
              final isSelected = selectedType == (ticketType['type'] as String);

              return GestureDetector(
                onTap: () => onTypeSelected(ticketType['type'] as String),
                child: Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? (isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight)
                            .withValues(alpha: 0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isSelected
                          ? (isDark
                              ? AppTheme.primaryDark
                              : AppTheme.primaryLight)
                          : (isDark
                              ? AppTheme.dividerDark
                              : AppTheme.dividerLight),
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isSelected
                                ? (isDark
                                    ? AppTheme.primaryDark
                                    : AppTheme.primaryLight)
                                : (isDark
                                    ? AppTheme.dividerDark
                                    : AppTheme.dividerLight),
                            width: 2,
                          ),
                          color: isSelected
                              ? (isDark
                                  ? AppTheme.primaryDark
                                  : AppTheme.primaryLight)
                              : Colors.transparent,
                        ),
                        child: isSelected
                            ? Center(
                                child: Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: isDark
                                        ? AppTheme.onPrimaryDark
                                        : AppTheme.onPrimaryLight,
                                  ),
                                ),
                              )
                            : null,
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  ticketType['type'] as String,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleSmall
                                      ?.copyWith(
                                        fontWeight: FontWeight.w600,
                                        color: isSelected
                                            ? (isDark
                                                ? AppTheme.primaryDark
                                                : AppTheme.primaryLight)
                                            : null,
                                      ),
                                ),
                                Text(
                                  ticketType['price'] as String,
                                  style: AppTheme.priceTextStyle(
                                    isLight: !isDark,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ).copyWith(
                                    color: isSelected
                                        ? (isDark
                                            ? AppTheme.primaryDark
                                            : AppTheme.primaryLight)
                                        : null,
                                  ),
                                ),
                              ],
                            ),
                            if (ticketType['description'] != null) ...[
                              SizedBox(height: 0.5.h),
                              Text(
                                ticketType['description'] as String,
                                style: Theme.of(context).textTheme.bodySmall,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2,
                              ),
                            ],
                            if (ticketType['savings'] != null) ...[
                              SizedBox(height: 0.5.h),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 2.w, vertical: 0.5.h),
                                decoration: BoxDecoration(
                                  color: isDark
                                      ? AppTheme.successDark
                                      : AppTheme.successLight,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  'Save ${ticketType['savings']}',
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelSmall
                                      ?.copyWith(
                                        color: isDark
                                            ? AppTheme.onPrimaryDark
                                            : AppTheme.onPrimaryLight,
                                        fontWeight: FontWeight.w500,
                                      ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
