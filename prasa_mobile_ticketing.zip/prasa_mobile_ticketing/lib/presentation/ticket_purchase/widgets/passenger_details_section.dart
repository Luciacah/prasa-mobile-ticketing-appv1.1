import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PassengerDetailsSection extends StatelessWidget {
  final List<Map<String, dynamic>> passengers;
  final Function(int, String, String) onPassengerUpdated;
  final VoidCallback onAddPassenger;
  final Function(int) onRemovePassenger;

  const PassengerDetailsSection({
    Key? key,
    required this.passengers,
    required this.onPassengerUpdated,
    required this.onAddPassenger,
    required this.onRemovePassenger,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Passenger Details',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              if (passengers.length < 6)
                TextButton.icon(
                  onPressed: onAddPassenger,
                  icon: CustomIconWidget(
                    iconName: 'add',
                    color:
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                    size: 18,
                  ),
                  label: Text(
                    'Add',
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: isDark
                              ? AppTheme.primaryDark
                              : AppTheme.primaryLight,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 2.h),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: passengers.length,
            separatorBuilder: (context, index) => SizedBox(height: 2.h),
            itemBuilder: (context, index) {
              final passenger = passengers[index];
              final isMainPassenger = index == 0;

              return Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: isMainPassenger
                      ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                          .withValues(alpha: 0.05)
                      : (isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: isMainPassenger
                        ? (isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight)
                            .withValues(alpha: 0.3)
                        : (isDark
                            ? AppTheme.dividerDark
                            : AppTheme.dividerLight),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          isMainPassenger
                              ? 'Main Passenger'
                              : 'Passenger ${index + 1}',
                          style:
                              Theme.of(context).textTheme.titleSmall?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: isMainPassenger
                                        ? (isDark
                                            ? AppTheme.primaryDark
                                            : AppTheme.primaryLight)
                                        : null,
                                  ),
                        ),
                        if (!isMainPassenger)
                          GestureDetector(
                            onTap: () => onRemovePassenger(index),
                            child: Container(
                              padding: EdgeInsets.all(1.w),
                              decoration: BoxDecoration(
                                color: isDark
                                    ? AppTheme.errorDark
                                    : AppTheme.errorLight,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: CustomIconWidget(
                                iconName: 'close',
                                color: isDark
                                    ? AppTheme.onErrorDark
                                    : AppTheme.onErrorLight,
                                size: 16,
                              ),
                            ),
                          ),
                      ],
                    ),
                    SizedBox(height: 1.5.h),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            initialValue: passenger['name'] as String? ?? '',
                            decoration: InputDecoration(
                              labelText: 'Full Name',
                              hintText: 'Enter full name',
                              prefixIcon: Padding(
                                padding: EdgeInsets.all(3.w),
                                child: CustomIconWidget(
                                  iconName: 'person',
                                  color: isDark
                                      ? AppTheme.textSecondaryDark
                                      : AppTheme.textSecondaryLight,
                                  size: 20,
                                ),
                              ),
                            ),
                            onChanged: (value) =>
                                onPassengerUpdated(index, 'name', value),
                          ),
                        ),
                        SizedBox(width: 2.w),
                        Expanded(
                          child: TextFormField(
                            initialValue:
                                passenger['idNumber'] as String? ?? '',
                            decoration: InputDecoration(
                              labelText: 'ID Number',
                              hintText: 'Enter ID number',
                              prefixIcon: Padding(
                                padding: EdgeInsets.all(3.w),
                                child: CustomIconWidget(
                                  iconName: 'badge',
                                  color: isDark
                                      ? AppTheme.textSecondaryDark
                                      : AppTheme.textSecondaryLight,
                                  size: 20,
                                ),
                              ),
                            ),
                            onChanged: (value) =>
                                onPassengerUpdated(index, 'idNumber', value),
                          ),
                        ),
                      ],
                    ),
                    if (isMainPassenger) ...[
                      SizedBox(height: 1.5.h),
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'info',
                            color: isDark
                                ? AppTheme.accentDark
                                : AppTheme.accentLight,
                            size: 16,
                          ),
                          SizedBox(width: 2.w),
                          Expanded(
                            child: Text(
                              'Details auto-filled from your profile',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: isDark
                                        ? AppTheme.accentDark
                                        : AppTheme.accentLight,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
