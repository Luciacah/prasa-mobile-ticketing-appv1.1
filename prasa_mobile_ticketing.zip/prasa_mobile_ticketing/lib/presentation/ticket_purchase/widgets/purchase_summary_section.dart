import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PurchaseSummarySection extends StatelessWidget {
  final Map<String, dynamic> summaryData;
  final bool isTermsAccepted;
  final Function(bool?) onTermsChanged;
  final bool isLoading;
  final VoidCallback onPurchase;

  const PurchaseSummarySection({
    Key? key,
    required this.summaryData,
    required this.isTermsAccepted,
    required this.onTermsChanged,
    required this.isLoading,
    required this.onPurchase,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Purchase Summary',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          _buildSummaryRow(
            context,
            'Ticket Type',
            summaryData['ticketType'] as String? ?? 'Single Journey',
            isDark,
          ),
          SizedBox(height: 1.h),
          _buildSummaryRow(
            context,
            'Passengers',
            '${summaryData['passengerCount'] ?? 1}',
            isDark,
          ),
          SizedBox(height: 1.h),
          _buildSummaryRow(
            context,
            'Base Price',
            summaryData['basePrice'] as String? ?? 'R 0.00',
            isDark,
          ),
          if (summaryData['discount'] != null) ...[
            SizedBox(height: 1.h),
            _buildSummaryRow(
              context,
              'Discount',
              '- ${summaryData['discount']}',
              isDark,
              isDiscount: true,
            ),
          ],
          if (summaryData['fees'] != null) ...[
            SizedBox(height: 1.h),
            _buildSummaryRow(
              context,
              'Service Fee',
              summaryData['fees'] as String,
              isDark,
            ),
          ],
          SizedBox(height: 1.h),
          Divider(
            color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
            thickness: 1,
          ),
          SizedBox(height: 1.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Amount',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
              ),
              Text(
                summaryData['totalAmount'] as String? ?? 'R 0.00',
                style: AppTheme.priceTextStyle(
                  isLight: !isDark,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ).copyWith(
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: isTermsAccepted,
                onChanged: onTermsChanged,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: GestureDetector(
                  onTap: () => onTermsChanged(!isTermsAccepted),
                  child: RichText(
                    text: TextSpan(
                      style: Theme.of(context).textTheme.bodySmall,
                      children: [
                        const TextSpan(text: 'I agree to the '),
                        TextSpan(
                          text: 'Terms and Conditions',
                          style: TextStyle(
                            color: isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight,
                            decoration: TextDecoration.underline,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const TextSpan(text: ' and '),
                        TextSpan(
                          text: 'PRASA Privacy Policy',
                          style: TextStyle(
                            color: isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight,
                            decoration: TextDecoration.underline,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          SizedBox(
            width: double.infinity,
            height: 6.h,
            child: ElevatedButton(
              onPressed: isTermsAccepted && !isLoading ? onPurchase : null,
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                foregroundColor:
                    isDark ? AppTheme.onPrimaryDark : AppTheme.onPrimaryLight,
                disabledBackgroundColor: isDark
                    ? AppTheme.textDisabledDark
                    : AppTheme.textDisabledLight,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: isTermsAccepted && !isLoading ? 2 : 0,
              ),
              child: isLoading
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              isDark
                                  ? AppTheme.onPrimaryDark
                                  : AppTheme.onPrimaryLight,
                            ),
                          ),
                        ),
                        SizedBox(width: 3.w),
                        Text(
                          'Processing...',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: isDark
                                        ? AppTheme.onPrimaryDark
                                        : AppTheme.onPrimaryLight,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'payment',
                          color: isDark
                              ? AppTheme.onPrimaryDark
                              : AppTheme.onPrimaryLight,
                          size: 20,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Pay Now - ${summaryData['totalAmount'] ?? 'R 0.00'}',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: isDark
                                        ? AppTheme.onPrimaryDark
                                        : AppTheme.onPrimaryLight,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(
    BuildContext context,
    String label,
    String value,
    bool isDark, {
    bool isDiscount = false,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        Text(
          value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: isDiscount
                    ? (isDark ? AppTheme.successDark : AppTheme.successLight)
                    : null,
              ),
        ),
      ],
    );
  }
}
