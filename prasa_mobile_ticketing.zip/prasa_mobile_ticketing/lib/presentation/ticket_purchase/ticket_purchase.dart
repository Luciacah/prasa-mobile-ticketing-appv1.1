import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/journey_summary_card.dart';
import './widgets/passenger_details_section.dart';
import './widgets/payment_method_selector.dart';
import './widgets/purchase_summary_section.dart';
import './widgets/ticket_type_selector.dart';

class TicketPurchase extends StatefulWidget {
  const TicketPurchase({Key? key}) : super(key: key);

  @override
  State<TicketPurchase> createState() => _TicketPurchaseState();
}

class _TicketPurchaseState extends State<TicketPurchase> {
  int _currentStep = 0;
  String _selectedTicketType = 'single';
  String _selectedPaymentMethod = 'card_1';
  bool _isTermsAccepted = false;
  bool _isLoading = false;

  List<Map<String, dynamic>> _passengers = [
    {
      'name': 'John Doe',
      'idNumber': '9001015009087',
    }
  ];

  // Mock journey data
  final Map<String, dynamic> _journeyData = {
    'from': 'Cape Town Central',
    'to': 'Stellenbosch',
    'date': '15/11/2025',
    'time': '08:30',
    'passengers': 1,
  };

  // Mock ticket types data
  final List<Map<String, dynamic>> _ticketTypes = [
    {
      'type': 'single',
      'name': 'Single Journey',
      'price': 'R 25.00',
      'description': 'One-way ticket for immediate travel',
    },
    {
      'type': 'return',
      'name': 'Return Journey',
      'price': 'R 45.00',
      'description': 'Round-trip ticket valid for 30 days',
      'savings': 'R 5.00',
    },
    {
      'type': 'weekly',
      'name': 'Weekly Pass',
      'price': 'R 120.00',
      'description': 'Unlimited travel for 7 days',
      'savings': 'R 55.00',
    },
    {
      'type': 'monthly',
      'name': 'Monthly Pass',
      'price': 'R 400.00',
      'description': 'Unlimited travel for 30 days',
      'savings': 'R 350.00',
    },
  ];

  // Mock payment methods data
  final List<Map<String, dynamic>> _paymentMethods = [
    {
      'id': 'card_1',
      'name': 'Visa Card',
      'details': '**** **** **** 1234',
      'icon':
          'https://img.rocket.new/generatedImages/rocket_gen_img_1e215c494-1763237403893.png',
      'semanticLabel': 'Visa credit card logo with blue and white colors',
      'isSecure': true,
    },
    {
      'id': 'apple_pay',
      'name': 'Apple Pay',
      'details': 'Touch ID or Face ID',
      'iconName': 'phone_iphone',
      'isSecure': true,
    },
    {
      'id': 'google_pay',
      'name': 'Google Pay',
      'details': 'Fingerprint or PIN',
      'iconName': 'android',
      'isSecure': true,
    },
    {
      'id': 'snapscan',
      'name': 'SnapScan',
      'details': 'QR Code Payment',
      'icon': 'https://img.rocket.new/generatedImages/rocket_gen_img_184d5f963-1763237404187.png',
      'semanticLabel':
          'SnapScan logo with green circular design and white text',
      'isSecure': true,
    },
    {
      'id': 'payfast',
      'name': 'PayFast',
      'details': 'Secure Online Payment',
      'icon': 'https://img.rocket.new/generatedImages/rocket_gen_img_1bfb6e939-1763237404727.png',
      'semanticLabel': 'PayFast logo with orange and blue colors',
      'isSecure': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: AppBar(
        title: Text(
          'Purchase Ticket',
          style: Theme.of(context).appBarTheme.titleTextStyle,
        ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: isDark ? AppTheme.onSurfaceDark : AppTheme.onSurfaceLight,
            size: 24,
          ),
        ),
        backgroundColor: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
        elevation: 1,
      ),
      body: Column(
        children: [
          // Progress Indicator
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
              border: Border(
                bottom: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                _buildStepIndicator(0, 'Details', isDark),
                _buildStepConnector(isDark),
                _buildStepIndicator(1, 'Payment', isDark),
                _buildStepConnector(isDark),
                _buildStepIndicator(2, 'Confirm', isDark),
              ],
            ),
          ),
          // Content
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: 2.h),
                  // Journey Summary Card
                  JourneySummaryCard(
                    journeyData: _journeyData,
                    onTap: _onEditJourney,
                  ),
                  // Ticket Type Selector
                  TicketTypeSelector(
                    selectedType: _selectedTicketType,
                    onTypeSelected: _onTicketTypeSelected,
                    ticketTypes: _ticketTypes,
                  ),
                  // Passenger Details Section
                  PassengerDetailsSection(
                    passengers: _passengers,
                    onPassengerUpdated: _onPassengerUpdated,
                    onAddPassenger: _onAddPassenger,
                    onRemovePassenger: _onRemovePassenger,
                  ),
                  // Payment Method Selector
                  PaymentMethodSelector(
                    selectedPaymentMethod: _selectedPaymentMethod,
                    onPaymentMethodSelected: _onPaymentMethodSelected,
                    paymentMethods: _paymentMethods,
                    onAddPaymentMethod: _onAddPaymentMethod,
                  ),
                  // Purchase Summary Section
                  PurchaseSummarySection(
                    summaryData: _getPurchaseSummary(),
                    isTermsAccepted: _isTermsAccepted,
                    onTermsChanged: _onTermsChanged,
                    isLoading: _isLoading,
                    onPurchase: _onPurchase,
                  ),
                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepIndicator(int step, String label, bool isDark) {
    final isActive = step <= _currentStep;
    final isCompleted = step < _currentStep;

    return Expanded(
      child: Column(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isActive
                  ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                  : (isDark ? AppTheme.dividerDark : AppTheme.dividerLight),
            ),
            child: Center(
              child: isCompleted
                  ? CustomIconWidget(
                      iconName: 'check',
                      color: isDark
                          ? AppTheme.onPrimaryDark
                          : AppTheme.onPrimaryLight,
                      size: 18,
                    )
                  : Text(
                      '${step + 1}',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: isActive
                                ? (isDark
                                    ? AppTheme.onPrimaryDark
                                    : AppTheme.onPrimaryLight)
                                : (isDark
                                    ? AppTheme.textSecondaryDark
                                    : AppTheme.textSecondaryLight),
                            fontWeight: FontWeight.w600,
                          ),
                    ),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: isActive
                      ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                      : (isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight),
                  fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepConnector(bool isDark) {
    return Expanded(
      child: Container(
        height: 2,
        margin: EdgeInsets.symmetric(horizontal: 2.w),
        color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
      ),
    );
  }

  void _onEditJourney() {
    Fluttertoast.showToast(
      msg: "Journey editing functionality",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onTicketTypeSelected(String type) {
    setState(() {
      _selectedTicketType = type;
    });
  }

  void _onPassengerUpdated(int index, String field, String value) {
    setState(() {
      if (index < _passengers.length) {
        _passengers[index][field] = value;
      }
    });
  }

  void _onAddPassenger() {
    if (_passengers.length < 6) {
      setState(() {
        _passengers.add({
          'name': '',
          'idNumber': '',
        });
        _journeyData['passengers'] = _passengers.length;
      });
    }
  }

  void _onRemovePassenger(int index) {
    if (index > 0 && index < _passengers.length) {
      setState(() {
        _passengers.removeAt(index);
        _journeyData['passengers'] = _passengers.length;
      });
    }
  }

  void _onPaymentMethodSelected(String methodId) {
    setState(() {
      _selectedPaymentMethod = methodId;
    });
  }

  void _onAddPaymentMethod() {
    Fluttertoast.showToast(
      msg: "Add payment method functionality",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onTermsChanged(bool? value) {
    setState(() {
      _isTermsAccepted = value ?? false;
    });
  }

  Map<String, dynamic> _getPurchaseSummary() {
    final selectedTicket = _ticketTypes.firstWhere(
      (ticket) => ticket['type'] == _selectedTicketType,
      orElse: () => _ticketTypes.first,
    );

    final basePrice = double.parse((selectedTicket['price'] as String)
        .replaceAll('R ', '')
        .replaceAll(',', ''));
    final passengerCount = _passengers.length;
    final subtotal = basePrice * passengerCount;
    final serviceFee = subtotal * 0.05; // 5% service fee
    final total = subtotal + serviceFee;

    return {
      'ticketType': selectedTicket['name'],
      'passengerCount': passengerCount,
      'basePrice': 'R ${basePrice.toStringAsFixed(2)}',
      'fees': 'R ${serviceFee.toStringAsFixed(2)}',
      'totalAmount': 'R ${total.toStringAsFixed(2)}',
    };
  }

  Future<void> _onPurchase() async {
    if (!_isTermsAccepted) {
      Fluttertoast.showToast(
        msg: "Please accept the terms and conditions",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate payment processing
      await Future.delayed(const Duration(seconds: 3));

      // Simulate payment success
      if (mounted) {
        setState(() {
          _isLoading = false;
          _currentStep = 2;
        });

        _showSuccessDialog();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });

        Fluttertoast.showToast(
          msg: "Payment failed. Please try again.",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
        );
      }
    }
  }

  void _showSuccessDialog() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: isDark ? AppTheme.dialogDark : AppTheme.dialogLight,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isDark ? AppTheme.successDark : AppTheme.successLight,
                ),
                child: CustomIconWidget(
                  iconName: 'check',
                  color:
                      isDark ? AppTheme.onPrimaryDark : AppTheme.onPrimaryLight,
                  size: 40,
                ),
              ),
              SizedBox(height: 3.h),
              Text(
                'Ticket Purchased!',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color:
                          isDark ? AppTheme.successDark : AppTheme.successLight,
                    ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 1.h),
              Text(
                'Your ticket has been successfully purchased. You will receive a confirmation email shortly.',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 3.h),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.pushReplacementNamed(context, '/home-dashboard');
                  },
                  child: Text('View Ticket'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
