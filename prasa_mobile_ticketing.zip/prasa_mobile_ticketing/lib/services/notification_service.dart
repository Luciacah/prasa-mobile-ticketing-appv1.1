import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Service for managing notifications and real-time updates
class NotificationService {
  static NotificationService? _instance;
  static NotificationService get instance =>
      _instance ??= NotificationService._();
  NotificationService._();

  final SupabaseClient _supabase = Supabase.instance.client;

  // Stream controllers for real-time notifications
  final Map<String, RealtimeChannel> _activeChannels = {};
  final List<Function(Map<String, dynamic>)> _notificationListeners = [];

  // ==================== INITIALIZATION ====================

  /// Initialize notification service and set up real-time listeners
  Future<void> initialize() async {
    try {
      await _setupRealtimeListeners();
      if (kDebugMode) {
        print('NotificationService initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to initialize NotificationService: $e');
      }
      throw Exception('Failed to initialize notifications: $e');
    }
  }

  /// Dispose notification service and clean up resources
  void dispose() {
    try {
      _cleanupChannels();
      _notificationListeners.clear();
      if (kDebugMode) {
        print('NotificationService disposed successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error disposing NotificationService: $e');
      }
    }
  }

  // ==================== REAL-TIME LISTENERS ====================

  /// Set up real-time listeners for various notifications
  Future<void> _setupRealtimeListeners() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        if (kDebugMode) {
          print('User not authenticated - skipping real-time setup');
        }
        return;
      }

      // Listen to service alerts
      await _subscribeToServiceAlerts();

      // Listen to booking status updates
      await _subscribeToBookingUpdates(user.id);

      // Listen to payment status updates
      await _subscribeToPaymentUpdates(user.id);

      // Listen to service status changes
      await _subscribeToServiceStatusUpdates();
    } catch (e) {
      if (kDebugMode) {
        print('Error setting up real-time listeners: $e');
      }
      throw Exception('Failed to setup real-time notifications: $e');
    }
  }

  /// Subscribe to service alerts
  Future<void> _subscribeToServiceAlerts() async {
    try {
      const channelName = 'service_alerts';

      if (_activeChannels.containsKey(channelName)) {
        return; // Already subscribed
      }

      final channel = _supabase.channel(channelName);

      channel.onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'service_alerts',
        callback: (payload) {
          _handleServiceAlert(payload.newRecord);
        },
      );

      channel.onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'service_alerts',
        callback: (payload) {
          _handleServiceAlert(payload.newRecord);
        },
      );

      await channel.subscribe();
      _activeChannels[channelName] = channel;

      if (kDebugMode) {
        print('Subscribed to service alerts');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error subscribing to service alerts: $e');
      }
    }
  }

  /// Subscribe to booking status updates
  Future<void> _subscribeToBookingUpdates(String userId) async {
    try {
      final channelName = 'booking_updates_$userId';

      if (_activeChannels.containsKey(channelName)) {
        return; // Already subscribed
      }

      final channel = _supabase.channel(channelName);

      channel.onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'bookings',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'user_id',
          value: userId,
        ),
        callback: (payload) {
          _handleBookingUpdate(payload.newRecord);
        },
      );

      await channel.subscribe();
      _activeChannels[channelName] = channel;

      if (kDebugMode) {
        print('Subscribed to booking updates for user: $userId');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error subscribing to booking updates: $e');
      }
    }
  }

  /// Subscribe to payment status updates
  Future<void> _subscribeToPaymentUpdates(String userId) async {
    try {
      final channelName = 'payment_updates_$userId';

      if (_activeChannels.containsKey(channelName)) {
        return; // Already subscribed
      }

      final channel = _supabase.channel(channelName);

      channel.onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'payment_transactions',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'user_id',
          value: userId,
        ),
        callback: (payload) {
          _handlePaymentUpdate(payload.newRecord);
        },
      );

      await channel.subscribe();
      _activeChannels[channelName] = channel;

      if (kDebugMode) {
        print('Subscribed to payment updates for user: $userId');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error subscribing to payment updates: $e');
      }
    }
  }

  /// Subscribe to service status updates
  Future<void> _subscribeToServiceStatusUpdates() async {
    try {
      const channelName = 'service_status_updates';

      if (_activeChannels.containsKey(channelName)) {
        return; // Already subscribed
      }

      final channel = _supabase.channel(channelName);

      channel.onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'service_status',
        callback: (payload) {
          _handleServiceStatusUpdate(payload.newRecord);
        },
      );

      await channel.subscribe();
      _activeChannels[channelName] = channel;

      if (kDebugMode) {
        print('Subscribed to service status updates');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error subscribing to service status updates: $e');
      }
    }
  }

  // ==================== NOTIFICATION HANDLERS ====================

  /// Handle service alert notifications
  void _handleServiceAlert(Map<String, dynamic> alertData) {
    try {
      final notification = {
        'type': 'service_alert',
        'title': alertData['title'] ?? 'Service Update',
        'message': alertData['message'] ?? '',
        'alert_type': alertData['alert_type'] ?? 'info',
        'severity': alertData['severity'] ?? 'medium',
        'service_id': alertData['service_id'],
        'route_id': alertData['route_id'],
        'station_id': alertData['station_id'],
        'timestamp': DateTime.now().toIso8601String(),
        'data': alertData,
      };

      _broadcastNotification(notification);

      if (kDebugMode) {
        print('Service alert notification: ${notification['title']}');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error handling service alert: $e');
      }
    }
  }

  /// Handle booking status update notifications
  void _handleBookingUpdate(Map<String, dynamic> bookingData) {
    try {
      final status = bookingData['booking_status'] ?? '';
      final bookingReference = bookingData['booking_reference'] ?? '';

      String title;
      String message;

      switch (status) {
        case 'confirmed':
          title = 'Booking Confirmed';
          message =
              'Your booking $bookingReference has been confirmed. Have a great journey!';
          break;
        case 'cancelled':
          title = 'Booking Cancelled';
          message = 'Your booking $bookingReference has been cancelled.';
          break;
        case 'completed':
          title = 'Journey Complete';
          message =
              'Thank you for traveling with PRASA. We hope you enjoyed your journey!';
          break;
        default:
          title = 'Booking Update';
          message =
              'Your booking $bookingReference status has been updated to $status.';
      }

      final notification = {
        'type': 'booking_update',
        'title': title,
        'message': message,
        'booking_id': bookingData['id'],
        'booking_reference': bookingReference,
        'status': status,
        'timestamp': DateTime.now().toIso8601String(),
        'data': bookingData,
      };

      _broadcastNotification(notification);

      if (kDebugMode) {
        print('Booking update notification: $title');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error handling booking update: $e');
      }
    }
  }

  /// Handle payment status update notifications
  void _handlePaymentUpdate(Map<String, dynamic> paymentData) {
    try {
      final status = paymentData['payment_status'] ?? '';
      final amount = paymentData['amount'] ?? 0.0;
      final transactionReference = paymentData['transaction_reference'] ?? '';

      String title;
      String message;

      switch (status) {
        case 'completed':
          title = 'Payment Successful';
          message =
              'Your payment of R${amount.toStringAsFixed(2)} has been processed successfully.';
          break;
        case 'failed':
          title = 'Payment Failed';
          message =
              'Your payment of R${amount.toStringAsFixed(2)} could not be processed. Please try again.';
          break;
        case 'refunded':
          title = 'Payment Refunded';
          message =
              'Your refund of R${amount.toStringAsFixed(2)} has been processed and will reflect in your account shortly.';
          break;
        default:
          title = 'Payment Update';
          message = 'Your payment status has been updated to $status.';
      }

      final notification = {
        'type': 'payment_update',
        'title': title,
        'message': message,
        'transaction_id': paymentData['id'],
        'transaction_reference': transactionReference,
        'status': status,
        'amount': amount,
        'timestamp': DateTime.now().toIso8601String(),
        'data': paymentData,
      };

      _broadcastNotification(notification);

      if (kDebugMode) {
        print('Payment update notification: $title');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error handling payment update: $e');
      }
    }
  }

  /// Handle service status update notifications
  void _handleServiceStatusUpdate(Map<String, dynamic> statusData) {
    try {
      final status = statusData['status'] ?? '';
      final delayMinutes = statusData['delay_minutes'] ?? 0;
      final message = statusData['message'] ?? '';

      String title;
      String notificationMessage;

      switch (status) {
        case 'delayed':
          title = 'Service Delayed';
          notificationMessage =
              'Train service is delayed by $delayMinutes minutes. $message';
          break;
        case 'cancelled':
          title = 'Service Cancelled';
          notificationMessage = 'Train service has been cancelled. $message';
          break;
        case 'on_time':
          title = 'Service On Time';
          notificationMessage =
              'Train service is running on schedule. $message';
          break;
        default:
          title = 'Service Update';
          notificationMessage = 'Service status: $status. $message';
      }

      final notification = {
        'type': 'service_status',
        'title': title,
        'message': notificationMessage,
        'service_id': statusData['service_id'],
        'status': status,
        'delay_minutes': delayMinutes,
        'timestamp': DateTime.now().toIso8601String(),
        'data': statusData,
      };

      _broadcastNotification(notification);

      if (kDebugMode) {
        print('Service status notification: $title');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error handling service status update: $e');
      }
    }
  }

  // ==================== NOTIFICATION BROADCASTING ====================

  /// Broadcast notification to all listeners
  void _broadcastNotification(Map<String, dynamic> notification) {
    try {
      for (final listener in _notificationListeners) {
        try {
          listener(notification);
        } catch (e) {
          if (kDebugMode) {
            print('Error in notification listener: $e');
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error broadcasting notification: $e');
      }
    }
  }

  /// Add notification listener
  void addNotificationListener(Function(Map<String, dynamic>) listener) {
    _notificationListeners.add(listener);
    if (kDebugMode) {
      print(
          'Added notification listener. Total listeners: ${_notificationListeners.length}');
    }
  }

  /// Remove notification listener
  void removeNotificationListener(Function(Map<String, dynamic>) listener) {
    _notificationListeners.remove(listener);
    if (kDebugMode) {
      print(
          'Removed notification listener. Total listeners: ${_notificationListeners.length}');
    }
  }

  // ==================== NOTIFICATION PREFERENCES ====================

  /// Get user notification preferences
  Future<Map<String, dynamic>> getUserNotificationPreferences() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final response = await _supabase
          .from('travel_preferences')
          .select('notification_preferences')
          .eq('user_id', user.id)
          .maybeSingle();

      if (response != null) {
        return Map<String, dynamic>.from(
            response['notification_preferences'] ?? {});
      }

      // Return default preferences
      return {
        'delays': true,
        'cancellations': true,
        'platform_changes': true,
        'special_offers': false,
        'booking_updates': true,
        'payment_updates': true,
        'service_alerts': true,
      };
    } catch (e) {
      throw Exception('Failed to get notification preferences: $e');
    }
  }

  /// Update user notification preferences
  Future<void> updateNotificationPreferences(
      Map<String, dynamic> preferences) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      await _supabase.from('travel_preferences').upsert({
        'user_id': user.id,
        'notification_preferences': preferences,
      });

      if (kDebugMode) {
        print('Updated notification preferences');
      }
    } catch (e) {
      throw Exception('Failed to update notification preferences: $e');
    }
  }

  // ==================== PUSH NOTIFICATIONS ====================

  /// Send push notification (placeholder for actual push notification service)
  Future<void> sendPushNotification({
    required String title,
    required String message,
    Map<String, dynamic>? data,
  }) async {
    try {
      // This would integrate with a push notification service like Firebase Cloud Messaging
      // For now, we'll just log the notification

      if (kDebugMode) {
        print('Push Notification:');
        print('Title: $title');
        print('Message: $message');
        print('Data: $data');
      }

      // In a real implementation, you would:
      // 1. Get the user's device token(s)
      // 2. Send notification via FCM or similar service
      // 3. Handle notification delivery confirmation
    } catch (e) {
      if (kDebugMode) {
        print('Error sending push notification: $e');
      }
    }
  }

  /// Schedule notification for future delivery
  Future<void> scheduleNotification({
    required String title,
    required String message,
    required DateTime scheduledTime,
    Map<String, dynamic>? data,
  }) async {
    try {
      // This would integrate with a scheduled notification system
      // For now, we'll just log the scheduled notification

      if (kDebugMode) {
        print('Scheduled Notification:');
        print('Title: $title');
        print('Message: $message');
        print('Scheduled for: $scheduledTime');
        print('Data: $data');
      }

      // In a real implementation, you would:
      // 1. Store the scheduled notification in the database
      // 2. Set up a background job to send it at the scheduled time
      // 3. Handle timezone considerations
    } catch (e) {
      if (kDebugMode) {
        print('Error scheduling notification: $e');
      }
    }
  }

  // ==================== NOTIFICATION HISTORY ====================

  /// Get notification history for the user
  Future<List<Map<String, dynamic>>> getNotificationHistory({
    int limit = 50,
    String? type,
  }) async {
    try {
      // In a real implementation, this would query a notifications_log table
      // For now, return mock data

      return [
        {
          'id': '1',
          'type': 'service_alert',
          'title': 'Service Update',
          'message': 'All trains running on time this morning.',
          'timestamp': DateTime.now()
              .subtract(const Duration(hours: 2))
              .toIso8601String(),
          'read': true,
        },
        {
          'id': '2',
          'type': 'booking_update',
          'title': 'Booking Confirmed',
          'message': 'Your booking PRASA12345678 has been confirmed.',
          'timestamp': DateTime.now()
              .subtract(const Duration(days: 1))
              .toIso8601String(),
          'read': true,
        },
        {
          'id': '3',
          'type': 'payment_update',
          'title': 'Payment Successful',
          'message': 'Your payment of R45.50 has been processed successfully.',
          'timestamp': DateTime.now()
              .subtract(const Duration(days: 1))
              .toIso8601String(),
          'read': false,
        },
      ];
    } catch (e) {
      throw Exception('Failed to get notification history: $e');
    }
  }

  /// Mark notification as read
  Future<void> markNotificationAsRead(String notificationId) async {
    try {
      // In a real implementation, this would update the notifications_log table
      if (kDebugMode) {
        print('Marked notification $notificationId as read');
      }
    } catch (e) {
      throw Exception('Failed to mark notification as read: $e');
    }
  }

  // ==================== CLEANUP ====================

  /// Clean up all active channels
  void _cleanupChannels() {
    try {
      for (final channel in _activeChannels.values) {
        _supabase.removeChannel(channel);
      }
      _activeChannels.clear();

      if (kDebugMode) {
        print('Cleaned up all notification channels');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error cleaning up channels: $e');
      }
    }
  }

  /// Reconnect to real-time if connection is lost
  Future<void> reconnect() async {
    try {
      _cleanupChannels();
      await _setupRealtimeListeners();

      if (kDebugMode) {
        print('Reconnected to real-time notifications');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error reconnecting to notifications: $e');
      }
      throw Exception('Failed to reconnect to notifications: $e');
    }
  }

  // ==================== UTILITY METHODS ====================

  /// Get notification icon based on type
  String getNotificationIcon(String type) {
    switch (type) {
      case 'service_alert':
        return 'info';
      case 'booking_update':
        return 'confirmation_number';
      case 'payment_update':
        return 'payment';
      case 'service_status':
        return 'train';
      default:
        return 'notifications';
    }
  }

  /// Get notification color based on type and severity
  String getNotificationColor(String type, {String? severity}) {
    switch (type) {
      case 'service_alert':
        switch (severity) {
          case 'high':
            return 'red';
          case 'medium':
            return 'orange';
          case 'low':
            return 'blue';
          default:
            return 'blue';
        }
      case 'booking_update':
        return 'green';
      case 'payment_update':
        return 'purple';
      case 'service_status':
        return 'blue';
      default:
        return 'grey';
    }
  }

  /// Format notification timestamp for display
  String formatNotificationTime(String timestamp) {
    try {
      final dateTime = DateTime.parse(timestamp);
      final now = DateTime.now();
      final difference = now.difference(dateTime);

      if (difference.inMinutes < 1) {
        return 'Just now';
      } else if (difference.inMinutes < 60) {
        return '${difference.inMinutes}m ago';
      } else if (difference.inHours < 24) {
        return '${difference.inHours}h ago';
      } else {
        return '${difference.inDays}d ago';
      }
    } catch (e) {
      return 'Unknown';
    }
  }
}
