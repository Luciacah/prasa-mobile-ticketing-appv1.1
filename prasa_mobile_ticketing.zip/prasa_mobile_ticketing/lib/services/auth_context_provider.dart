import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_auth_service.dart';

/// Authentication Context Provider
/// Provides authentication state management across the app
class AuthContextProvider extends ChangeNotifier {
  static final AuthContextProvider _instance = AuthContextProvider._internal();
  factory AuthContextProvider() => _instance;
  AuthContextProvider._internal() {
    _initialize();
  }

  static AuthContextProvider get instance => _instance;

  User? _currentUser;
  Map<String, dynamic>? _userProfile;
  bool _isLoading = false;
  String? _errorMessage;

  // Getters
  User? get currentUser => _currentUser;
  Map<String, dynamic>? get userProfile => _userProfile;
  bool get isAuthenticated => _currentUser != null;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  /// Initialize auth context and listen to auth changes
  void _initialize() {
    // Listen to auth state changes
    SupabaseAuthService.instance.authStateChanges.listen((event) {
      _handleAuthStateChange(event);
    });

    // Set initial user if already signed in
    _currentUser = SupabaseAuthService.instance.currentUser;
    if (_currentUser != null) {
      _loadUserProfile();
    }
  }

  /// Handle authentication state changes
  void _handleAuthStateChange(AuthState event) {
    _currentUser = event.session?.user;

    if (_currentUser != null) {
      _loadUserProfile();
    } else {
      _userProfile = null;
      _clearError();
    }

    notifyListeners();
  }

  /// Load user profile data
  Future<void> _loadUserProfile() async {
    try {
      _setLoading(true);
      _userProfile = await SupabaseAuthService.instance.getUserProfile();
    } catch (e) {
      _setError('Failed to load user profile: ${e.toString()}');
      debugPrint('❌ Load user profile error: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Refresh user profile
  Future<void> refreshUserProfile() async {
    await _loadUserProfile();
  }

  /// Update user profile
  Future<bool> updateUserProfile(Map<String, dynamic> updates) async {
    try {
      _setLoading(true);
      await SupabaseAuthService.instance.updateUserProfile(updates);

      // Refresh profile data
      await _loadUserProfile();

      return true;
    } catch (e) {
      _setError('Failed to update profile: ${e.toString()}');
      debugPrint('❌ Update user profile error: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Update travel preferences
  Future<bool> updateTravelPreferences(Map<String, dynamic> preferences) async {
    try {
      _setLoading(true);
      await SupabaseAuthService.instance.updateTravelPreferences(preferences);
      return true;
    } catch (e) {
      _setError('Failed to update travel preferences: ${e.toString()}');
      debugPrint('❌ Update travel preferences error: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Sign out user
  Future<void> signOut() async {
    try {
      _setLoading(true);
      await SupabaseAuthService.instance.signOut();

      // Clear local state
      _currentUser = null;
      _userProfile = null;
      _clearError();

      notifyListeners();
    } catch (e) {
      _setError('Failed to sign out: ${e.toString()}');
      debugPrint('❌ Sign out error: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Check user role
  bool hasRole(String role) {
    return _userProfile?['role'] == role;
  }

  /// Check if user is admin
  bool get isAdmin => hasRole('admin');

  /// Check if user is manager
  bool get isManager => hasRole('manager');

  /// Check if user is passenger
  bool get isPassenger => hasRole('passenger');

  /// Get user display name
  String get displayName {
    if (_userProfile != null) {
      return _userProfile!['full_name'] ?? 'User';
    }
    return _currentUser?.email?.split('@').first ?? 'User';
  }

  /// Get user avatar URL
  String? get avatarUrl => _userProfile?['avatar_url'];

  /// Helper methods for state management
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  /// Clear error message
  void clearError() {
    _clearError();
  }
}

/// Widget for providing authentication context to the widget tree
class AuthContextWidget extends InheritedNotifier<AuthContextProvider> {
  const AuthContextWidget({
    Key? key,
    required Widget child,
  }) : super(key: key, notifier: AuthContextProvider.instance, child: child);

  static AuthContextProvider? of(BuildContext context) {
    return context
        .dependOnInheritedWidgetOfExactType<AuthContextWidget>()
        ?.notifier;
  }
}

/// Extension for easy access to auth context
extension AuthContextExtension on BuildContext {
  AuthContextProvider get auth {
    final provider = AuthContextWidget.of(this);
    assert(provider != null, 'AuthContextWidget not found in widget tree');
    return provider!;
  }
}
