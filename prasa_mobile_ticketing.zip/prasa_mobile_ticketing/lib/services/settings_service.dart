import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import './supabase_service.dart';
import './user_service.dart';

/// Settings Service
/// Handles application settings with local caching and Supabase sync
class SettingsService {
  static final SettingsService _instance = SettingsService._internal();
  factory SettingsService() => _instance;
  SettingsService._internal();

  static SettingsService get instance => _instance;

  SupabaseClient get _client => SupabaseService.instance.client;
  UserService get _userService => UserService.instance;

  // Default settings
  static const Map<String, dynamic> defaultSettings = {
    'theme_mode': 'system',
    'app_language': 'en',
    'data_sync_frequency': 'real_time',
    'auto_backup_enabled': true,
    'biometric_auth_enabled': false,
    'location_services_enabled': true,
    'analytics_enabled': true,
    'marketing_notifications': false,
    'security_notifications': true,
    'system_notifications': true,
    'offline_mode_enabled': false,
    'data_saver_mode': false,
    'auto_update_enabled': true,
  };

  /// Initialize settings (load from cache or create defaults)
  Future<Map<String, dynamic>> initializeSettings(String userId) async {
    try {
      // Try to load from cache first
      final cachedSettings = await _loadFromCache();

      if (cachedSettings.isNotEmpty) {
        // Sync with server in background if real-time sync is enabled
        if (cachedSettings['data_sync_frequency'] == 'real_time') {
          _syncWithServer(userId);
        }
        return cachedSettings;
      }

      // Load from server if no cache
      final serverSettings = await _userService.getUserSettings(userId);
      if (serverSettings != null) {
        await _saveToCache(serverSettings);
        return serverSettings;
      }

      // Return defaults if nothing found
      return Map<String, dynamic>.from(defaultSettings);
    } catch (e) {
      debugPrint('❌ Initialize settings error: $e');
      return Map<String, dynamic>.from(defaultSettings);
    }
  }

  /// Update a specific setting
  Future<bool> updateSetting(String userId, String key, dynamic value) async {
    try {
      final settings = await _loadFromCache();
      settings[key] = value;

      // Save to cache immediately
      await _saveToCache(settings);

      // Update server based on sync frequency
      final syncFrequency = settings['data_sync_frequency'] ?? 'real_time';
      if (syncFrequency == 'real_time') {
        await _userService.updateUserSettings(userId, {key: value});
      }

      debugPrint('✅ Setting updated: $key = $value');
      return true;
    } catch (e) {
      debugPrint('❌ Update setting error: $e');
      return false;
    }
  }

  /// Update multiple settings at once
  Future<bool> updateSettings(
      String userId, Map<String, dynamic> updates) async {
    try {
      final settings = await _loadFromCache();
      settings.addAll(updates);

      // Save to cache immediately
      await _saveToCache(settings);

      // Update server based on sync frequency
      final syncFrequency = settings['data_sync_frequency'] ?? 'real_time';
      if (syncFrequency == 'real_time') {
        await _userService.updateUserSettings(userId, updates);
      }

      debugPrint('✅ Settings updated: ${updates.keys.join(', ')}');
      return true;
    } catch (e) {
      debugPrint('❌ Update settings error: $e');
      return false;
    }
  }

  /// Get a specific setting value
  Future<T?> getSetting<T>(String key, [T? defaultValue]) async {
    try {
      final settings = await _loadFromCache();
      return settings[key] as T? ?? defaultValue;
    } catch (e) {
      debugPrint('❌ Get setting error: $e');
      return defaultValue;
    }
  }

  /// Get all settings
  Future<Map<String, dynamic>> getAllSettings() async {
    try {
      return await _loadFromCache();
    } catch (e) {
      debugPrint('❌ Get all settings error: $e');
      return Map<String, dynamic>.from(defaultSettings);
    }
  }

  /// Reset all settings to defaults
  Future<bool> resetToDefaults(String userId) async {
    try {
      await _saveToCache(Map<String, dynamic>.from(defaultSettings));
      await _userService.resetUserSettings(userId);

      debugPrint('✅ Settings reset to defaults');
      return true;
    } catch (e) {
      debugPrint('❌ Reset settings error: $e');
      return false;
    }
  }

  /// Force sync with server
  Future<bool> syncWithServer(String userId) async {
    return await _syncWithServer(userId);
  }

  /// Export settings for backup
  Future<Map<String, dynamic>?> exportSettings() async {
    try {
      final settings = await _loadFromCache();
      return {
        'settings': settings,
        'export_date': DateTime.now().toIso8601String(),
        'version': '1.0',
      };
    } catch (e) {
      debugPrint('❌ Export settings error: $e');
      return null;
    }
  }

  /// Import settings from backup
  Future<bool> importSettings(
      String userId, Map<String, dynamic> backup) async {
    try {
      if (backup['settings'] is Map<String, dynamic>) {
        final settings = backup['settings'] as Map<String, dynamic>;

        // Validate settings against defaults
        final validSettings = <String, dynamic>{};
        defaultSettings.forEach((key, defaultValue) {
          if (settings.containsKey(key)) {
            validSettings[key] = settings[key];
          } else {
            validSettings[key] = defaultValue;
          }
        });

        await _saveToCache(validSettings);
        await _userService.updateUserSettings(userId, validSettings);

        debugPrint('✅ Settings imported successfully');
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('❌ Import settings error: $e');
      return false;
    }
  }

  /// Check if settings need sync based on frequency
  Future<bool> needsSync() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastSync = prefs.getInt('last_settings_sync') ?? 0;
      final syncFrequency =
          await getSetting('data_sync_frequency', 'real_time');

      final now = DateTime.now().millisecondsSinceEpoch;

      switch (syncFrequency) {
        case 'real_time':
          return true;
        case 'hourly':
          return (now - lastSync) > (60 * 60 * 1000); // 1 hour
        case 'daily':
          return (now - lastSync) > (24 * 60 * 60 * 1000); // 24 hours
        case 'manual':
          return false;
        default:
          return true;
      }
    } catch (e) {
      debugPrint('❌ Check sync needs error: $e');
      return true;
    }
  }

  // Private helper methods

  Future<Map<String, dynamic>> _loadFromCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final settingsJson = prefs.getString('user_settings');

      if (settingsJson != null) {
        // In a real implementation, you would decode JSON here
        // For now, return defaults merged with any stored values
        return Map<String, dynamic>.from(defaultSettings);
      }

      return <String, dynamic>{};
    } catch (e) {
      debugPrint('❌ Load from cache error: $e');
      return <String, dynamic>{};
    }
  }

  Future<bool> _saveToCache(Map<String, dynamic> settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // In a real implementation, you would encode to JSON here
      await prefs.setString('user_settings', settings.toString());
      return true;
    } catch (e) {
      debugPrint('❌ Save to cache error: $e');
      return false;
    }
  }

  Future<bool> _syncWithServer(String userId) async {
    try {
      final localSettings = await _loadFromCache();
      final serverSettings = await _userService.getUserSettings(userId);

      if (serverSettings != null) {
        // Merge settings (server takes precedence for conflicts)
        final mergedSettings = <String, dynamic>{};
        mergedSettings.addAll(localSettings);
        mergedSettings.addAll(serverSettings);

        // Save merged settings locally
        await _saveToCache(mergedSettings);

        // Update last sync timestamp
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt(
            'last_settings_sync', DateTime.now().millisecondsSinceEpoch);

        debugPrint('✅ Settings synced with server');
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('❌ Sync with server error: $e');
      return false;
    }
  }
}
