import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';

/// Supabase Authentication Service
/// Handles all Supabase authentication operations including
/// email/password, Google Sign-In, and Apple Sign-In
class SupabaseAuthService {
  static final SupabaseAuthService _instance = SupabaseAuthService._internal();
  factory SupabaseAuthService() => _instance;
  SupabaseAuthService._internal();

  static SupabaseAuthService get instance => _instance;

  SupabaseClient get _client => SupabaseService.instance.client;
  GoogleSignIn? _googleSignIn;

  /// Initialize Google Sign In
  void _initializeGoogleSignIn() {
    if (_googleSignIn == null) {
      const webClientId = String.fromEnvironment('GOOGLE_WEB_CLIENT_ID', defaultValue: '');
      _googleSignIn = GoogleSignIn(
        serverClientId: kIsWeb ? null : webClientId,
      );
    }
  }

  /// Get current user
  User? get currentUser => _client.auth.currentUser;

  /// Check if user is signed in
  bool get isSignedIn => currentUser != null;

  /// Get auth state stream
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  /// Get user profile data
  Future<Map<String, dynamic>?> getUserProfile() async {
    try {
      if (currentUser == null) return null;

      final response = await _client
          .from('user_profiles')
          .select()
          .eq('id', currentUser!.id)
          .single();

      return response;
    } catch (e) {
      debugPrint('❌ Get user profile error: $e');
      return null;
    }
  }

  /// Sign up with email and password
  Future<AuthResponse?> signUpWithEmailAndPassword({
    required String email,
    required String password,
    Map<String, dynamic>? userData,
  }) async {
    try {
      final AuthResponse response = await _client.auth.signUp(
        email: email,
        password: password,
        data: userData, // This becomes raw_user_meta_data
      );

      if (response.user != null) {
        debugPrint('✅ User signed up successfully: ${response.user?.email}');
        return response;
      } else {
        throw Exception('Sign up failed: No user returned');
      }
    } on AuthException catch (e) {
      debugPrint('❌ Sign up error: ${e.message}');
      throw _handleAuthException(e);
    } catch (e) {
      debugPrint('❌ Unexpected sign up error: $e');
      throw Exception('An unexpected error occurred during sign up');
    }
  }

  /// Sign in with email and password
  Future<AuthResponse?> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      final AuthResponse response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user != null) {
        // Update last login time
        await _updateLastLogin(response.user!.id);
        debugPrint('✅ User signed in successfully: ${response.user?.email}');
        return response;
      } else {
        throw Exception('Sign in failed: No user returned');
      }
    } on AuthException catch (e) {
      debugPrint('❌ Sign in error: ${e.message}');
      throw _handleAuthException(e);
    } catch (e) {
      debugPrint('❌ Unexpected sign in error: $e');
      throw Exception('An unexpected error occurred during sign in');
    }
  }

  /// Sign in with Google
  Future<AuthResponse?> signInWithGoogle() async {
    try {
      _initializeGoogleSignIn();

      if (kIsWeb) {
        // Web implementation
        final success = await _client.auth.signInWithOAuth(
          OAuthProvider.google,
        );
        
        if (success) {
          // Wait for auth state change
          await Future.delayed(const Duration(milliseconds: 1000));
          if (currentUser != null) {
            await _updateLastLogin(currentUser!.id);
            debugPrint('✅ Google sign in successful: ${currentUser?.email}');
            return AuthResponse(user: currentUser, session: _client.auth.currentSession);
          }
        }
        return null;
      } else {
        // Native implementation
        const webClientId = String.fromEnvironment('GOOGLE_WEB_CLIENT_ID', defaultValue: '');
        
        if (webClientId.isEmpty) {
          throw Exception('Google Web Client ID not configured');
        }

        // Silent sign-in first, then show UI if needed
        GoogleSignInAccount? user = await _googleSignIn!.signInSilently();
        user ??= await _googleSignIn!.signIn();

        if (user == null) {
          debugPrint('❌ Google sign in cancelled by user');
          return null;
        }

        final googleAuth = await user.authentication;
        final idToken = googleAuth.idToken;

        if (idToken == null) {
          throw Exception('No ID Token found');
        }

        final response = await _client.auth.signInWithIdToken(
          provider: OAuthProvider.google,
          idToken: idToken,
          accessToken: googleAuth.accessToken,
        );

        if (response.user != null) {
          await _updateLastLogin(response.user!.id);
          debugPrint('✅ Google sign in successful: ${response.user?.email}');
          return response;
        }

        return null;
      }
    } on AuthException catch (e) {
      debugPrint('❌ Google sign in error: ${e.message}');
      throw _handleAuthException(e);
    } catch (e) {
      debugPrint('❌ Unexpected Google sign in error: $e');
      throw Exception('An unexpected error occurred during Google sign in');
    }
  }

  /// Sign in with Apple
  Future<AuthResponse?> signInWithApple() async {
    try {
      // Check if Apple Sign In is available
      if (!await SignInWithApple.isAvailable()) {
        throw Exception('Apple Sign In is not available on this device');
      }

      // Request Apple ID credential
      final appleCredential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
      );

      final response = await _client.auth.signInWithIdToken(
        provider: OAuthProvider.apple,
        idToken: appleCredential.identityToken!,
      );

      if (response.user != null) {
        // Update profile with Apple data if available
        if (appleCredential.givenName != null && appleCredential.familyName != null) {
          final displayName = '${appleCredential.givenName} ${appleCredential.familyName}';
          await _updateUserProfile(response.user!.id, {'full_name': displayName});
        }

        await _updateLastLogin(response.user!.id);
        debugPrint('✅ Apple sign in successful: ${response.user?.email}');
        return response;
      }

      return null;
    } on SignInWithAppleAuthorizationException catch (e) {
      debugPrint('❌ Apple sign in authorization error: ${e.code} - ${e.message}');
      throw Exception('Apple sign in was cancelled or failed');
    } on AuthException catch (e) {
      debugPrint('❌ Apple sign in error: ${e.message}');
      throw _handleAuthException(e);
    } catch (e) {
      debugPrint('❌ Unexpected Apple sign in error: $e');
      throw Exception('An unexpected error occurred during Apple sign in');
    }
  }

  /// Send password reset email
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _client.auth.resetPasswordForEmail(email);
      debugPrint('✅ Password reset email sent to: $email');
    } on AuthException catch (e) {
      debugPrint('❌ Password reset error: ${e.message}');
      throw _handleAuthException(e);
    } catch (e) {
      debugPrint('❌ Unexpected password reset error: $e');
      throw Exception('An unexpected error occurred while sending password reset email');
    }
  }

  /// Resend email confirmation
  Future<void> resendEmailConfirmation() async {
    try {
      if (currentUser?.email != null) {
        await _client.auth.resend(
          type: OtpType.signup,
          email: currentUser!.email!,
        );
        debugPrint('✅ Email confirmation resent to: ${currentUser!.email}');
      } else {
        throw Exception('No user email available');
      }
    } on AuthException catch (e) {
      debugPrint('❌ Email confirmation error: ${e.message}');
      throw _handleAuthException(e);
    } catch (e) {
      debugPrint('❌ Unexpected email confirmation error: $e');
      rethrow;
    }
  }

  /// Sign out
  Future<void> signOut() async {
    try {
      // Sign out from Google if signed in
      _initializeGoogleSignIn();
      if (!kIsWeb && _googleSignIn != null && await _googleSignIn!.isSignedIn()) {
        await _googleSignIn!.signOut();
      }

      // Sign out from Supabase
      await _client.auth.signOut();
      debugPrint('✅ User signed out successfully');
    } catch (e) {
      debugPrint('❌ Sign out error: $e');
      throw Exception('An unexpected error occurred during sign out');
    }
  }

  /// Update user profile
  Future<void> updateUserProfile(Map<String, dynamic> updates) async {
    try {
      if (currentUser == null) {
        throw Exception('No user signed in');
      }

      await _updateUserProfile(currentUser!.id, updates);
      debugPrint('✅ User profile updated successfully');
    } catch (e) {
      debugPrint('❌ Update profile error: $e');
      throw Exception('An unexpected error occurred while updating profile');
    }
  }

  /// Update travel preferences
  Future<void> updateTravelPreferences(Map<String, dynamic> preferences) async {
    try {
      if (currentUser == null) {
        throw Exception('No user signed in');
      }

      await _client
          .from('travel_preferences')
          .update(preferences)
          .eq('user_id', currentUser!.id);

      debugPrint('✅ Travel preferences updated successfully');
    } catch (e) {
      debugPrint('❌ Update travel preferences error: $e');
      throw Exception('An unexpected error occurred while updating travel preferences');
    }
  }

  /// Get travel preferences
  Future<Map<String, dynamic>?> getTravelPreferences() async {
    try {
      if (currentUser == null) return null;

      final response = await _client
          .from('travel_preferences')
          .select()
          .eq('user_id', currentUser!.id)
          .single();

      return response;
    } catch (e) {
      debugPrint('❌ Get travel preferences error: $e');
      return null;
    }
  }

  /// Private helper methods

  /// Update last login time
  Future<void> _updateLastLogin(String userId) async {
    try {
      await _client
          .from('user_profiles')
          .update({'last_login_at': DateTime.now().toIso8601String()})
          .eq('id', userId);
    } catch (e) {
      // Don't throw on last login update failure
      debugPrint('❌ Update last login error: $e');
    }
  }

  /// Update user profile helper
  Future<void> _updateUserProfile(String userId, Map<String, dynamic> updates) async {
    await _client
        .from('user_profiles')
        .update(updates)
        .eq('id', userId);
  }

  /// Handle Supabase Auth exceptions
  String _handleAuthException(AuthException e) {
    switch (e.message.toLowerCase()) {
      case 'invalid login credentials':
        return 'Invalid email or password. Please check your credentials and try again.';
      case 'email not confirmed':
        return 'Please check your email and click the confirmation link before signing in.';
      case 'user not found':
        return 'No account found with this email address.';
      case 'invalid email':
        return 'Please enter a valid email address.';
      case 'weak password':
        return 'Password is too weak. Please use at least 6 characters.';
      case 'email already registered':
      case 'user already registered':
        return 'An account with this email already exists. Try signing in instead.';
      case 'signup disabled':
        return 'Account registration is currently disabled. Please contact support.';
      case 'too many requests':
        return 'Too many requests. Please wait a moment before trying again.';
      case 'network error':
        return 'Network error. Please check your internet connection and try again.';
      default:
        return 'Authentication failed: ${e.message}';
    }
  }

  /// Get user data as Map
  Map<String, dynamic>? getUserData() {
    final user = currentUser;
    if (user == null) return null;

    return {
      'id': user.id,
      'email': user.email,
      'phone': user.phone,
      'emailConfirmed': user.emailConfirmedAt != null,
      'lastSignIn': user.lastSignInAt,
      'createdAt': user.createdAt,
      'userMetadata': user.userMetadata,
      'appMetadata': user.appMetadata,
    };
  }

  /// Check if user has specific role
  Future<bool> hasRole(String role) async {
    try {
      final profile = await getUserProfile();
      return profile?['role'] == role;
    } catch (e) {
      return false;
    }
  }

  /// Check if user is admin
  Future<bool> isAdmin() async {
    return await hasRole('admin');
  }

  /// Check if user is manager
  Future<bool> isManager() async {
    return await hasRole('manager');
  }
}