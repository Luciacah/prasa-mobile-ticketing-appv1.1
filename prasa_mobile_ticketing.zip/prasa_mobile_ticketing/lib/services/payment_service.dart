import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Service for handling payment processing and transactions
class PaymentService {
  static PaymentService? _instance;
  static PaymentService get instance => _instance ??= PaymentService._();
  PaymentService._();

  final Dio _dio = Dio();
  final SupabaseClient _supabase = Supabase.instance.client;

  // ==================== PAYMENT METHODS ====================

  /// Get available payment methods for the user
  Future<List<Map<String, dynamic>>> getAvailablePaymentMethods() async {
    try {
      // Return available payment methods in South Africa
      return [
        {
          'id': 'card',
          'name': 'Credit/Debit Card',
          'type': 'card',
          'icon': 'credit_card',
          'description': 'Visa, MasterCard, American Express',
          'enabled': true,
        },
        {
          'id': 'mobile_money',
          'name': 'Mobile Money',
          'type': 'mobile_money',
          'icon': 'phone_android',
          'description': 'MTN Mobile Money, Vodacom VodaPay',
          'enabled': true,
        },
        {
          'id': 'wallet',
          'name': 'Digital Wallet',
          'type': 'wallet',
          'icon': 'account_balance_wallet',
          'description': 'Stored balance in your PRASA account',
          'enabled': true,
        },
        {
          'id': 'cash',
          'name': 'Cash at Station',
          'type': 'cash',
          'icon': 'money',
          'description': 'Pay at ticket office or kiosk',
          'enabled': true,
        },
      ];
    } catch (e) {
      throw Exception('Failed to get payment methods: $e');
    }
  }

  // ==================== PAYMENT PROCESSING ====================

  /// Process payment for a booking
  Future<Map<String, dynamic>> processPayment({
    required String bookingId,
    required double amount,
    required String paymentMethod,
    required Map<String, dynamic> paymentDetails,
    String currency = 'ZAR',
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Create payment transaction record
      final transactionResponse = await _supabase
          .from('payment_transactions')
          .insert({
            'booking_id': bookingId,
            'user_id': user.id,
            'amount': amount,
            'currency': currency,
            'payment_method': paymentMethod,
            'payment_status': 'pending',
            'metadata': paymentDetails,
          })
          .select()
          .single();

      final transactionId = transactionResponse['id'];
      final transactionReference = transactionResponse['transaction_reference'];

      // Process payment based on method
      Map<String, dynamic> paymentResult;

      switch (paymentMethod) {
        case 'card':
          paymentResult = await _processCardPayment(
            transactionId,
            transactionReference,
            amount,
            currency,
            paymentDetails,
          );
          break;
        case 'mobile_money':
          paymentResult = await _processMobileMoneyPayment(
            transactionId,
            transactionReference,
            amount,
            currency,
            paymentDetails,
          );
          break;
        case 'wallet':
          paymentResult = await _processWalletPayment(
            transactionId,
            transactionReference,
            amount,
            currency,
            paymentDetails,
          );
          break;
        case 'cash':
          paymentResult = await _processCashPayment(
            transactionId,
            transactionReference,
            amount,
            currency,
            paymentDetails,
          );
          break;
        default:
          throw Exception('Unsupported payment method: $paymentMethod');
      }

      // Update transaction with payment result
      await _updateTransactionStatus(
        transactionId,
        paymentResult['status'],
        gatewayTransactionId: paymentResult['gateway_transaction_id'],
        failureReason: paymentResult['failure_reason'],
      );

      return {
        'transaction_id': transactionId,
        'transaction_reference': transactionReference,
        'status': paymentResult['status'],
        'payment_method': paymentMethod,
        'amount': amount,
        'currency': currency,
        'message': paymentResult['message'],
        'gateway_data': paymentResult['gateway_data'],
      };
    } catch (e) {
      if (kDebugMode) {
        print('Payment processing error: $e');
      }
      throw Exception('Payment processing failed: $e');
    }
  }

  // ==================== CARD PAYMENT PROCESSING ====================

  Future<Map<String, dynamic>> _processCardPayment(
    String transactionId,
    String transactionReference,
    double amount,
    String currency,
    Map<String, dynamic> cardDetails,
  ) async {
    try {
      // Simulate card payment processing
      // In a real implementation, this would integrate with a payment gateway like Stripe, PayGate, or Peach Payments

      await Future.delayed(
          const Duration(seconds: 2)); // Simulate network delay

      // Mock validation
      final cardNumber = cardDetails['card_number'] ?? '';
      final cvv = cardDetails['cvv'] ?? '';
      final expiryMonth = cardDetails['expiry_month'] ?? '';
      final expiryYear = cardDetails['expiry_year'] ?? '';

      // Basic validation
      if (cardNumber.isEmpty ||
          cvv.isEmpty ||
          expiryMonth.isEmpty ||
          expiryYear.isEmpty) {
        return {
          'status': 'failed',
          'message': 'Invalid card details provided',
          'failure_reason': 'Invalid card details',
          'gateway_transaction_id': null,
          'gateway_data': null,
        };
      }

      // Simulate different card scenarios for testing
      if (cardNumber.startsWith('4000000000000002')) {
        // Declined card
        return {
          'status': 'failed',
          'message': 'Card declined by bank',
          'failure_reason': 'Card declined',
          'gateway_transaction_id': null,
          'gateway_data': {'decline_code': 'generic_decline'},
        };
      } else if (cardNumber.startsWith('4000000000000119')) {
        // Processing error
        return {
          'status': 'failed',
          'message': 'Processing error occurred',
          'failure_reason': 'Processing error',
          'gateway_transaction_id': null,
          'gateway_data': {'error_code': 'processing_error'},
        };
      } else {
        // Successful payment
        final gatewayTransactionId =
            'gw_${DateTime.now().millisecondsSinceEpoch}';

        return {
          'status': 'completed',
          'message': 'Payment successful',
          'failure_reason': null,
          'gateway_transaction_id': gatewayTransactionId,
          'gateway_data': {
            'gateway': 'mock_gateway',
            'reference': gatewayTransactionId,
            'card_last_four': cardNumber.substring(cardNumber.length - 4),
            'card_brand': _getCardBrand(cardNumber),
          },
        };
      }
    } catch (e) {
      return {
        'status': 'failed',
        'message': 'Payment processing error: $e',
        'failure_reason': e.toString(),
        'gateway_transaction_id': null,
        'gateway_data': null,
      };
    }
  }

  // ==================== MOBILE MONEY PROCESSING ====================

  Future<Map<String, dynamic>> _processMobileMoneyPayment(
    String transactionId,
    String transactionReference,
    double amount,
    String currency,
    Map<String, dynamic> mobileDetails,
  ) async {
    try {
      await Future.delayed(
          const Duration(seconds: 3)); // Simulate network delay

      final phoneNumber = mobileDetails['phone_number'] ?? '';
      final provider = mobileDetails['provider'] ?? '';

      if (phoneNumber.isEmpty || provider.isEmpty) {
        return {
          'status': 'failed',
          'message': 'Invalid mobile money details',
          'failure_reason': 'Invalid mobile details',
          'gateway_transaction_id': null,
          'gateway_data': null,
        };
      }

      // Simulate mobile money processing
      final gatewayTransactionId =
          'mm_${DateTime.now().millisecondsSinceEpoch}';

      return {
        'status': 'completed',
        'message': 'Mobile money payment successful',
        'failure_reason': null,
        'gateway_transaction_id': gatewayTransactionId,
        'gateway_data': {
          'provider': provider,
          'phone_number': phoneNumber,
          'reference': gatewayTransactionId,
        },
      };
    } catch (e) {
      return {
        'status': 'failed',
        'message': 'Mobile money processing error: $e',
        'failure_reason': e.toString(),
        'gateway_transaction_id': null,
        'gateway_data': null,
      };
    }
  }

  // ==================== WALLET PAYMENT PROCESSING ====================

  Future<Map<String, dynamic>> _processWalletPayment(
    String transactionId,
    String transactionReference,
    double amount,
    String currency,
    Map<String, dynamic> walletDetails,
  ) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Check wallet balance (this would be stored in a user_wallets table)
      final walletBalance = await _getUserWalletBalance(user.id);

      if (walletBalance < amount) {
        return {
          'status': 'failed',
          'message': 'Insufficient wallet balance',
          'failure_reason': 'Insufficient funds',
          'gateway_transaction_id': null,
          'gateway_data': {
            'wallet_balance': walletBalance,
            'required_amount': amount,
          },
        };
      }

      // Deduct from wallet (simulate transaction)
      await _updateWalletBalance(user.id, walletBalance - amount);

      return {
        'status': 'completed',
        'message': 'Wallet payment successful',
        'failure_reason': null,
        'gateway_transaction_id': 'wallet_$transactionId',
        'gateway_data': {
          'previous_balance': walletBalance,
          'new_balance': walletBalance - amount,
          'amount_deducted': amount,
        },
      };
    } catch (e) {
      return {
        'status': 'failed',
        'message': 'Wallet payment error: $e',
        'failure_reason': e.toString(),
        'gateway_transaction_id': null,
        'gateway_data': null,
      };
    }
  }

  // ==================== CASH PAYMENT PROCESSING ====================

  Future<Map<String, dynamic>> _processCashPayment(
    String transactionId,
    String transactionReference,
    double amount,
    String currency,
    Map<String, dynamic> cashDetails,
  ) async {
    try {
      // For cash payments, we mark as pending and provide payment instructions
      return {
        'status': 'pending',
        'message':
            'Please complete payment at any PRASA ticket office or station kiosk',
        'failure_reason': null,
        'gateway_transaction_id': 'cash_$transactionId',
        'gateway_data': {
          'payment_reference': transactionReference,
          'amount_due': amount,
          'currency': currency,
          'instructions':
              'Show this reference number at the ticket office: $transactionReference',
          'valid_until':
              DateTime.now().add(const Duration(hours: 24)).toIso8601String(),
        },
      };
    } catch (e) {
      return {
        'status': 'failed',
        'message': 'Cash payment setup error: $e',
        'failure_reason': e.toString(),
        'gateway_transaction_id': null,
        'gateway_data': null,
      };
    }
  }

  // ==================== PAYMENT VALIDATION ====================

  /// Validate payment details before processing
  Map<String, dynamic> validatePaymentDetails(
    String paymentMethod,
    Map<String, dynamic> details,
  ) {
    switch (paymentMethod) {
      case 'card':
        return _validateCardDetails(details);
      case 'mobile_money':
        return _validateMobileMoneyDetails(details);
      case 'wallet':
        return _validateWalletDetails(details);
      case 'cash':
        return {'valid': true, 'errors': []};
      default:
        return {
          'valid': false,
          'errors': ['Unsupported payment method']
        };
    }
  }

  Map<String, dynamic> _validateCardDetails(Map<String, dynamic> details) {
    final errors = <String>[];

    final cardNumber = details['card_number'] ?? '';
    final cvv = details['cvv'] ?? '';
    final expiryMonth = details['expiry_month'] ?? '';
    final expiryYear = details['expiry_year'] ?? '';
    final cardholderName = details['cardholder_name'] ?? '';

    if (cardNumber.isEmpty ||
        cardNumber.length < 13 ||
        cardNumber.length > 19) {
      errors.add('Invalid card number');
    }

    if (cvv.isEmpty || cvv.length < 3 || cvv.length > 4) {
      errors.add('Invalid CVV');
    }

    if (expiryMonth.isEmpty ||
        int.tryParse(expiryMonth) == null ||
        int.parse(expiryMonth) < 1 ||
        int.parse(expiryMonth) > 12) {
      errors.add('Invalid expiry month');
    }

    if (expiryYear.isEmpty ||
        int.tryParse(expiryYear) == null ||
        int.parse(expiryYear) < DateTime.now().year) {
      errors.add('Invalid expiry year');
    }

    if (cardholderName.isEmpty) {
      errors.add('Cardholder name is required');
    }

    return {'valid': errors.isEmpty, 'errors': errors};
  }

  Map<String, dynamic> _validateMobileMoneyDetails(
      Map<String, dynamic> details) {
    final errors = <String>[];

    final phoneNumber = details['phone_number'] ?? '';
    final provider = details['provider'] ?? '';

    if (phoneNumber.isEmpty ||
        !RegExp(r'^\+?[1-9]\d{1,14}$').hasMatch(phoneNumber)) {
      errors.add('Invalid phone number');
    }

    if (provider.isEmpty ||
        !['mtn', 'vodacom', 'cell_c', 'telkom']
            .contains(provider.toLowerCase())) {
      errors.add('Invalid mobile money provider');
    }

    return {'valid': errors.isEmpty, 'errors': errors};
  }

  Map<String, dynamic> _validateWalletDetails(Map<String, dynamic> details) {
    // For wallet payments, we just need to ensure user is authenticated
    // Additional validation can be added here
    return {'valid': true, 'errors': []};
  }

  // ==================== TRANSACTION MANAGEMENT ====================

  /// Get payment transaction details
  Future<Map<String, dynamic>?> getPaymentTransaction(
      String transactionId) async {
    try {
      final response = await _supabase.from('payment_transactions').select('''
            *,
            booking:bookings(*,
              service:train_services(*,
                route:routes(*)
              )
            )
          ''').eq('id', transactionId).maybeSingle();

      return response;
    } catch (e) {
      throw Exception('Failed to fetch payment transaction: $e');
    }
  }

  /// Get user payment history
  Future<List<Map<String, dynamic>>> getUserPaymentHistory({
    int limit = 50,
    String? status,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      var query = _supabase
          .from('payment_transactions')
          .select('''
            *,
            booking:bookings(*,
              service:train_services(*,
                route:routes(*,
                  origin_station:stations!routes_origin_station_id_fkey(*),
                  destination_station:stations!routes_destination_station_id_fkey(*)
                )
              )
            )
          ''')
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(limit);

      if (status != null) {
        query = query.eq('payment_status', status);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch payment history: $e');
    }
  }

  /// Update transaction status
  Future<void> _updateTransactionStatus(
    String transactionId,
    String status, {
    String? gatewayTransactionId,
    String? failureReason,
  }) async {
    try {
      final updates = <String, dynamic>{'payment_status': status};

      if (gatewayTransactionId != null) {
        updates['gateway_transaction_id'] = gatewayTransactionId;
      }

      if (failureReason != null) {
        updates['failure_reason'] = failureReason;
      }

      if (status == 'completed') {
        updates['payment_date'] = DateTime.now().toIso8601String();
      }

      await _supabase
          .from('payment_transactions')
          .update(updates)
          .eq('id', transactionId);
    } catch (e) {
      throw Exception('Failed to update transaction status: $e');
    }
  }

  // ==================== REFUND OPERATIONS ====================

  /// Process refund for a payment
  Future<Map<String, dynamic>> processRefund({
    required String transactionId,
    required double refundAmount,
    required String reason,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get original transaction
      final transaction = await getPaymentTransaction(transactionId);
      if (transaction == null) {
        throw Exception('Transaction not found');
      }

      if (transaction['payment_status'] != 'completed') {
        throw Exception('Can only refund completed payments');
      }

      final originalAmount = double.parse(transaction['amount'].toString());
      if (refundAmount > originalAmount) {
        throw Exception('Refund amount cannot exceed original payment');
      }

      // Update transaction with refund information
      await _supabase.from('payment_transactions').update({
        'refund_amount': refundAmount,
        'refund_date': DateTime.now().toIso8601String(),
        'payment_status':
            refundAmount >= originalAmount ? 'refunded' : 'partially_refunded',
      }).eq('id', transactionId);

      // Process actual refund based on payment method
      String refundMethod = transaction['payment_method'];

      if (refundMethod == 'wallet') {
        // For wallet payments, add back to user's wallet
        final currentBalance = await _getUserWalletBalance(user.id);
        await _updateWalletBalance(user.id, currentBalance + refundAmount);
      }

      return {
        'success': true,
        'refund_amount': refundAmount,
        'refund_method': refundMethod,
        'processing_time':
            refundMethod == 'wallet' ? 'Immediate' : '3-5 business days',
        'message': 'Refund processed successfully',
      };
    } catch (e) {
      throw Exception('Failed to process refund: $e');
    }
  }

  // ==================== WALLET OPERATIONS ====================

  /// Get user wallet balance
  Future<double> _getUserWalletBalance(String userId) async {
    try {
      // This would query a user_wallets table
      // For now, return a mock balance
      return 150.00; // Mock wallet balance
    } catch (e) {
      return 0.0;
    }
  }

  /// Update user wallet balance
  Future<void> _updateWalletBalance(String userId, double newBalance) async {
    try {
      // This would update the user_wallets table
      // Mock implementation - in real app this would be a database operation
      if (kDebugMode) {
        print('Updated wallet balance for user $userId to R$newBalance');
      }
    } catch (e) {
      throw Exception('Failed to update wallet balance: $e');
    }
  }

  // ==================== HELPER METHODS ====================

  /// Get card brand from card number
  String _getCardBrand(String cardNumber) {
    if (cardNumber.startsWith('4')) return 'Visa';
    if (cardNumber.startsWith('5') || cardNumber.startsWith('2'))
      return 'MasterCard';
    if (cardNumber.startsWith('3')) return 'American Express';
    return 'Unknown';
  }

  /// Format amount for display
  String formatAmount(double amount, {String currency = 'ZAR'}) {
    return 'R${amount.toStringAsFixed(2)}';
  }

  /// Get payment status display text
  String getPaymentStatusText(String status) {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'processing':
        return 'Processing';
      case 'completed':
        return 'Completed';
      case 'failed':
        return 'Failed';
      case 'refunded':
        return 'Refunded';
      case 'partially_refunded':
        return 'Partially Refunded';
      default:
        return 'Unknown';
    }
  }

  /// Get payment method display name
  String getPaymentMethodDisplayName(String method) {
    switch (method) {
      case 'card':
        return 'Credit/Debit Card';
      case 'mobile_money':
        return 'Mobile Money';
      case 'wallet':
        return 'Digital Wallet';
      case 'cash':
        return 'Cash Payment';
      default:
        return method;
    }
  }
}
