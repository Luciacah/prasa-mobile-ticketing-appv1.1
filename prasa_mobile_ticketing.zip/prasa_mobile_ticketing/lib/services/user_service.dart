import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';
import 'supabase_service.dart';

/// User Service
/// Handles user-related database operations and profile management
class UserService {
  static final UserService _instance = UserService._internal();
  factory UserService() => _instance;
  UserService._internal();

  static UserService get instance => _instance;

  SupabaseClient get _client => SupabaseService.instance.client;

  /// Get user profile by ID
  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final response = await _client.from('user_profiles').select('''
            id, email, full_name, phone, avatar_url,
            date_of_birth, role, status, preferred_language,
            home_station, work_station, is_email_verified,
            created_at, updated_at, last_login_at
          ''').eq('id', userId).single();

      return response;
    } catch (e) {
      debugPrint('❌ Get user profile error: $e');
      return null;
    }
  }

  /// Update user profile
  Future<bool> updateUserProfile(
      String userId, Map<String, dynamic> updates) async {
    try {
      // Remove null values and empty strings
      final cleanUpdates = <String, dynamic>{};
      updates.forEach((key, value) {
        if (value != null && value.toString().isNotEmpty) {
          cleanUpdates[key] = value;
        }
      });

      if (cleanUpdates.isEmpty) {
        return true; // Nothing to update
      }

      await _client.from('user_profiles').update(cleanUpdates).eq('id', userId);

      debugPrint('✅ User profile updated successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Update user profile error: $e');
      return false;
    }
  }

  /// Get travel preferences for user
  Future<Map<String, dynamic>?> getTravelPreferences(String userId) async {
    try {
      final response = await _client.from('travel_preferences').select('''
            id, user_id, preferred_travel_time,
            accessibility_needs, notification_preferences,
            created_at, updated_at
          ''').eq('user_id', userId).single();

      return response;
    } catch (e) {
      debugPrint('❌ Get travel preferences error: $e');
      return null;
    }
  }

  /// Update travel preferences
  Future<bool> updateTravelPreferences(
      String userId, Map<String, dynamic> preferences) async {
    try {
      final existingPrefs = await getTravelPreferences(userId);

      if (existingPrefs != null) {
        // Update existing preferences
        await _client
            .from('travel_preferences')
            .update(preferences)
            .eq('user_id', userId);
      } else {
        // Create new preferences
        final newPrefs = {
          'user_id': userId,
          ...preferences,
        };
        await _client.from('travel_preferences').insert(newPrefs);
      }

      debugPrint('✅ Travel preferences updated successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Update travel preferences error: $e');
      return false;
    }
  }

  /// Search users by role (admin only)
  Future<List<Map<String, dynamic>>> searchUsersByRole(String role) async {
    try {
      final response = await _client.from('user_profiles').select('''
            id, email, full_name, role, status, 
            created_at, last_login_at
          ''').eq('role', role).order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('❌ Search users by role error: $e');
      return [];
    }
  }

  /// Get user statistics (admin only)
  Future<Map<String, int>> getUserStatistics() async {
    try {
      // Get total users count
      final totalResponse = await _client
          .from('user_profiles')
          .select('id', const FetchOptions(count: CountOption.exact));

      // Get active users count
      final activeResponse = await _client
          .from('user_profiles')
          .select('id', const FetchOptions(count: CountOption.exact))
          .eq('status', 'active');

      // Get users by role
      final adminResponse = await _client
          .from('user_profiles')
          .select('id', const FetchOptions(count: CountOption.exact))
          .eq('role', 'admin');

      final managerResponse = await _client
          .from('user_profiles')
          .select('id', const FetchOptions(count: CountOption.exact))
          .eq('role', 'manager');

      final passengerResponse = await _client
          .from('user_profiles')
          .select('id', const FetchOptions(count: CountOption.exact))
          .eq('role', 'passenger');

      return {
        'total_users': totalResponse.count ?? 0,
        'active_users': activeResponse.count ?? 0,
        'admin_users': adminResponse.count ?? 0,
        'manager_users': managerResponse.count ?? 0,
        'passenger_users': passengerResponse.count ?? 0,
      };
    } catch (e) {
      debugPrint('❌ Get user statistics error: $e');
      return {
        'total_users': 0,
        'active_users': 0,
        'admin_users': 0,
        'manager_users': 0,
        'passenger_users': 0,
      };
    }
  }

  /// Update user status (admin only)
  Future<bool> updateUserStatus(String userId, String status) async {
    try {
      await _client
          .from('user_profiles')
          .update({'status': status}).eq('id', userId);

      debugPrint('✅ User status updated successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Update user status error: $e');
      return false;
    }
  }

  /// Delete user account (admin only)
  Future<bool> deleteUserAccount(String userId) async {
    try {
      // First delete travel preferences
      await _client.from('travel_preferences').delete().eq('user_id', userId);

      // Then delete user profile
      await _client.from('user_profiles').delete().eq('id', userId);

      debugPrint('✅ User account deleted successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Delete user account error: $e');
      return false;
    }
  }

  /// Verify user email
  Future<bool> verifyUserEmail(String userId) async {
    try {
      await _client
          .from('user_profiles')
          .update({'is_email_verified': true}).eq('id', userId);

      debugPrint('✅ User email verified successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Verify user email error: $e');
      return false;
    }
  }

  /// Get recently active users
  Future<List<Map<String, dynamic>>> getRecentlyActiveUsers(
      {int limit = 10}) async {
    try {
      final response = await _client
          .from('user_profiles')
          .select('''
            id, email, full_name, role, last_login_at,
            avatar_url
          ''')
          .not('last_login_at', 'is', null)
          .order('last_login_at', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('❌ Get recently active users error: $e');
      return [];
    }
  }

  /// Get user settings
  Future<Map<String, dynamic>?> getUserSettings(String userId) async {
    try {
      final response = await _client.from('user_settings').select('''
            id, user_id, theme_mode, app_language, data_sync_frequency,
            auto_backup_enabled, biometric_auth_enabled, location_services_enabled,
            analytics_enabled, marketing_notifications, security_notifications,
            system_notifications, offline_mode_enabled, data_saver_mode,
            auto_update_enabled, created_at, updated_at
          ''').eq('user_id', userId).single();

      return response;
    } catch (e) {
      debugPrint('❌ Get user settings error: $e');
      return null;
    }
  }

  /// Update user settings
  Future<bool> updateUserSettings(
      String userId, Map<String, dynamic> settings) async {
    try {
      // Remove null values and empty strings
      final cleanSettings = <String, dynamic>{};
      settings.forEach((key, value) {
        if (value != null) {
          cleanSettings[key] = value;
        }
      });

      if (cleanSettings.isEmpty) {
        return true; // Nothing to update
      }

      await _client
          .from('user_settings')
          .update(cleanSettings)
          .eq('user_id', userId);

      // Log the activity
      await logUserActivity(userId, 'settings_updated', 'user_settings', null,
          null, cleanSettings);

      debugPrint('✅ User settings updated successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Update user settings error: $e');
      return false;
    }
  }

  /// Create or update user session
  Future<bool> createUserSession(
      String userId, Map<String, dynamic> sessionData) async {
    try {
      await _client.from('user_sessions').insert({
        'user_id': userId,
        'session_token': sessionData['session_token'],
        'device_info': sessionData['device_info'],
        'ip_address': sessionData['ip_address'],
      });

      debugPrint('✅ User session created successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Create user session error: $e');
      return false;
    }
  }

  /// End user session
  Future<bool> endUserSession(String sessionToken) async {
    try {
      await _client.from('user_sessions').update({
        'logout_at': DateTime.now().toIso8601String(),
        'is_active': false,
      }).eq('session_token', sessionToken);

      debugPrint('✅ User session ended successfully');
      return true;
    } catch (e) {
      debugPrint('❌ End user session error: $e');
      return false;
    }
  }

  /// Get user active sessions
  Future<List<Map<String, dynamic>>> getUserActiveSessions(
      String userId) async {
    try {
      final response = await _client
          .from('user_sessions')
          .select('''
            id, session_token, device_info, ip_address,
            login_at, is_active
          ''')
          .eq('user_id', userId)
          .eq('is_active', true)
          .order('login_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('❌ Get user active sessions error: $e');
      return [];
    }
  }

  /// Log user activity
  Future<bool> logUserActivity(
    String userId,
    String actionType, [
    String? tableName,
    String? recordId,
    Map<String, dynamic>? oldValues,
    Map<String, dynamic>? newValues,
  ]) async {
    try {
      await _client.rpc('log_user_activity', params: {
        'p_user_id': userId,
        'p_action_type': actionType,
        'p_table_name': tableName,
        'p_record_id': recordId,
        'p_old_values': oldValues,
        'p_new_values': newValues,
      });

      return true;
    } catch (e) {
      debugPrint('❌ Log user activity error: $e');
      return false;
    }
  }

  /// Get user activity logs
  Future<List<Map<String, dynamic>>> getUserActivityLogs(String userId,
      {int limit = 50}) async {
    try {
      final response = await _client
          .from('user_activity_logs')
          .select('''
            id, action_type, table_name, record_id,
            old_values, new_values, created_at
          ''')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('❌ Get user activity logs error: $e');
      return [];
    }
  }

  /// Update last login timestamp
  Future<bool> updateLastLogin(String userId) async {
    try {
      await _client.from('user_profiles').update(
          {'last_login_at': DateTime.now().toIso8601String()}).eq('id', userId);

      await logUserActivity(userId, 'login');

      debugPrint('✅ Last login updated successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Update last login error: $e');
      return false;
    }
  }

  /// Reset user settings to default
  Future<bool> resetUserSettings(String userId) async {
    try {
      await _client.from('user_settings').update({
        'theme_mode': 'system',
        'app_language': 'en',
        'data_sync_frequency': 'real_time',
        'auto_backup_enabled': true,
        'biometric_auth_enabled': false,
        'location_services_enabled': true,
        'analytics_enabled': true,
        'marketing_notifications': false,
        'security_notifications': true,
        'system_notifications': true,
        'offline_mode_enabled': false,
        'data_saver_mode': false,
        'auto_update_enabled': true,
      }).eq('user_id', userId);

      await logUserActivity(userId, 'settings_reset');

      debugPrint('✅ User settings reset to defaults');
      return true;
    } catch (e) {
      debugPrint('❌ Reset user settings error: $e');
      return false;
    }
  }

  /// Export user data (GDPR compliance)
  Future<Map<String, dynamic>?> exportUserData(String userId) async {
    try {
      final profile = await getUserProfile(userId);
      final settings = await getUserSettings(userId);
      final travelPrefs = await getTravelPreferences(userId);
      final sessions = await getUserActiveSessions(userId);
      final activityLogs = await getUserActivityLogs(userId, limit: 100);

      return {
        'profile': profile,
        'settings': settings,
        'travel_preferences': travelPrefs,
        'active_sessions': sessions,
        'activity_logs': activityLogs,
        'export_date': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      debugPrint('❌ Export user data error: $e');
      return null;
    }
  }

  /// Deactivate user account
  Future<bool> deactivateAccount(String userId) async {
    try {
      // Update user status to inactive
      await _client
          .from('user_profiles')
          .update({'status': 'inactive'}).eq('id', userId);

      // End all active sessions
      await _client.from('user_sessions').update({
        'logout_at': DateTime.now().toIso8601String(),
        'is_active': false,
      }).eq('user_id', userId);

      await logUserActivity(userId, 'account_deactivated');

      debugPrint('✅ User account deactivated successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Deactivate account error: $e');
      return false;
    }
  }
}
