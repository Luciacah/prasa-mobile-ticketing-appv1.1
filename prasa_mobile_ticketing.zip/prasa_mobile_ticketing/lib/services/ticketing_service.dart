import 'package:supabase_flutter/supabase_flutter.dart';

/// Service for managing train schedules, bookings, and ticketing operations
class TicketingService {
  static TicketingService? _instance;
  static TicketingService get instance => _instance ??= TicketingService._();
  TicketingService._();

  final SupabaseClient _supabase = Supabase.instance.client;

  // ==================== STATION OPERATIONS ====================

  /// Get all active train stations
  Future<List<Map<String, dynamic>>> getStations() async {
    try {
      final response = await _supabase
          .from('stations')
          .select('*')
          .eq('is_active', true)
          .order('city')
          .order('name');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch stations: $e');
    }
  }

  /// Get stations by city
  Future<List<Map<String, dynamic>>> getStationsByCity(String city) async {
    try {
      final response = await _supabase
          .from('stations')
          .select('*')
          .eq('is_active', true)
          .eq('city', city)
          .order('name');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch stations for city $city: $e');
    }
  }

  /// Search stations by name
  Future<List<Map<String, dynamic>>> searchStations(String query) async {
    try {
      final response = await _supabase
          .from('stations')
          .select('*')
          .eq('is_active', true)
          .ilike('name', '%$query%')
          .order('name')
          .limit(20);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to search stations: $e');
    }
  }

  // ==================== ROUTE OPERATIONS ====================

  /// Get routes between two stations
  Future<List<Map<String, dynamic>>> getRoutesBetweenStations(
    String originStationId,
    String destinationStationId,
  ) async {
    try {
      final response = await _supabase
          .from('routes')
          .select('''
            *,
            origin_station:stations!routes_origin_station_id_fkey(id, name, code, city),
            destination_station:stations!routes_destination_station_id_fkey(id, name, code, city),
            train_services(*)
          ''')
          .eq('is_active', true)
          .or('origin_station_id.eq.$originStationId,destination_station_id.eq.$originStationId')
          .or('origin_station_id.eq.$destinationStationId,destination_station_id.eq.$destinationStationId');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch routes: $e');
    }
  }

  /// Get all available routes
  Future<List<Map<String, dynamic>>> getAllRoutes() async {
    try {
      final response = await _supabase.from('routes').select('''
            *,
            origin_station:stations!routes_origin_station_id_fkey(id, name, code, city),
            destination_station:stations!routes_destination_station_id_fkey(id, name, code, city)
          ''').eq('is_active', true).order('route_number');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch all routes: $e');
    }
  }

  // ==================== SERVICE OPERATIONS ====================

  /// Get train services for a specific route
  Future<List<Map<String, dynamic>>> getServicesForRoute(String routeId) async {
    try {
      final response = await _supabase
          .from('train_services')
          .select('''
            *,
            route:routes(*, 
              origin_station:stations!routes_origin_station_id_fkey(*),
              destination_station:stations!routes_destination_station_id_fkey(*)
            ),
            service_schedules(*),
            service_status(*)
          ''')
          .eq('route_id', routeId)
          .eq('is_active', true)
          .order('service_number');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch services for route: $e');
    }
  }

  /// Get service schedules for a specific date
  Future<List<Map<String, dynamic>>> getServiceSchedules(
    String serviceId,
    DateTime date,
  ) async {
    try {
      // Check which day of week to filter by service operating days
      final dayOfWeek = date.weekday;
      final dayColumn = _getDayColumn(dayOfWeek);

      final response = await _supabase
          .from('service_schedules')
          .select('''
            *,
            service:train_services!inner(*, $dayColumn)
          ''')
          .eq('service_id', serviceId)
          .eq('service.is_active', true)
          .eq('service.$dayColumn', true)
          .lte('effective_from', date.toIso8601String().split('T')[0])
          .or('effective_until.is.null,effective_until.gte.${date.toIso8601String().split('T')[0]}')
          .order('departure_time');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch service schedules: $e');
    }
  }

  /// Get current service status
  Future<Map<String, dynamic>?> getServiceStatus(
    String serviceId,
    DateTime date,
  ) async {
    try {
      final response = await _supabase
          .from('service_status')
          .select('''
            *,
            service:train_services(*),
            current_station:stations(*)
          ''')
          .eq('service_id', serviceId)
          .eq('schedule_date', date.toIso8601String().split('T')[0])
          .maybeSingle();

      return response;
    } catch (e) {
      throw Exception('Failed to fetch service status: $e');
    }
  }

  // ==================== FARE CALCULATIONS ====================

  /// Calculate fare for a journey
  Future<Map<String, dynamic>> calculateFare(
    String routeId,
    String ticketType,
    String ticketClass,
    int passengerCount,
    DateTime travelTime,
  ) async {
    try {
      final response = await _supabase.rpc('calculate_fare', params: {
        'p_route_id': routeId,
        'p_ticket_type': ticketType,
        'p_ticket_class': ticketClass,
        'p_travel_time':
            '${travelTime.hour.toString().padLeft(2, '0')}:${travelTime.minute.toString().padLeft(2, '0')}:00',
      });

      final baseFare = double.parse(response.toString());
      final totalFare = baseFare * passengerCount;

      return {
        'base_fare': baseFare,
        'passenger_count': passengerCount,
        'total_fare': totalFare,
        'currency': 'ZAR',
        'ticket_type': ticketType,
        'ticket_class': ticketClass,
      };
    } catch (e) {
      throw Exception('Failed to calculate fare: $e');
    }
  }

  /// Get fare prices for a route
  Future<List<Map<String, dynamic>>> getFarePrices(String routeId) async {
    try {
      final response = await _supabase
          .from('fare_prices')
          .select('*')
          .eq('route_id', routeId)
          .eq('is_active', true)
          .lte('effective_from', DateTime.now().toIso8601String().split('T')[0])
          .or('effective_until.is.null,effective_until.gte.${DateTime.now().toIso8601String().split('T')[0]}')
          .order('ticket_type')
          .order('ticket_class');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch fare prices: $e');
    }
  }

  // ==================== BOOKING OPERATIONS ====================

  /// Create a new booking
  Future<Map<String, dynamic>> createBooking({
    required String serviceId,
    required String originStationId,
    required String destinationStationId,
    required DateTime travelDate,
    required String departureTime,
    required String ticketType,
    required String ticketClass,
    required double totalAmount,
    required List<Map<String, String>> passengers,
    String? specialRequirements,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Create booking
      final bookingResponse = await _supabase
          .from('bookings')
          .insert({
            'user_id': user.id,
            'service_id': serviceId,
            'origin_station_id': originStationId,
            'destination_station_id': destinationStationId,
            'travel_date': travelDate.toIso8601String().split('T')[0],
            'departure_time': departureTime,
            'ticket_type': ticketType,
            'ticket_class': ticketClass,
            'passenger_count': passengers.length,
            'total_amount': totalAmount,
            'special_requirements': specialRequirements,
          })
          .select()
          .single();

      final bookingId = bookingResponse['id'];

      // Add passengers
      final passengerData = passengers
          .map((passenger) => {
                'booking_id': bookingId,
                'passenger_name': passenger['name']!,
                'passenger_age': int.tryParse(passenger['age'] ?? ''),
                'passenger_id_number': passenger['id_number'],
                'passenger_type': passenger['type'] ?? 'adult',
              })
          .toList();

      await _supabase.from('booking_passengers').insert(passengerData);

      return bookingResponse;
    } catch (e) {
      throw Exception('Failed to create booking: $e');
    }
  }

  /// Get user bookings
  Future<List<Map<String, dynamic>>> getUserBookings({
    String? status,
    int limit = 50,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      var query = _supabase
          .from('bookings')
          .select('''
            *,
            service:train_services(*,
              route:routes(*,
                origin_station:stations!routes_origin_station_id_fkey(*),
                destination_station:stations!routes_destination_station_id_fkey(*)
              )
            ),
            origin_station:stations!bookings_origin_station_id_fkey(*),
            destination_station:stations!bookings_destination_station_id_fkey(*),
            booking_passengers(*),
            payment_transactions(*),
            digital_tickets(*)
          ''')
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(limit);

      if (status != null) {
        query = query.eq('booking_status', status);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch user bookings: $e');
    }
  }

  /// Update booking status
  Future<Map<String, dynamic>> updateBookingStatus(
    String bookingId,
    String status,
  ) async {
    try {
      final response = await _supabase
          .from('bookings')
          .update({'booking_status': status})
          .eq('id', bookingId)
          .select()
          .single();

      return response;
    } catch (e) {
      throw Exception('Failed to update booking status: $e');
    }
  }

  /// Cancel booking
  Future<bool> cancelBooking(String bookingId) async {
    try {
      await _supabase
          .from('bookings')
          .update({'booking_status': 'cancelled'}).eq('id', bookingId);

      return true;
    } catch (e) {
      throw Exception('Failed to cancel booking: $e');
    }
  }

  // ==================== PAYMENT OPERATIONS ====================

  /// Create payment transaction
  Future<Map<String, dynamic>> createPaymentTransaction({
    required String bookingId,
    required double amount,
    required String paymentMethod,
    String currency = 'ZAR',
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final response = await _supabase
          .from('payment_transactions')
          .insert({
            'booking_id': bookingId,
            'user_id': user.id,
            'amount': amount,
            'currency': currency,
            'payment_method': paymentMethod,
            'metadata': metadata,
          })
          .select()
          .single();

      return response;
    } catch (e) {
      throw Exception('Failed to create payment transaction: $e');
    }
  }

  /// Update payment transaction status
  Future<Map<String, dynamic>> updatePaymentStatus(
    String transactionId,
    String status, {
    String? gatewayTransactionId,
    String? failureReason,
  }) async {
    try {
      final updates = <String, dynamic>{'payment_status': status};

      if (gatewayTransactionId != null) {
        updates['gateway_transaction_id'] = gatewayTransactionId;
      }
      if (failureReason != null) {
        updates['failure_reason'] = failureReason;
      }
      if (status == 'completed') {
        updates['payment_date'] = DateTime.now().toIso8601String();
      }

      final response = await _supabase
          .from('payment_transactions')
          .update(updates)
          .eq('id', transactionId)
          .select()
          .single();

      return response;
    } catch (e) {
      throw Exception('Failed to update payment status: $e');
    }
  }

  // ==================== DIGITAL TICKET OPERATIONS ====================

  /// Generate digital ticket after successful payment
  Future<Map<String, dynamic>> generateDigitalTicket({
    required String bookingId,
    required String passengerId,
    required DateTime validFrom,
    required DateTime validUntil,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Generate QR code data (booking_id + passenger_id + timestamp)
      final qrData =
          '$bookingId:$passengerId:${DateTime.now().millisecondsSinceEpoch}';

      final response = await _supabase
          .from('digital_tickets')
          .insert({
            'booking_id': bookingId,
            'passenger_id': passengerId,
            'user_id': user.id,
            'qr_code_data': qrData,
            'barcode_data': qrData,
            'valid_from': validFrom.toIso8601String(),
            'valid_until': validUntil.toIso8601String(),
          })
          .select()
          .single();

      return response;
    } catch (e) {
      throw Exception('Failed to generate digital ticket: $e');
    }
  }

  /// Get user digital tickets
  Future<List<Map<String, dynamic>>> getUserDigitalTickets({
    String? status,
    int limit = 50,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      var query = _supabase
          .from('digital_tickets')
          .select('''
            *,
            booking:bookings(*,
              service:train_services(*,
                route:routes(*,
                  origin_station:stations!routes_origin_station_id_fkey(*),
                  destination_station:stations!routes_destination_station_id_fkey(*)
                )
              ),
              origin_station:stations!bookings_origin_station_id_fkey(*),
              destination_station:stations!bookings_destination_station_id_fkey(*)
            ),
            passenger:booking_passengers(*)
          ''')
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(limit);

      if (status != null) {
        query = query.eq('ticket_status', status);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch digital tickets: $e');
    }
  }

  /// Validate digital ticket
  Future<Map<String, dynamic>> validateTicket(String ticketId) async {
    try {
      final response = await _supabase
          .from('digital_tickets')
          .update({
            'ticket_status': 'used',
            'used_at': DateTime.now().toIso8601String(),
          })
          .eq('id', ticketId)
          .select()
          .single();

      return response;
    } catch (e) {
      throw Exception('Failed to validate ticket: $e');
    }
  }

  // ==================== SERVICE ALERTS ====================

  /// Get active service alerts
  Future<List<Map<String, dynamic>>> getServiceAlerts({
    String? serviceId,
    String? routeId,
  }) async {
    try {
      var query = _supabase
          .from('service_alerts')
          .select('''
            *,
            service:train_services(*),
            route:routes(*),
            station:stations(*)
          ''')
          .eq('is_active', true)
          .lte('starts_at', DateTime.now().toIso8601String())
          .or('expires_at.is.null,expires_at.gt.${DateTime.now().toIso8601String()}')
          .order('created_at', ascending: false);

      if (serviceId != null) {
        query = query.eq('service_id', serviceId);
      }
      if (routeId != null) {
        query = query.eq('route_id', routeId);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch service alerts: $e');
    }
  }

  // ==================== USER SUBSCRIPTIONS ====================

  /// Subscribe to route/service notifications
  Future<Map<String, dynamic>> subscribeToNotifications({
    String? routeId,
    String? serviceId,
    String? stationId,
    List<String> notificationTypes = const ['delays', 'cancellations'],
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final response = await _supabase
          .from('user_route_subscriptions')
          .insert({
            'user_id': user.id,
            'route_id': routeId,
            'service_id': serviceId,
            'station_id': stationId,
            'notification_types': notificationTypes,
          })
          .select()
          .single();

      return response;
    } catch (e) {
      throw Exception('Failed to subscribe to notifications: $e');
    }
  }

  /// Get user subscriptions
  Future<List<Map<String, dynamic>>> getUserSubscriptions() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final response = await _supabase
          .from('user_route_subscriptions')
          .select('''
            *,
            route:routes(*,
              origin_station:stations!routes_origin_station_id_fkey(*),
              destination_station:stations!routes_destination_station_id_fkey(*)
            ),
            service:train_services(*),
            station:stations(*)
          ''')
          .eq('user_id', user.id)
          .eq('is_active', true)
          .order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to fetch user subscriptions: $e');
    }
  }

  // ==================== HELPER METHODS ====================

  /// Get day column name for database query
  String _getDayColumn(int dayOfWeek) {
    switch (dayOfWeek) {
      case 1:
        return 'operates_monday';
      case 2:
        return 'operates_tuesday';
      case 3:
        return 'operates_wednesday';
      case 4:
        return 'operates_thursday';
      case 5:
        return 'operates_friday';
      case 6:
        return 'operates_saturday';
      case 7:
        return 'operates_sunday';
      default:
        return 'operates_monday';
    }
  }

  /// Format time for display
  String formatTime(String time) {
    try {
      final parts = time.split(':');
      final hour = int.parse(parts[0]);
      final minute = parts[1];

      if (hour == 0) return '12:$minute AM';
      if (hour < 12) return '$hour:$minute AM';
      if (hour == 12) return '12:$minute PM';
      return '${hour - 12}:$minute PM';
    } catch (e) {
      return time;
    }
  }

  /// Calculate journey duration
  String calculateDuration(String departureTime, String arrivalTime) {
    try {
      final depParts = departureTime.split(':');
      final arrParts = arrivalTime.split(':');

      final depMinutes = int.parse(depParts[0]) * 60 + int.parse(depParts[1]);
      final arrMinutes = int.parse(arrParts[0]) * 60 + int.parse(arrParts[1]);

      var duration = arrMinutes - depMinutes;
      if (duration < 0) duration += 24 * 60; // Next day arrival

      final hours = duration ~/ 60;
      final minutes = duration % 60;

      if (hours > 0) {
        return '${hours}h ${minutes}m';
      } else {
        return '${minutes}m';
      }
    } catch (e) {
      return 'N/A';
    }
  }
}
