-- Location: supabase/migrations/20241216074052_prasa_auth_system.sql
-- Schema Analysis: Empty database - creating complete authentication system
-- Integration Type: Fresh authentication system for PRASA mobile ticketing
-- Dependencies: None (first migration)

-- 1. Types and Enums
CREATE TYPE public.user_role AS ENUM ('admin', 'manager', 'passenger');
CREATE TYPE public.user_status AS ENUM ('active', 'inactive', 'suspended');
CREATE TYPE public.preferred_language AS ENUM ('english', 'afrikaans', 'zulu', 'xhosa');

-- 2. Core user profiles table (intermediary between auth.users and app)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    phone TEXT,
    date_of_birth DATE,
    avatar_url TEXT,
    role public.user_role DEFAULT 'passenger'::public.user_role,
    status public.user_status DEFAULT 'active'::public.user_status,
    preferred_language public.preferred_language DEFAULT 'english'::public.preferred_language,
    home_station TEXT,
    work_station TEXT,
    is_email_verified BOOLEAN DEFAULT false,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Travel preferences table
CREATE TABLE public.travel_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    preferred_travel_time TEXT DEFAULT 'morning',
    notification_preferences JSONB DEFAULT '{"delays": true, "platform_changes": true, "special_offers": true}'::JSONB,
    accessibility_needs TEXT[],
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Essential Indexes
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX idx_user_profiles_status ON public.user_profiles(status);
CREATE INDEX idx_travel_preferences_user_id ON public.travel_preferences(user_id);

-- 5. Functions for automatic profile creation and updates
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $func$
BEGIN
    INSERT INTO public.user_profiles (
        id, 
        email, 
        full_name, 
        phone,
        date_of_birth,
        avatar_url,
        role,
        preferred_language,
        home_station,
        work_station
    ) VALUES (
        NEW.id, 
        NEW.email, 
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'phone', ''),
        CASE 
            WHEN NEW.raw_user_meta_data->>'date_of_birth' IS NOT NULL 
            THEN (NEW.raw_user_meta_data->>'date_of_birth')::DATE 
            ELSE NULL 
        END,
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', ''),
        COALESCE((NEW.raw_user_meta_data->>'role')::public.user_role, 'passenger'::public.user_role),
        COALESCE((NEW.raw_user_meta_data->>'preferred_language')::public.preferred_language, 'english'::public.preferred_language),
        COALESCE(NEW.raw_user_meta_data->>'home_station', ''),
        COALESCE(NEW.raw_user_meta_data->>'work_station', '')
    );
    
    -- Create default travel preferences
    INSERT INTO public.travel_preferences (user_id)
    VALUES (NEW.id);
    
    RETURN NEW;
END;
$func$;

-- 6. Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $func$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$func$;

-- 7. Triggers
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER update_user_profiles_updated_at
    BEFORE UPDATE ON public.user_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_travel_preferences_updated_at
    BEFORE UPDATE ON public.travel_preferences
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

-- 8. Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.travel_preferences ENABLE ROW LEVEL SECURITY;

-- 9. RLS Policies - Using Pattern 1 for user_profiles (core user table)
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Pattern 2: Simple user ownership for travel preferences
CREATE POLICY "users_manage_own_travel_preferences"
ON public.travel_preferences
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Pattern 6A: Admin access using auth.users metadata (safe for all tables)
CREATE OR REPLACE FUNCTION public.is_admin_from_auth()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' = 'admin' 
         OR au.raw_app_meta_data->>'role' = 'admin')
)
$$;

-- Admin policies for both tables
CREATE POLICY "admin_full_access_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

CREATE POLICY "admin_full_access_travel_preferences"
ON public.travel_preferences
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- 10. Mock Data for Development/Testing
DO $$
DECLARE
    admin_user_id UUID := gen_random_uuid();
    regular_user_id UUID := gen_random_uuid();
    manager_user_id UUID := gen_random_uuid();
BEGIN
    -- Create auth users with required fields
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_user_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@prasa.com', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "PRASA Admin", "role": "admin", "phone": "+27123456789"}'::jsonb, 
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (manager_user_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'manager@prasa.com', crypt('manager123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Station Manager", "role": "manager", "phone": "+27123456790", "home_station": "Cape Town", "work_station": "Cape Town Central"}'::jsonb,
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (regular_user_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'user@example.com', crypt('user123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "John Passenger", "role": "passenger", "phone": "+27123456791", "home_station": "Johannesburg", "work_station": "Sandton"}'::jsonb,
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);
END $$;

-- 11. Cleanup function for development
CREATE OR REPLACE FUNCTION public.cleanup_test_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $func$
DECLARE
    auth_user_ids_to_delete UUID[];
BEGIN
    -- Get test user IDs
    SELECT ARRAY_AGG(id) INTO auth_user_ids_to_delete
    FROM auth.users
    WHERE email IN ('admin@prasa.com', 'manager@prasa.com', 'user@example.com');

    -- Delete in dependency order (children first)
    DELETE FROM public.travel_preferences WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.user_profiles WHERE id = ANY(auth_user_ids_to_delete);
    
    -- Delete auth.users last
    DELETE FROM auth.users WHERE id = ANY(auth_user_ids_to_delete);
    
    RAISE NOTICE 'Test data cleanup completed';
EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key constraint prevents deletion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END;
$func$;