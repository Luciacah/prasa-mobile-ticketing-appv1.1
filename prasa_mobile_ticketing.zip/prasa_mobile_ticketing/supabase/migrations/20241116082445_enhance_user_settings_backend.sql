-- Location: supabase/migrations/20241116082445_enhance_user_settings_backend.sql
-- Schema Analysis: user_profiles and travel_preferences exist with comprehensive fields
-- Integration Type: Addition - Creating additional settings infrastructure
-- Dependencies: user_profiles (existing), travel_preferences (existing)

-- 1. Create additional settings types for comprehensive app preferences
CREATE TYPE public.theme_mode AS ENUM ('light', 'dark', 'system');
CREATE TYPE public.app_language AS ENUM ('en', 'af', 'zu', 'xh');
CREATE TYPE public.data_sync_frequency AS ENUM ('real_time', 'hourly', 'daily', 'manual');

-- 2. Create user settings table for app-wide preferences
CREATE TABLE public.user_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    theme_mode public.theme_mode DEFAULT 'system'::public.theme_mode,
    app_language public.app_language DEFAULT 'en'::public.app_language,
    data_sync_frequency public.data_sync_frequency DEFAULT 'real_time'::public.data_sync_frequency,
    auto_backup_enabled BOOLEAN DEFAULT true,
    biometric_auth_enabled BOOLEAN DEFAULT false,
    location_services_enabled BOOLEAN DEFAULT true,
    analytics_enabled BOOLEAN DEFAULT true,
    marketing_notifications BOOLEAN DEFAULT false,
    security_notifications BOOLEAN DEFAULT true,
    system_notifications BOOLEAN DEFAULT true,
    offline_mode_enabled BOOLEAN DEFAULT false,
    data_saver_mode BOOLEAN DEFAULT false,
    auto_update_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

-- 3. Create user sessions table for login tracking
CREATE TABLE public.user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    session_token TEXT NOT NULL,
    device_info JSONB,
    ip_address INET,
    login_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    logout_at TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create audit log table for user activity tracking
CREATE TABLE public.user_activity_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    action_type TEXT NOT NULL,
    table_name TEXT,
    record_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Essential Indexes for performance
CREATE INDEX idx_user_settings_user_id ON public.user_settings(user_id);
CREATE INDEX idx_user_sessions_user_id ON public.user_sessions(user_id);
CREATE INDEX idx_user_sessions_active ON public.user_sessions(is_active) WHERE is_active = true;
CREATE INDEX idx_user_activity_logs_user_id ON public.user_activity_logs(user_id);
CREATE INDEX idx_user_activity_logs_created_at ON public.user_activity_logs(created_at);
CREATE INDEX idx_user_activity_logs_action_type ON public.user_activity_logs(action_type);

-- 6. Update trigger for user_settings
CREATE OR REPLACE FUNCTION public.update_updated_at_user_settings()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

CREATE TRIGGER update_user_settings_updated_at
    BEFORE UPDATE ON public.user_settings
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_user_settings();

-- 7. Enable RLS
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_activity_logs ENABLE ROW LEVEL SECURITY;

-- 8. RLS Policies - Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_user_settings"
ON public.user_settings
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_user_sessions"
ON public.user_sessions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_view_own_activity_logs"
ON public.user_activity_logs
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Admin policy for user_activity_logs using existing is_admin_from_auth function
CREATE POLICY "admin_full_access_user_activity_logs"
ON public.user_activity_logs
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- 9. Function to automatically create user settings when user profile is created
CREATE OR REPLACE FUNCTION public.create_default_user_settings()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.user_settings (user_id)
    VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
    RETURN NEW;
END;
$$;

CREATE TRIGGER create_user_settings_on_profile_creation
    AFTER INSERT ON public.user_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.create_default_user_settings();

-- 10. Function to log user activity
CREATE OR REPLACE FUNCTION public.log_user_activity(
    p_user_id UUID,
    p_action_type TEXT,
    p_table_name TEXT DEFAULT NULL,
    p_record_id UUID DEFAULT NULL,
    p_old_values JSONB DEFAULT NULL,
    p_new_values JSONB DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.user_activity_logs (
        user_id, action_type, table_name, record_id,
        old_values, new_values
    )
    VALUES (
        p_user_id, p_action_type, p_table_name, p_record_id,
        p_old_values, p_new_values
    );
EXCEPTION
    WHEN OTHERS THEN
        -- Silently fail to avoid breaking main operations
        NULL;
END;
$$;

-- 11. Mock data for existing users
DO $$
DECLARE
    existing_user_record RECORD;
BEGIN
    -- Create default settings for existing users
    FOR existing_user_record IN 
        SELECT id FROM public.user_profiles
    LOOP
        INSERT INTO public.user_settings (user_id)
        VALUES (existing_user_record.id)
        ON CONFLICT (user_id) DO NOTHING;
    END LOOP;
    
    -- Log successful setup
    RAISE NOTICE 'Enhanced user settings backend created successfully';
END $$;