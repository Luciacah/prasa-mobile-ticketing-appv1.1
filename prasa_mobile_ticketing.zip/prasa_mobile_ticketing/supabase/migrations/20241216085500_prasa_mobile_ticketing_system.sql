-- Location: supabase/migrations/20241216085500_prasa_mobile_ticketing_system.sql
-- Schema Analysis: Existing user_profiles, travel_preferences, user_settings foundation
-- Integration Type: Addition - Extending user management with mobile ticketing functionality
-- Dependencies: user_profiles (for user relationships), existing enum types

-- ==============================================
-- 1. TYPES AND ENUMS
-- ==============================================

-- Train service types
CREATE TYPE public.service_type AS ENUM ('metro', 'commuter', 'long_distance', 'express');

-- Train status types
CREATE TYPE public.train_status AS ENUM ('on_time', 'delayed', 'cancelled', 'boarding');

-- Ticket types and classes
CREATE TYPE public.ticket_type AS ENUM ('single', 'return', 'weekly', 'monthly', 'annual');
CREATE TYPE public.ticket_class AS ENUM ('economy', 'business', 'first_class');

-- Booking and payment statuses
CREATE TYPE public.booking_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed', 'expired');
CREATE TYPE public.payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');
CREATE TYPE public.payment_method AS ENUM ('card', 'mobile_money', 'cash', 'wallet');

-- Ticket validation status
CREATE TYPE public.ticket_status AS ENUM ('active', 'used', 'expired', 'cancelled', 'refunded');

-- ==============================================
-- 2. CORE INFRASTRUCTURE TABLES
-- ==============================================

-- Train stations
CREATE TABLE public.stations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    is_active BOOLEAN DEFAULT true,
    facilities JSONB DEFAULT '[]'::jsonb,
    contact_info JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Train routes connecting stations
CREATE TABLE public.routes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_number TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    origin_station_id UUID NOT NULL REFERENCES public.stations(id),
    destination_station_id UUID NOT NULL REFERENCES public.stations(id),
    distance_km DECIMAL(8, 2),
    estimated_duration_minutes INTEGER,
    is_active BOOLEAN DEFAULT true,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_different_stations CHECK (origin_station_id != destination_station_id)
);

-- Route stops (intermediate stations)
CREATE TABLE public.route_stops (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_id UUID NOT NULL REFERENCES public.routes(id) ON DELETE CASCADE,
    station_id UUID NOT NULL REFERENCES public.stations(id),
    stop_order INTEGER NOT NULL,
    distance_from_origin_km DECIMAL(8, 2),
    estimated_minutes_from_origin INTEGER,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(route_id, station_id),
    UNIQUE(route_id, stop_order)
);

-- ==============================================
-- 3. SERVICE AND SCHEDULE TABLES
-- ==============================================

-- Train services running on routes
CREATE TABLE public.train_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_number TEXT NOT NULL,
    route_id UUID NOT NULL REFERENCES public.routes(id),
    service_type public.service_type DEFAULT 'commuter'::public.service_type,
    train_number TEXT,
    capacity INTEGER DEFAULT 200,
    operates_monday BOOLEAN DEFAULT true,
    operates_tuesday BOOLEAN DEFAULT true,
    operates_wednesday BOOLEAN DEFAULT true,
    operates_thursday BOOLEAN DEFAULT true,
    operates_friday BOOLEAN DEFAULT true,
    operates_saturday BOOLEAN DEFAULT true,
    operates_sunday BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    amenities JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(service_number, route_id)
);

-- Daily service schedules
CREATE TABLE public.service_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_id UUID NOT NULL REFERENCES public.train_services(id) ON DELETE CASCADE,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    effective_from DATE DEFAULT CURRENT_DATE,
    effective_until DATE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Real-time service status updates
CREATE TABLE public.service_status (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_id UUID NOT NULL REFERENCES public.train_services(id),
    schedule_date DATE DEFAULT CURRENT_DATE,
    status public.train_status DEFAULT 'on_time'::public.train_status,
    delay_minutes INTEGER DEFAULT 0,
    current_station_id UUID REFERENCES public.stations(id),
    message TEXT,
    updated_by UUID REFERENCES public.user_profiles(id),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(service_id, schedule_date)
);

-- ==============================================
-- 4. PRICING AND TICKETS
-- ==============================================

-- Fare pricing matrix
CREATE TABLE public.fare_prices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_id UUID NOT NULL REFERENCES public.routes(id),
    ticket_type public.ticket_type NOT NULL,
    ticket_class public.ticket_class DEFAULT 'economy'::public.ticket_class,
    base_price DECIMAL(8, 2) NOT NULL,
    peak_hour_multiplier DECIMAL(3, 2) DEFAULT 1.0,
    weekend_multiplier DECIMAL(3, 2) DEFAULT 1.0,
    student_discount_percent INTEGER DEFAULT 0,
    senior_discount_percent INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    effective_from DATE DEFAULT CURRENT_DATE,
    effective_until DATE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_positive_price CHECK (base_price > 0),
    CONSTRAINT check_valid_multipliers CHECK (
        peak_hour_multiplier >= 0.5 AND peak_hour_multiplier <= 3.0 AND
        weekend_multiplier >= 0.5 AND weekend_multiplier <= 3.0
    )
);

-- ==============================================
-- 5. BOOKING AND RESERVATION SYSTEM  
-- ==============================================

-- Main bookings table
CREATE TABLE public.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_reference TEXT NOT NULL UNIQUE,
    user_id UUID NOT NULL REFERENCES public.user_profiles(id),
    service_id UUID NOT NULL REFERENCES public.train_services(id),
    origin_station_id UUID NOT NULL REFERENCES public.stations(id),
    destination_station_id UUID NOT NULL REFERENCES public.stations(id),
    travel_date DATE NOT NULL,
    departure_time TIME NOT NULL,
    ticket_type public.ticket_type NOT NULL,
    ticket_class public.ticket_class DEFAULT 'economy'::public.ticket_class,
    passenger_count INTEGER DEFAULT 1,
    total_amount DECIMAL(10, 2) NOT NULL,
    booking_status public.booking_status DEFAULT 'pending'::public.booking_status,
    booking_source TEXT DEFAULT 'mobile_app',
    special_requirements TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_future_travel CHECK (travel_date >= CURRENT_DATE),
    CONSTRAINT check_passenger_count CHECK (passenger_count > 0 AND passenger_count <= 10),
    CONSTRAINT check_positive_amount CHECK (total_amount > 0)
);

-- Individual passengers for each booking
CREATE TABLE public.booking_passengers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    passenger_name TEXT NOT NULL,
    passenger_age INTEGER,
    passenger_id_number TEXT,
    passenger_type TEXT DEFAULT 'adult',
    seat_preference TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_valid_age CHECK (passenger_age IS NULL OR (passenger_age > 0 AND passenger_age < 150))
);

-- ==============================================
-- 6. PAYMENT PROCESSING
-- ==============================================

-- Payment transactions
CREATE TABLE public.payment_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_reference TEXT NOT NULL UNIQUE,
    booking_id UUID NOT NULL REFERENCES public.bookings(id),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id),
    amount DECIMAL(10, 2) NOT NULL,
    currency TEXT DEFAULT 'ZAR',
    payment_method public.payment_method NOT NULL,
    payment_status public.payment_status DEFAULT 'pending'::public.payment_status,
    payment_gateway TEXT,
    gateway_transaction_id TEXT,
    payment_date TIMESTAMPTZ,
    failure_reason TEXT,
    refund_amount DECIMAL(10, 2) DEFAULT 0,
    refund_date TIMESTAMPTZ,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_positive_payment_amount CHECK (amount > 0),
    CONSTRAINT check_valid_refund CHECK (refund_amount >= 0 AND refund_amount <= amount)
);

-- ==============================================
-- 7. DIGITAL TICKETS
-- ==============================================

-- Generated digital tickets
CREATE TABLE public.digital_tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_number TEXT NOT NULL UNIQUE,
    booking_id UUID NOT NULL REFERENCES public.bookings(id),
    passenger_id UUID REFERENCES public.booking_passengers(id),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id),
    qr_code_data TEXT NOT NULL,
    barcode_data TEXT,
    ticket_status public.ticket_status DEFAULT 'active'::public.ticket_status,
    issued_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    valid_from TIMESTAMPTZ NOT NULL,
    valid_until TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    validated_by TEXT,
    validation_location TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_validity_period CHECK (valid_until > valid_from)
);

-- ==============================================
-- 8. USER ACTIVITY AND NOTIFICATIONS
-- ==============================================

-- Service alerts and notifications
CREATE TABLE public.service_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    alert_type TEXT DEFAULT 'info',
    severity TEXT DEFAULT 'medium',
    service_id UUID REFERENCES public.train_services(id),
    route_id UUID REFERENCES public.routes(id),
    station_id UUID REFERENCES public.stations(id),
    is_active BOOLEAN DEFAULT true,
    starts_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ,
    created_by UUID REFERENCES public.user_profiles(id),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_alert_period CHECK (expires_at IS NULL OR expires_at > starts_at)
);

-- User notification preferences for specific routes/services
CREATE TABLE public.user_route_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id),
    route_id UUID REFERENCES public.routes(id),
    service_id UUID REFERENCES public.train_services(id),
    station_id UUID REFERENCES public.stations(id),
    notification_types JSONB DEFAULT '["delays", "cancellations"]'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(user_id, route_id),
    CONSTRAINT check_subscription_target CHECK (
        (route_id IS NOT NULL) OR (service_id IS NOT NULL) OR (station_id IS NOT NULL)
    )
);

-- ==============================================
-- 9. INDEXES FOR PERFORMANCE
-- ==============================================

-- Station indexes
CREATE INDEX idx_stations_city ON public.stations(city);
CREATE INDEX idx_stations_active ON public.stations(is_active);
CREATE INDEX idx_stations_location ON public.stations(latitude, longitude);

-- Route indexes
CREATE INDEX idx_routes_origin_destination ON public.routes(origin_station_id, destination_station_id);
CREATE INDEX idx_routes_active ON public.routes(is_active);

-- Service and schedule indexes
CREATE INDEX idx_train_services_route ON public.train_services(route_id);
CREATE INDEX idx_train_services_active ON public.train_services(is_active);
CREATE INDEX idx_service_schedules_service ON public.service_schedules(service_id);
CREATE INDEX idx_service_schedules_departure ON public.service_schedules(departure_time);
CREATE INDEX idx_service_status_date ON public.service_status(service_id, schedule_date);

-- Booking indexes
CREATE INDEX idx_bookings_user ON public.bookings(user_id);
CREATE INDEX idx_bookings_travel_date ON public.bookings(travel_date);
CREATE INDEX idx_bookings_status ON public.bookings(booking_status);
CREATE INDEX idx_bookings_service_date ON public.bookings(service_id, travel_date);

-- Payment indexes  
CREATE INDEX idx_payment_transactions_booking ON public.payment_transactions(booking_id);
CREATE INDEX idx_payment_transactions_user ON public.payment_transactions(user_id);
CREATE INDEX idx_payment_transactions_status ON public.payment_transactions(payment_status);

-- Digital ticket indexes
CREATE INDEX idx_digital_tickets_booking ON public.digital_tickets(booking_id);
CREATE INDEX idx_digital_tickets_user ON public.digital_tickets(user_id);
CREATE INDEX idx_digital_tickets_status ON public.digital_tickets(ticket_status);
CREATE INDEX idx_digital_tickets_validity ON public.digital_tickets(valid_from, valid_until);

-- Alert and subscription indexes
CREATE INDEX idx_service_alerts_active ON public.service_alerts(is_active, starts_at, expires_at);
CREATE INDEX idx_user_subscriptions_user ON public.user_route_subscriptions(user_id);

-- ==============================================
-- 10. HELPER FUNCTIONS
-- ==============================================

-- Function to generate unique booking reference
CREATE OR REPLACE FUNCTION public.generate_booking_reference()
RETURNS TEXT
LANGUAGE plpgsql
AS $func$
DECLARE
    reference TEXT;
    exists_count INTEGER;
BEGIN
    LOOP
        reference := 'PRASA' || UPPER(SUBSTRING(gen_random_uuid()::TEXT FROM 1 FOR 8));
        
        SELECT COUNT(*) INTO exists_count 
        FROM public.bookings 
        WHERE booking_reference = reference;
        
        EXIT WHEN exists_count = 0;
    END LOOP;
    
    RETURN reference;
END;
$func$;

-- Function to generate ticket number
CREATE OR REPLACE FUNCTION public.generate_ticket_number()
RETURNS TEXT
LANGUAGE plpgsql  
AS $func$
DECLARE
    ticket_num TEXT;
    exists_count INTEGER;
BEGIN
    LOOP
        ticket_num := 'TKT' || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || LPAD(FLOOR(RANDOM() * 100000)::TEXT, 5, '0');
        
        SELECT COUNT(*) INTO exists_count 
        FROM public.digital_tickets 
        WHERE ticket_number = ticket_num;
        
        EXIT WHEN exists_count = 0;
    END LOOP;
    
    RETURN ticket_num;
END;
$func$;

-- Function to calculate fare between stations
CREATE OR REPLACE FUNCTION public.calculate_fare(
    p_route_id UUID,
    p_ticket_type public.ticket_type,
    p_ticket_class public.ticket_class,
    p_travel_time TIME DEFAULT NULL
)
RETURNS DECIMAL(8, 2)
LANGUAGE plpgsql
SECURITY DEFINER
AS $func$
DECLARE
    base_fare DECIMAL(8, 2);
    final_fare DECIMAL(8, 2);
    peak_multiplier DECIMAL(3, 2) := 1.0;
BEGIN
    -- Get base fare
    SELECT fp.base_price INTO base_fare
    FROM public.fare_prices fp
    WHERE fp.route_id = p_route_id 
        AND fp.ticket_type = p_ticket_type 
        AND fp.ticket_class = p_ticket_class
        AND fp.is_active = true
        AND (fp.effective_from <= CURRENT_DATE)
        AND (fp.effective_until IS NULL OR fp.effective_until >= CURRENT_DATE)
    ORDER BY fp.created_at DESC
    LIMIT 1;

    IF base_fare IS NULL THEN
        RAISE EXCEPTION 'No fare found for route %, ticket type %, class %', p_route_id, p_ticket_type, p_ticket_class;
    END IF;

    -- Apply peak hour multiplier if time provided
    IF p_travel_time IS NOT NULL AND 
       (p_travel_time BETWEEN '07:00' AND '09:00' OR p_travel_time BETWEEN '17:00' AND '19:00') THEN
        
        SELECT fp.peak_hour_multiplier INTO peak_multiplier
        FROM public.fare_prices fp
        WHERE fp.route_id = p_route_id 
            AND fp.ticket_type = p_ticket_type 
            AND fp.ticket_class = p_ticket_class
            AND fp.is_active = true
        LIMIT 1;
    END IF;

    final_fare := base_fare * peak_multiplier;
    RETURN ROUND(final_fare, 2);
END;
$func$;

-- ==============================================
-- 11. ROW LEVEL SECURITY SETUP
-- ==============================================

-- Enable RLS on all tables
ALTER TABLE public.stations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.route_stops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.train_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fare_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_passengers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.digital_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_route_subscriptions ENABLE ROW LEVEL SECURITY;

-- ==============================================
-- 12. RLS POLICIES
-- ==============================================

-- Stations: Public read, admin write
CREATE POLICY "public_can_read_stations" 
ON public.stations FOR SELECT 
TO public USING (true);

CREATE POLICY "admin_can_manage_stations" 
ON public.stations FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Routes: Public read, admin write  
CREATE POLICY "public_can_read_routes" 
ON public.routes FOR SELECT 
TO public USING (true);

CREATE POLICY "admin_can_manage_routes" 
ON public.routes FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Route stops: Public read, admin write
CREATE POLICY "public_can_read_route_stops" 
ON public.route_stops FOR SELECT 
TO public USING (true);

CREATE POLICY "admin_can_manage_route_stops" 
ON public.route_stops FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Train services: Public read, admin write
CREATE POLICY "public_can_read_train_services" 
ON public.train_services FOR SELECT 
TO public USING (true);

CREATE POLICY "admin_can_manage_train_services" 
ON public.train_services FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Service schedules: Public read, admin write
CREATE POLICY "public_can_read_service_schedules" 
ON public.service_schedules FOR SELECT 
TO public USING (true);

CREATE POLICY "admin_can_manage_service_schedules" 
ON public.service_schedules FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Service status: Public read, staff write
CREATE POLICY "public_can_read_service_status" 
ON public.service_status FOR SELECT 
TO public USING (true);

CREATE POLICY "staff_can_update_service_status" 
ON public.service_status FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Fare prices: Public read, admin write
CREATE POLICY "public_can_read_fare_prices" 
ON public.fare_prices FOR SELECT 
TO public USING (true);

CREATE POLICY "admin_can_manage_fare_prices" 
ON public.fare_prices FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- Bookings: Users manage their own
CREATE POLICY "users_manage_own_bookings" 
ON public.bookings FOR ALL 
TO authenticated 
USING (user_id = auth.uid()) 
WITH CHECK (user_id = auth.uid());

-- Booking passengers: Users manage their own booking passengers
CREATE POLICY "users_manage_own_booking_passengers" 
ON public.booking_passengers FOR ALL 
TO authenticated 
USING (
    booking_id IN (
        SELECT id FROM public.bookings WHERE user_id = auth.uid()
    )
) 
WITH CHECK (
    booking_id IN (
        SELECT id FROM public.bookings WHERE user_id = auth.uid()
    )
);

-- Payment transactions: Users see their own
CREATE POLICY "users_manage_own_payment_transactions" 
ON public.payment_transactions FOR ALL 
TO authenticated 
USING (user_id = auth.uid()) 
WITH CHECK (user_id = auth.uid());

-- Digital tickets: Users see their own
CREATE POLICY "users_manage_own_digital_tickets" 
ON public.digital_tickets FOR ALL 
TO authenticated 
USING (user_id = auth.uid()) 
WITH CHECK (user_id = auth.uid());

-- Service alerts: Public read, admin write
CREATE POLICY "public_can_read_service_alerts" 
ON public.service_alerts FOR SELECT 
TO public USING (is_active = true);

CREATE POLICY "admin_can_manage_service_alerts" 
ON public.service_alerts FOR ALL 
TO authenticated 
USING (public.is_admin_from_auth()) 
WITH CHECK (public.is_admin_from_auth());

-- User subscriptions: Users manage their own
CREATE POLICY "users_manage_own_route_subscriptions" 
ON public.user_route_subscriptions FOR ALL 
TO authenticated 
USING (user_id = auth.uid()) 
WITH CHECK (user_id = auth.uid());

-- ==============================================
-- 13. TRIGGERS FOR AUTOMATIC UPDATES
-- ==============================================

-- Trigger for updating timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $trigger$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$trigger$ LANGUAGE plpgsql;

-- Apply update triggers to relevant tables
CREATE TRIGGER update_stations_updated_at 
    BEFORE UPDATE ON public.stations 
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_routes_updated_at 
    BEFORE UPDATE ON public.routes 
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_train_services_updated_at 
    BEFORE UPDATE ON public.train_services 
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at 
    BEFORE UPDATE ON public.bookings 
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payment_transactions_updated_at 
    BEFORE UPDATE ON public.payment_transactions 
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_digital_tickets_updated_at 
    BEFORE UPDATE ON public.digital_tickets 
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Automatic booking reference generation
CREATE OR REPLACE FUNCTION public.set_booking_reference()
RETURNS TRIGGER AS $trigger$
BEGIN
    IF NEW.booking_reference IS NULL OR NEW.booking_reference = '' THEN
        NEW.booking_reference := public.generate_booking_reference();
    END IF;
    RETURN NEW;
END;
$trigger$ LANGUAGE plpgsql;

CREATE TRIGGER set_booking_reference_trigger
    BEFORE INSERT ON public.bookings
    FOR EACH ROW EXECUTE FUNCTION public.set_booking_reference();

-- Automatic ticket number generation
CREATE OR REPLACE FUNCTION public.set_ticket_number()
RETURNS TRIGGER AS $trigger$
BEGIN
    IF NEW.ticket_number IS NULL OR NEW.ticket_number = '' THEN
        NEW.ticket_number := public.generate_ticket_number();
    END IF;
    RETURN NEW;
END;
$trigger$ LANGUAGE plpgsql;

CREATE TRIGGER set_ticket_number_trigger
    BEFORE INSERT ON public.digital_tickets
    FOR EACH ROW EXECUTE FUNCTION public.set_ticket_number();

-- ==============================================
-- 14. SAMPLE DATA FOR TESTING
-- ==============================================

DO $$
DECLARE
    -- Station IDs
    ct_central_id UUID := gen_random_uuid();
    ct_goodwood_id UUID := gen_random_uuid();
    ct_bellville_id UUID := gen_random_uuid();
    ct_parow_id UUID := gen_random_uuid();
    jhb_central_id UUID := gen_random_uuid();
    jhb_sandton_id UUID := gen_random_uuid();
    jhb_rosebank_id UUID := gen_random_uuid();
    dbn_central_id UUID := gen_random_uuid();
    dbn_westville_id UUID := gen_random_uuid();
    
    -- Route IDs
    ct_northern_route_id UUID := gen_random_uuid();
    jhb_gautrain_route_id UUID := gen_random_uuid();
    dbn_metro_route_id UUID := gen_random_uuid();
    
    -- Service IDs  
    ct_commuter_service_id UUID := gen_random_uuid();
    jhb_express_service_id UUID := gen_random_uuid();
    dbn_metro_service_id UUID := gen_random_uuid();
    
    -- User IDs (get existing admin user)
    admin_user_id UUID;
BEGIN
    -- Get existing admin user
    SELECT id INTO admin_user_id FROM public.user_profiles WHERE role = 'admin' LIMIT 1;
    
    -- Insert major train stations across South Africa
    INSERT INTO public.stations (id, code, name, city, province, latitude, longitude, facilities) VALUES
        (ct_central_id, 'CPT001', 'Cape Town Central', 'Cape Town', 'Western Cape', -33.9058, 18.4168, '["parking", "wifi", "restaurant", "atm"]'),
        (ct_goodwood_id, 'CPT002', 'Goodwood Station', 'Cape Town', 'Western Cape', -33.8891, 18.5398, '["parking", "wifi"]'),
        (ct_bellville_id, 'CPT003', 'Bellville Station', 'Cape Town', 'Western Cape', -33.8803, 18.6292, '["parking", "restaurant", "atm"]'),
        (ct_parow_id, 'CPT004', 'Parow Station', 'Cape Town', 'Western Cape', -33.8920, 18.5970, '["parking"]'),
        
        (jhb_central_id, 'JHB001', 'Johannesburg Central', 'Johannesburg', 'Gauteng', -26.2044, 28.0456, '["parking", "wifi", "restaurant", "atm", "security"]'),
        (jhb_sandton_id, 'JHB002', 'Sandton Station', 'Johannesburg', 'Gauteng', -26.1076, 28.0567, '["parking", "wifi", "restaurant", "shopping"]'),
        (jhb_rosebank_id, 'JHB003', 'Rosebank Station', 'Johannesburg', 'Gauteng', -26.1467, 28.0407, '["parking", "wifi", "shopping"]'),
        
        (dbn_central_id, 'DBN001', 'Durban Central', 'Durban', 'KwaZulu-Natal', -29.8587, 31.0218, '["parking", "wifi", "restaurant", "atm"]'),
        (dbn_westville_id, 'DBN002', 'Westville Station', 'Durban', 'KwaZulu-Natal', -29.8209, 30.9318, '["parking", "wifi"]');
        
    -- Insert train routes
    INSERT INTO public.routes (id, route_number, name, origin_station_id, destination_station_id, distance_km, estimated_duration_minutes) VALUES
        (ct_northern_route_id, 'R001', 'Cape Town Northern Line', ct_central_id, ct_bellville_id, 25.5, 45),
        (jhb_gautrain_route_id, 'R002', 'Johannesburg Express Line', jhb_central_id, jhb_sandton_id, 18.2, 25),
        (dbn_metro_route_id, 'R003', 'Durban Metro Line', dbn_central_id, dbn_westville_id, 12.8, 20);
        
    -- Insert route stops
    INSERT INTO public.route_stops (route_id, station_id, stop_order, distance_from_origin_km, estimated_minutes_from_origin) VALUES
        -- Cape Town Northern Line stops
        (ct_northern_route_id, ct_central_id, 1, 0, 0),
        (ct_northern_route_id, ct_goodwood_id, 2, 8.5, 15),
        (ct_northern_route_id, ct_parow_id, 3, 18.2, 32),
        (ct_northern_route_id, ct_bellville_id, 4, 25.5, 45),
        
        -- Johannesburg Express stops
        (jhb_gautrain_route_id, jhb_central_id, 1, 0, 0),
        (jhb_gautrain_route_id, jhb_rosebank_id, 2, 9.1, 12),
        (jhb_gautrain_route_id, jhb_sandton_id, 3, 18.2, 25),
        
        -- Durban Metro stops
        (dbn_metro_route_id, dbn_central_id, 1, 0, 0),
        (dbn_metro_route_id, dbn_westville_id, 2, 12.8, 20);
        
    -- Insert train services
    INSERT INTO public.train_services (id, service_number, route_id, service_type, capacity, amenities) VALUES
        (ct_commuter_service_id, 'CT001', ct_northern_route_id, 'commuter', 300, '["wifi", "air_conditioning"]'),
        (jhb_express_service_id, 'JHB001', jhb_gautrain_route_id, 'express', 180, '["wifi", "air_conditioning", "business_class"]'),
        (dbn_metro_service_id, 'DBN001', dbn_metro_route_id, 'metro', 250, '["wifi"]');
        
    -- Insert service schedules (multiple daily departures)
    INSERT INTO public.service_schedules (service_id, departure_time, arrival_time) VALUES
        -- Cape Town commuter (every 30 minutes during peak)
        (ct_commuter_service_id, '06:00', '06:45'),
        (ct_commuter_service_id, '06:30', '07:15'),
        (ct_commuter_service_id, '07:00', '07:45'),
        (ct_commuter_service_id, '07:30', '08:15'),
        (ct_commuter_service_id, '08:00', '08:45'),
        (ct_commuter_service_id, '17:00', '17:45'),
        (ct_commuter_service_id, '17:30', '18:15'),
        (ct_commuter_service_id, '18:00', '18:45'),
        
        -- Johannesburg express (every 15 minutes)
        (jhb_express_service_id, '06:00', '06:25'),
        (jhb_express_service_id, '06:15', '06:40'),
        (jhb_express_service_id, '06:30', '06:55'),
        (jhb_express_service_id, '06:45', '07:10'),
        (jhb_express_service_id, '17:15', '17:40'),
        (jhb_express_service_id, '17:30', '17:55'),
        (jhb_express_service_id, '17:45', '18:10'),
        
        -- Durban metro (every 20 minutes)
        (dbn_metro_service_id, '06:20', '06:40'),
        (dbn_metro_service_id, '06:40', '07:00'),
        (dbn_metro_service_id, '07:00', '07:20'),
        (dbn_metro_service_id, '17:20', '17:40'),
        (dbn_metro_service_id, '17:40', '18:00');
        
    -- Insert fare prices
    INSERT INTO public.fare_prices (route_id, ticket_type, ticket_class, base_price, peak_hour_multiplier, student_discount_percent, senior_discount_percent) VALUES
        -- Cape Town Northern Line
        (ct_northern_route_id, 'single', 'economy', 15.50, 1.2, 20, 15),
        (ct_northern_route_id, 'return', 'economy', 29.00, 1.2, 20, 15),
        (ct_northern_route_id, 'weekly', 'economy', 95.00, 1.0, 20, 15),
        (ct_northern_route_id, 'monthly', 'economy', 350.00, 1.0, 20, 15),
        
        -- Johannesburg Express
        (jhb_gautrain_route_id, 'single', 'economy', 25.00, 1.3, 15, 10),
        (jhb_gautrain_route_id, 'single', 'business', 45.00, 1.3, 0, 0),
        (jhb_gautrain_route_id, 'return', 'economy', 47.00, 1.3, 15, 10),
        (jhb_gautrain_route_id, 'return', 'business', 85.00, 1.3, 0, 0),
        (jhb_gautrain_route_id, 'monthly', 'economy', 850.00, 1.0, 15, 10),
        
        -- Durban Metro
        (dbn_metro_route_id, 'single', 'economy', 12.00, 1.1, 25, 20),
        (dbn_metro_route_id, 'return', 'economy', 22.50, 1.1, 25, 20),
        (dbn_metro_route_id, 'weekly', 'economy', 75.00, 1.0, 25, 20);
        
    -- Insert sample service alerts
    INSERT INTO public.service_alerts (title, message, alert_type, service_id, created_by, expires_at) VALUES
        ('Morning Service Update', 'All services running on time this morning. Have a great journey!', 'info', ct_commuter_service_id, admin_user_id, CURRENT_TIMESTAMP + INTERVAL '1 day'),
        ('Platform Change', 'Johannesburg Express services departing from Platform 3 today due to maintenance.', 'warning', jhb_express_service_id, admin_user_id, CURRENT_TIMESTAMP + INTERVAL '8 hours'),
        ('Weekend Schedule', 'Reduced weekend schedule in effect. Check timetable for updated departure times.', 'info', dbn_metro_service_id, admin_user_id, CURRENT_TIMESTAMP + INTERVAL '3 days');
        
    -- Insert current service status (all on time)
    INSERT INTO public.service_status (service_id, status, updated_by) VALUES
        (ct_commuter_service_id, 'on_time', admin_user_id),
        (jhb_express_service_id, 'on_time', admin_user_id),
        (dbn_metro_service_id, 'on_time', admin_user_id);
        
    RAISE NOTICE 'PRASA Mobile Ticketing System sample data created successfully!';
    RAISE NOTICE 'Created % stations, % routes, and % train services', 9, 3, 3;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating sample data: %', SQLERRM;
END $$;

-- ==============================================
-- 15. DATA CLEANUP FUNCTION
-- ==============================================

CREATE OR REPLACE FUNCTION public.cleanup_prasa_test_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $cleanup$
BEGIN
    -- Delete in reverse dependency order
    DELETE FROM public.digital_tickets WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.booking_passengers;
    DELETE FROM public.payment_transactions WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.bookings WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.user_route_subscriptions WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.service_alerts WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.service_status WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.service_schedules;
    DELETE FROM public.fare_prices WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.train_services WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.route_stops;
    DELETE FROM public.routes WHERE created_at >= CURRENT_DATE;
    DELETE FROM public.stations WHERE created_at >= CURRENT_DATE;
    
    RAISE NOTICE 'PRASA test data cleanup completed successfully';
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END;
$cleanup$;

-- Final success message
DO $$
BEGIN
    RAISE NOTICE '🚆 PRASA Mobile Ticketing System Backend Complete! 🚆';
    RAISE NOTICE '✅ Created comprehensive train system with stations, routes, services, and schedules';
    RAISE NOTICE '✅ Implemented booking and payment processing with digital tickets';
    RAISE NOTICE '✅ Added real-time service status and user notifications';
    RAISE NOTICE '✅ Set up Row Level Security for data protection';
    RAISE NOTICE '✅ Generated sample data for Cape Town, Johannesburg, and Durban routes';
    RAISE NOTICE '📱 Ready for mobile app integration!';
END $$;